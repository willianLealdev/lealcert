<?php
function b64u($s){ return rtrim(strtr(base64_encode($s), '+/','-_'),'='); }
function ub64u($s){ return base64_decode(strtr($s,'-_','+/')); }

function app_secret(): string {
  return getenv('APP_SECRET') ?: (defined('APP_SECRET') ? APP_SECRET : 'change-me');
}

function make_signed_ref(int $id, string $scope='order'): array {
  $payload = $scope.':'.$id;
  $sig = hash_hmac('sha256', $payload, app_secret(), true);
  return ['oid'=>b64u((string)$id), 'sig'=>b64u($sig)];
}

function verify_signed_ref(string $oid, string $sig, string $scope='order'): ?int {
  $id = (int)ub64u($oid);
  if ($id<=0) return null;
  $expected = b64u(hash_hmac('sha256', $scope.':'.$id, app_secret(), true));
  return hash_equals($expected, $sig) ? $id : null;
}
