<?php
require_login();
$u = auth_user();

$stmt = $pdo->prepare("SELECT o.*, m.name AS mname, m.price AS mprice
FROM orders o
JOIN certificate_models m ON m.id=o.model_id
WHERE o.user_id=? ORDER BY o.id DESC");
$stmt->execute([$u['id']]);
$rows = $stmt->fetchAll();

function status_badge($s){
  $map = [
    'created'            => ['gray','Criado'],
    'pending_payment'    => ['warn','Aguardando pagamento'],
    'paid'               => ['ok','Pago'],
    'protocol_assigned'  => ['info','Protocolo'],
    'completed'          => ['done','Concluído'],
  ];
  [$cls,$txt] = $map[$s] ?? ['gray', ucfirst($s)];
  return "<span class='badge $cls'>$txt</span>";
}

/* HEADER do seu painel (fallbacks) */
$__hdr = [
  __DIR__ . '/_header.php',
  __DIR__ . '/../views/_header.php',
  __DIR__ . '/../_header.php',
  __DIR__ . '/partials/_header.php'
];
foreach ($__hdr as $__p) { if (file_exists($__p)) { include $__p; break; } }
?>
<style>
:root{--bg:#f8f9fb;--card:#fff;--text:#1f2937;--muted:#6b7280;--brand:#0d6efd;--border:#e5e7eb}
.ridie-wrap{max-width:1100px;margin:0 auto;padding:24px}
.h-title{font-size:24px;font-weight:800;margin:0 0 16px}
.table{width:100%;border-collapse:collapse;background:var(--card);border-radius:16px;overflow:hidden;box-shadow:0 6px 16px rgba(0,0,0,.06)}
.table th,.table td{padding:12px 14px;border-bottom:1px solid var(--border);font-size:14px;color:#111827}
.table thead th{text-align:left;background:#f3f4f6;font-weight:700;color:#374151}
.badge{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700}
.badge.gray{background:#eef2ff;color:#3730a3}.badge.warn{background:#fffbeb;color:#92400e}
.badge.ok{background:#ecfdf5;color:#065f46}.badge.info{background:#eff6ff;color:#1e40af}
.badge.done{background:#ecfeff;color:#155e75}
.btn{appearance:none;border:1px solid var(--border);background:#fff;padding:8px 12px;border-radius:10px;font-weight:700;cursor:pointer;font-size:13px}
.btn:hover{box-shadow:0 2px 10px rgba(0,0,0,.06)}.btn.primary{background:var(--brand);color:#fff;border-color:var(--brand)}
.small{font-size:12px;color:#6b7280}
.row-main{cursor:pointer}
.row-main:hover{background:#fafafa}
.row-details{background:#fcfcfd}
.details-card{padding:14px 10px}
.kv{display:grid;grid-template-columns:180px 1fr;gap:8px 14px;font-size:14px}
.kv b{color:#374151}
.hr{height:1px;background:var(--border);margin:12px 0}
.slot-badge{padding:.55rem .85rem;border:1px solid var(--border);border-radius:12px;margin:.3rem;display:inline-block;cursor:pointer;font-weight:700}
.slot-badge.disabled{opacity:.45;cursor:not-allowed}.slot-badge.active{border-color:var(--brand);background:var(--brand);color:#fff}
.slot-row{display:flex;flex-wrap:wrap}
.alert{position:fixed;right:18px;bottom:18px;background:#111827;color:#fff;padding:10px 14px;border-radius:10px;font-size:13px;display:none;z-index:10000}
.alert.show{display:block}
</style>

<div class="ridie-wrap">
  <h1 class="h-title">Meus Pedidos</h1>

  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>Pedido</th><th>Certificado</th><th>Status</th><th>Agendamento</th><th>Total</th><th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): $id=intval($r['id']); ?>
          <!-- Linha principal (clicável para expandir) -->
          <tr class="row-main" data-toggle="details-<?= $id ?>">
            <td>
              <a href="/?page=order_view&id=<?= $id ?>" onclick="event.stopPropagation()" style="text-decoration:underline">
                #<?= sanitize($r['order_number']) ?>
              </a>
            </td>
            <td><?= sanitize($r['mname']) ?></td>
            <td><?= status_badge($r['status']) ?></td>
            <td><?= $r['scheduled_at'] ? date('d/m/Y H:i', strtotime($r['scheduled_at'])) : '-' ?></td>
            <td>R$ <?= number_format($r['total'], 2, ',', '.') ?></td>
            <td>
              <button class="btn js-show" data-target="details-<?= $id ?>" onclick="event.stopPropagation()">Detalhes</button>
              <?php if (!in_array($r['status'], ['protocol_assigned','completed'])): ?>
                <button class="btn js-edit" data-id="<?= $id ?>" onclick="event.stopPropagation()">Editar</button>
              <?php else: ?><span class="small">—</span><?php endif; ?>
            </td>
          </tr>

          <!-- Linha de detalhes (expande/retrai) -->
          <tr id="details-<?= $id ?>" class="row-details" style="display:none">
            <td colspan="6">
              <div class="details-card">
                <div class="kv">
                  <b>Certificado</b> <span><?= sanitize($r['mname']) ?><?= isset($r['mprice']) ? ' — R$ '.number_format($r['mprice'],2,',','.') : '' ?></span>
                  <b>Total</b>       <span>R$ <?= number_format($r['total'],2,',','.') ?></span>
                  <b>Status</b>      <span><?= strip_tags(status_badge($r['status'])) ?></span>
                  <b>Agendamento</b> <span><?= $r['scheduled_at'] ? date('d/m/Y H:i', strtotime($r['scheduled_at'])) : '-' ?></span>
                  <b>Protocolo</b>   <span><?= $r['protocol_number'] ? sanitize($r['protocol_number']) : '—' ?></span>
                </div>

                <div class="hr"></div>

                <div class="kv">
                  <b>Nome do Cliente</b> <span><?= sanitize($r['customer_name']) ?></span>
                  <b>CPF/CNPJ</b>        <span><?= sanitize($r['customer_cpf_cnpj']) ?></span>
                  <b>E-mail</b>          <span><?= sanitize($r['customer_email']) ?></span>
                  <b>Telefone</b>        <span><?= sanitize($r['customer_phone'] ?? '') ?></span>
                  <b>CNH</b>             <span>
                    <?php if (!empty($r['cnh_path'])): ?>
                      <a href="/?page=download_cnh&id=<?= $id ?>" target="_blank">baixar CNH</a>
                    <?php else: ?>—<?php endif; ?>
                  </span>
                </div>

                <div class="hr"></div>

                <div class="kv">
                  <b>MP Preference</b> <span><?= sanitize($r['mp_preference_id'] ?? '-') ?></span>
                  <b>MP Payment</b>    <span><?= sanitize($r['mp_payment_id'] ?? '-') ?></span>
                </div>

                <?php if (!in_array($r['status'], ['protocol_assigned','completed'])): ?>
                  <div class="hr"></div>
                  <button class="btn js-edit" data-id="<?= $id ?>">Editar este pedido</button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ===== Modal EDITAR (já existente) ===== -->
<div class="modal-mask" id="ridieEditMask" aria-hidden="true">
  <div class="modal-card">
    <form method="post" action="/?page=do_order_update" enctype="multipart/form-data" id="ridieEditForm">
      <div class="modal-head">
        <div>
          <div class="small" id="ridieOrderNumber">Pedido — </div>
          <strong id="ridieStatus" class="small"></strong>
        </div>
        <button type="button" class="btn" id="ridieClose">Fechar</button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="ridieOrderId">
        <div class="form-grid">
          <div>
            <label class="label">Nome do Cliente</label>
            <input class="input" type="text" name="customer_name" id="ridieName" required>
          </div>
          <div>
            <label class="label">CPF/CNPJ do Cliente</label>
            <input class="input" type="text" name="customer_cpf_cnpj" id="ridieDoc" required>
          </div>
          <div>
            <label class="label">E-mail</label>
            <input class="input" type="email" name="customer_email" id="ridieEmail">
          </div>
          <div>
            <label class="label">Telefone</label>
            <input class="input" type="text" name="customer_phone" id="ridiePhone">
          </div>
          <div class="full">
            <label class="label">CNH (opcional — enviar para substituir)</label>
            <input class="file" type="file" name="cnh" accept=".png,.jpg,.jpeg,.pdf">
            <div class="small" id="ridieCnhInfo"></div>
          </div>
          <div>
            <label class="label">Data do Agendamento</label>
            <input class="input" type="text" id="ridieDate" placeholder="Escolha a data" required>
            <input type="hidden" name="scheduled_at" id="ridieScheduledAt">
          </div>
          <div class="full">
            <label class="label">Horários disponíveis</label>
            <div id="ridieSlots" class="slot-row"></div>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <span class="small" id="ridieFootHint"></span>
        <div>
          <button class="btn primary" type="submit">Salvar alterações</button>
          <button class="btn" type="button" id="ridieCancel">Cancelar</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="alert" id="ridieAlert"></div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
<script>
(function(){
  const $ = (s, root=document)=>root.querySelector(s);
  const $$ = (s, root=document)=>Array.from(root.querySelectorAll(s));
  const statusMap = {'created':'Criado','pending_payment':'Aguardando pagamento','paid':'Pago','protocol_assigned':'Protocolo','completed':'Concluído'};
  const alertBox = $('#ridieAlert');
  function toast(t){ alertBox.textContent=t; alertBox.classList.add('show'); setTimeout(()=>alertBox.classList.remove('show'), 3200); }

  // Expandir/contrair detalhes (sem AJAX)
  document.addEventListener('click', function(e){
    const tr = e.target.closest('.row-main');
    const btn = e.target.closest('.js-show');
    let targetId = null;
    if (btn) targetId = btn.getAttribute('data-target');
    else if (tr) targetId = tr.getAttribute('data-toggle');
    if (targetId) {
      const row = document.getElementById(targetId);
      if (row) {
        row.style.display = (row.style.display==='none'||!row.style.display) ? 'table-row' : 'none';
      }
    }
  });

  // ====== EDITAR (usa order_info_json já existente) ======
  const editMask = $('#ridieEditMask'), form = $('#ridieEditForm');
  const dateInput = $('#ridieDate'), hiddenAt = $('#ridieScheduledAt'), slotsWrap = $('#ridieSlots');

  function renderSlots(list, current){
    slotsWrap.innerHTML='';
    if (!list || !list.length){ slotsWrap.textContent='Sem horários disponíveis nesta data.'; return; }
    list.forEach(s=>{
      const b=document.createElement('button');
      b.type='button'; b.className='slot-badge'+(s.available?'':' disabled'); b.textContent=s.label; b.dataset.value=s.value;
      if (s.available){
        b.addEventListener('click', ()=>{
          Array.from(slotsWrap.querySelectorAll('.slot-badge')).forEach(el=>el.classList.remove('active'));
          b.classList.add('active'); hiddenAt.value=s.value;
        });
      }
      if (current && s.value===current) b.classList.add('active');
      slotsWrap.appendChild(b);
    });
  }
  function loadSlots(iso, current){
    slotsWrap.textContent='Carregando...';
    fetch('/?page=slots&date='+encodeURIComponent(iso), {cache:'no-store'})
      .then(r=> r.ok ? r.json() : Promise.reject())
      .then(j=>{ if (j.weekend){ slotsWrap.textContent='Atendimento apenas de segunda a sexta.'; return; } renderSlots(j.slots, current); })
      .catch(()=> { slotsWrap.textContent='Erro ao carregar horários'; });
  }
  function setupDatepicker(initialISO, current){
    if (dateInput._flatpickr) dateInput._flatpickr.destroy();
    flatpickr(dateInput, {
      locale:'pt', dateFormat:'Y-m-d', minDate:'today',
      disable:[d=>{const g=d.getDay(); return (g===0||g===6);} ],
      onChange: function(_,str){ if (str){ hiddenAt.value=''; loadSlots(str, null); } }
    });
    dateInput._flatpickr.setDate(initialISO, true);
    loadSlots(initialISO, current);
  }

  function openEdit(id){
    form.reset(); slotsWrap.innerHTML=''; hiddenAt.value='';
    fetch('/?page=order_info_json&id='+encodeURIComponent(id), {cache:'no-store'})
      .then(r=> r.ok ? r.json() : Promise.reject())
      .then(o=>{
        if (o.error){ toast('Erro: '+o.error); return; }
        $('#ridieOrderId').value = o.id;
        $('#ridieOrderNumber').textContent = 'Pedido — #'+o.order_number;
        $('#ridieStatus').textContent = 'Status: '+(statusMap[o.status]||o.status);
        $('#ridieName').value = o.customer_name||'';
        $('#ridieDoc').value  = o.customer_cpf_cnpj||'';
        $('#ridieEmail').value= o.customer_email||'';
        $('#ridiePhone').value= o.customer_phone||'';
        $('#ridieCnhInfo').textContent = o.cnh_path ? ('Atual: '+o.cnh_path) : '';
        const current = o.scheduled_at;
        const initialISO = current ? current.substring(0,10) : (new Date()).toISOString().slice(0,10);
        hiddenAt.value = current || '';
        setupDatepicker(initialISO, current);
        editMask.classList.add('open');
      })
      .catch(()=> toast('Não foi possível carregar os dados do pedido.'));
  }

  document.addEventListener('click', function(e){
    const btn = e.target.closest('.js-edit');
    if (btn){
      openEdit(btn.getAttribute('data-id'));
    }
  });

  $('#ridieClose').onclick = ()=> editMask.classList.remove('open');
  $('#ridieCancel').onclick = ()=> editMask.classList.remove('open');
  editMask.addEventListener('click', e=>{ if(e.target===editMask) editMask.classList.remove('open'); });
})();
</script>
<?php
/* FOOTER (fallbacks) */
$__ftr = [
  __DIR__ . '/_footer.php',
  __DIR__ . '/../views/_footer.php',
  __DIR__ . '/../_footer.php',
  __DIR__ . '/partials/_footer.php'
];
foreach ($__ftr as $__p) { if (file_exists($__p)) { include $__p; break; } }
?>
