<?php
require_role('accountant');
$u = auth_user();
$id = intval($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o || $o['user_id'] != $u['id']) { redirect('/?page=orders_me'); }

// só permite editar se ainda não tiver protocolo atribuído
if (in_array($o['status'], ['protocol_assigned','completed'])) {
  redirect('/?page=orders_me');
}

// pega info do modelo
$stm = $pdo->prepare("SELECT id,name,price FROM certificate_models WHERE id=?");
$stm->execute([$o['model_id']]);
$m = $stm->fetch();

include __DIR__ . '/../views/_header.php';

function status_label($s){
  $map = [
    'created' => 'Criado',
    'pending_payment' => 'Aguardando pagamento',
    'paid' => 'Pago',
    'protocol_assigned' => 'Protocolo',
    'completed' => 'Concluído'
  ];
  return $map[$s] ?? ucfirst($s);
}
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
  .slot-badge { padding:.45rem .7rem; border:1px solid #ddd; border-radius:12px; margin:.25rem; display:inline-block; cursor:pointer; font-weight:500 }
  .slot-badge.disabled { opacity:.45; cursor:not-allowed }
  .slot-badge.active   { border-color:#0d6efd; background:#0d6efd; color:#fff }
</style>

<div class="container py-3">
  <h1 class="h5 mb-3">Editar Pedido — #<?= sanitize($o['order_number']) ?></h1>
  <div class="mb-3">
    <strong>Modelo:</strong> <?= sanitize($m['name'] ?? 'Certificado') ?> — R$ <?= number_format($o['total'],2,',','.') ?><br>
    <strong>Status:</strong> <?= status_label($o['status']) ?>
  </div>

  <form method="post" action="/?page=do_order_update" enctype="multipart/form-data" class="row g-3">
    <input type="hidden" name="id" value="<?= $o['id'] ?>">

    <div class="col-md-6">
      <label class="form-label">Nome do Cliente</label>
      <input class="form-control" type="text" name="customer_name" value="<?= sanitize($o['customer_name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">CPF/CNPJ do Cliente</label>
      <input class="form-control" type="text" name="customer_cpf_cnpj" value="<?= sanitize($o['customer_cpf_cnpj']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">E-mail</label>
      <input class="form-control" type="email" name="customer_email" value="<?= sanitize($o['customer_email']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Telefone</label>
      <input class="form-control" type="text" name="customer_phone" value <?= $o['customer_phone'] ? '="'.sanitize($o['customer_phone']).'"' : '=""' ?>>
    </div>

    <div class="col-md-6">
      <label class="form-label">CNH (opcional — enviar para substituir)</label>
      <input class="form-control" type="file" name="cnh" accept=".png,.jpg,.jpeg,.pdf">
      <?php if ($o['cnh_path']): ?>
        <small class="text-muted">Atual: <a href="/uploads/cnh/<?= sanitize($o['cnh_path']) ?>" target="_blank">baixar</a></small>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <label class="form-label">Data do Agendamento</label>
      <input class="form-control" type="text" id="scheduled_date" placeholder="Escolha a data" required>
      <input type="hidden" name="scheduled_at" id="scheduled_at" value="<?= $o['scheduled_at'] ? date('Y-m-d H:i:00', strtotime($o['scheduled_at'])) : '' ?>">
    </div>

    <div class="col-12">
      <label class="form-label">Horários disponíveis</label>
      <div id="slotsWrap" class="mt-1"></div>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit">Salvar alterações</button>
      <a class="btn btn-outline-secondary" href="/?page=orders_me">Cancelar</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
<script>
(function(){
  const dateInput = document.getElementById('scheduled_date');
  const hiddenAt  = document.getElementById('scheduled_at');
  const slotsWrap = document.getElementById('slotsWrap');

  function render(list){
    slotsWrap.innerHTML = '';
    if (!list || !list.length) { slotsWrap.textContent='Sem horários disponíveis nesta data.'; return; }
    const current = hiddenAt.value;
    list.forEach(s => {
      const b = document.createElement('button');
      b.type='button'; b.className='slot-badge'+(s.available?'':' disabled');
      b.textContent = s.label; b.dataset.value = s.value;
      if (s.available){
        b.addEventListener('click', ()=>{
          document.querySelectorAll('.slot-badge').forEach(el=>el.classList.remove('active'));
          b.classList.add('active'); hiddenAt.value=s.value;
        });
      }
      if (current && s.value===current) b.classList.add('active');
      slotsWrap.appendChild(b);
    });
  }

  function loadSlots(iso){
    slotsWrap.textContent = 'Carregando...';
    fetch('/?page=slots&date='+encodeURIComponent(iso), {cache:'no-store'})
      .then(r=>r.json())
      .then(j=>{
        if (j.weekend){ slotsWrap.textContent='Atendimento apenas de segunda a sexta.'; return; }
        render(j.slots);
      })
      .catch(_=> slotsWrap.textContent='Erro ao carregar horários');
  }

  // Inicial: usa a data do pedido, senão hoje/próximo dia útil
  let startIso = (hiddenAt.value ? hiddenAt.value.substring(0,10) : null);
  if (!startIso) {
    const now = new Date(); let start = new Date(now);
    if (now.getDay()===6) start.setDate(now.getDate()+2);
    if (now.getDay()===0) start.setDate(now.getDate()+1);
    startIso = start.toISOString().slice(0,10);
  }
  flatpickr(dateInput, {
    locale:'pt', dateFormat:'Y-m-d', minDate:'today',
    disable:[d=>{const g=d.getDay(); return (g===0||g===6);}],
    onChange: function(sel,str){ if (str){ hiddenAt.value=''; loadSlots(str); } }
  });
  dateInput._flatpickr.setDate(startIso,true);
  loadSlots(startIso);
})();
</script>
<?php include __DIR__ . '/../views/_footer.php'; ?>
