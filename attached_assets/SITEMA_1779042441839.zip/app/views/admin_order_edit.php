<?php
require_role('admin');

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o) redirect('/?page=admin_orders');

$stm = $pdo->prepare("SELECT id,name,price FROM certificate_models WHERE id=?");
$stm->execute([$o['model_id']]);
$m = $stm->fetch();

function status_label($s){
  $map = [
    'created'=>'Criado','pending_payment'=>'Aguardando pagamento','paid'=>'Pago',
    'protocol_assigned'=>'Protocolo','completed'=>'Concluído'
  ];
  return $map[$s] ?? ucfirst($s);
}

include __DIR__ . '/_header.php';
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
  .slot-badge{padding:.55rem .85rem;border:1px solid #e5e7eb;border-radius:12px;margin:.3rem;display:inline-block;cursor:pointer;font-weight:700}
  .slot-badge.disabled{opacity:.45;cursor:not-allowed}
  .slot-badge.active{border-color:#0d6efd;background:#0d6efd;color:#fff}
</style>

<div class="container py-3">
  <h1 class="h5 mb-3">Editar Pedido (Admin) — #<?= sanitize($o['order_number']) ?></h1>
  <div class="mb-3">
    <strong>Modelo:</strong> <?= sanitize($m['name'] ?? 'Certificado') ?> — R$ <?= number_format($o['total'],2,',','.') ?><br>
    <strong>Status atual:</strong> <?= status_label($o['status']) ?>
  </div>

  <form method="post" action="/?page=admin_do_order_update" enctype="multipart/form-data" class="row g-3">
    <input type="hidden" name="id" value="<?= $o['id'] ?>">

    <div class="col-md-6">
      <label class="form-label">Nome do Cliente</label>
      <input class="form-control" type="text" name="customer_name" value="<?= sanitize($o['customer_name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">CPF/CNPJ do Cliente</label>
      <input class="form-control" type="text" name="customer_cpf_cnpj" value="<?= sanitize($o['customer_cpf_cnpj']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">E-mail</label>
      <input class="form-control" type="email" name="customer_email" value="<?= sanitize($o['customer_email']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Telefone</label>
      <input class="form-control" type="text" name="customer_phone" value="<?= sanitize($o['customer_phone'] ?? '') ?>">
    </div>

    <div class="col-md-6">
      <label class="form-label">CNH (opcional — enviar para substituir)</label>
      <input class="form-control" type="file" name="cnh" accept=".png,.jpg,.jpeg,.pdf">
      <?php if ($o['cnh_path']): ?>
        <small class="text-muted">
          Atual: <a href="/?page=download_cnh&id=<?= $o['id'] ?>" target="_blank">baixar</a>
        </small>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <label class="form-label">Data do Agendamento</label>
      <input class="form-control" type="text" id="scheduled_date" placeholder="Escolha a data" required>
      <input type="hidden" name="scheduled_at" id="scheduled_at" value="<?= $o['scheduled_at'] ? date('Y-m-d H:i:00', strtotime($o['scheduled_at'])) : '' ?>">
    </div>

    <div class="col-12">
      <label class="form-label">Horários disponíveis</label>
      <div id="slotsWrap" class="mt-1"></div>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit">Salvar alterações</button>
      <a class="btn btn-outline-secondary" href="/?page=admin_order_view&id=<?= $o['id'] ?>">Cancelar</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
<script>
(function(){
  const dateInput = document.getElementById('scheduled_date');
  const hiddenAt  = document.getElementById('scheduled_at');
  const slotsWrap = document.getElementById('slotsWrap');

  function render(list){
    slotsWrap.innerHTML = '';
    if (!list || !list.length) { slotsWrap.textContent='Sem horários disponíveis nesta data.'; return; }
    const current = hiddenAt.value;
    list.forEach(s => {
      const b = document.createElement('button');
      b.type='button'; b.className='slot-badge'+(s.available?'':' disabled');
      b.textContent = s.label; b.dataset.value = s.value;
      if (s.available){
        b.addEventListener('click', ()=>{
          document.querySelectorAll('.slot-badge').forEach(el=>el.classList.remove('active'));
          b.classList.add('active'); hiddenAt.value=s.value;
        });
      }
      if (current && s.value===current) b.classList.add('active');
      slotsWrap.appendChild(b);
    });
  }

  function loadSlots(iso){
    slotsWrap.textContent = 'Carregando...';
    fetch('/?page=slots&date='+encodeURIComponent(iso), {cache:'no-store'})
      .then(r=>r.json())
      .then(j=>{
        if (j.weekend){ slotsWrap.textContent='Atendimento apenas de segunda a sexta.'; return; }
        render(j.slots);
      })
      .catch(_=> slotsWrap.textContent='Erro ao carregar horários');
  }

  // Inicial: usa a data atual do pedido
  let startIso = (hiddenAt.value ? hiddenAt.value.substring(0,10) : (new Date()).toISOString().slice(0,10));
  flatpickr(dateInput, {
    locale:'pt', dateFormat:'Y-m-d', minDate:'today',
    disable:[d=>{const g=d.getDay(); return (g===0||g===6);}],
    onChange: function(sel,str){ if (str){ hiddenAt.value=''; loadSlots(str); } }
  });
  dateInput._flatpickr.setDate(startIso,true);
  loadSlots(startIso);
})();
</script>
<?php include __DIR__ . '/_footer.php'; ?>
