<?php
require_role('accountant');

// Se vier com ?model_id=...
if (!isset($model)) {
  $model_id = intval($_GET['model_id'] ?? 0);
  $stmt = $pdo->prepare("SELECT * FROM certificate_models WHERE id=? AND active=1");
  $stmt->execute([$model_id]);
  $model = $stmt->fetch();
}
include __DIR__ . '/../views/_header.php';
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
  .slot-badge { padding:.45rem .7rem; border:1px solid #ddd; border-radius:12px; margin:.25rem; display:inline-block; cursor:pointer; font-weight:500 }
  .slot-badge.disabled { opacity:.45; cursor:not-allowed }
  .slot-badge.active   { border-color:#0d6efd; background:#0d6efd; color:#fff }
</style>

<div class="container py-3">
  <h1 class="h5 mb-3">Dados para Emissão — <?= sanitize($model['name'] ?? 'Certificado') ?></h1>

  <form method="post" action="/?page=do_new_order" enctype="multipart/form-data" id="orderForm" class="row g-3">
    <input type="hidden" name="model_id" value="<?= intval($model['id'] ?? 0) ?>">

    <div class="col-md-6">
      <label class="form-label">Nome do Cliente</label>
      <input class="form-control" type="text" name="customer_name" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">CPF/CNPJ do Cliente</label>
      <input class="form-control" type="text" name="customer_cpf_cnpj" required>
    </div>

    <div class="col-md-6">
      <label class="form-label">E-mail do Cliente</label>
      <input class="form-control" type="email" name="customer_email">
    </div>
    <div class="col-md-6">
      <label class="form-label">Telefone do Cliente</label>
      <input class="form-control" type="text" name="customer_phone">
    </div>

    <div class="col-md-6">
      <label class="form-label">CNH (imagem/PDF) — máx 5MB</label>
      <input class="form-control" type="file" name="cnh" accept=".png,.jpg,.jpeg,.pdf" required>
    </div>

    <div class="col-md-6">
      <label class="form-label">Data do Agendamento</label>
      <input class="form-control" type="text" id="scheduled_date" placeholder="Escolha a data" required>
      <input type="hidden" name="scheduled_at" id="scheduled_at">
    </div>

    <div class="col-12">
      <label class="form-label">Horários disponíveis</label>
      <div id="slotsWrap" class="mt-1"></div>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit">Salvar e Ir para Checkout</button>
      <a href="/?page=products" class="btn btn-outline-secondary">Cancelar</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
<script>
(function(){
  const dateInput = document.getElementById('scheduled_date');
  const hiddenAt  = document.getElementById('scheduled_at');
  const slotsWrap = document.getElementById('slotsWrap');

  function render(list){
    slotsWrap.innerHTML = '';
    if (!list || !list.length) {
      slotsWrap.textContent = 'Sem horários disponíveis nesta data.';
      hiddenAt.value = '';
      return;
    }
    list.forEach(s => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'slot-badge' + (s.available ? '' : ' disabled');
      b.textContent = s.label;
      b.dataset.value = s.value;
      if (s.available) {
        b.addEventListener('click', () => {
          document.querySelectorAll('.slot-badge').forEach(el => el.classList.remove('active'));
          b.classList.add('active');
          hiddenAt.value = s.value; // YYYY-MM-DD HH:MM:00
        });
      }
      slotsWrap.appendChild(b);
    });
  }

  function loadSlots(isoDate){
    slotsWrap.textContent = 'Carregando...';
    fetch('/?page=slots&date=' + encodeURIComponent(isoDate), {cache:'no-store'})
      .then(r => r.json())
      .then(json => {
        if (json.weekend) {
          slotsWrap.textContent = 'Atendimento apenas de segunda a sexta.';
          hiddenAt.value = '';
          return;
        }
        render(json.slots);
      })
      .catch(_ => { slotsWrap.textContent = 'Erro ao carregar horários'; });
  }

  flatpickr(dateInput, {
    locale: 'pt',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disable: [ function(date){ const d = date.getDay(); return (d===0 || d===6); } ],
    onChange: function(sel, str){ if (str){ hiddenAt.value=''; loadSlots(str); } }
  });

  // Valor inicial: hoje ou próximo dia útil
  const now = new Date();
  let start = new Date(now);
  if (now.getDay() === 6) start.setDate(now.getDate()+2); // sábado -> segunda
  if (now.getDay() === 0) start.setDate(now.getDate()+1); // domingo -> segunda
  const iso = start.toISOString().slice(0,10);
  dateInput._flatpickr.setDate(iso, true);
  loadSlots(iso);
})();
</script>
<?php include __DIR__ . '/../views/_footer.php'; ?>
