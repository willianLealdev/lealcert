<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
$u    = auth_user();
$role = $u['role'] ?? '';
$curr = $_GET['page'] ?? '';

function is_active($curr, $names) {
  if (!is_array($names)) $names = [$names];
  return in_array($curr, $names, true) ? 'active' : '';
}

$badgeCount = 0;
if ($u) {
  try {
    if ($role === 'admin') {
      $q = $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE unread_admin=1 AND status!='finalizado'");
      $badgeCount = (int)$q->fetchColumn();
    } else {
      $st = $pdo->prepare("SELECT COUNT(*) FROM support_tickets WHERE user_id=? AND unread_client=1 AND status!='finalizado'");
      $st->execute([(int)$u['id']]);
      $badgeCount = (int)$st->fetchColumn();
    }
  } catch (Throwable $e) {
    $badgeCount = 0;
  }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= sanitize(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/custom.css" rel="stylesheet">
  <style>
    .navbar .navbar-nav { margin-left: auto; margin-right: auto; }
    .brand { font-weight: 700; letter-spacing: .5px; }
    .nav-emoji { width: 1.25rem; display:inline-block; text-align:center; }
    .avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; border: 1px solid rgba(0,0,0,.1); }
    .badge-dot { display:inline-block; min-width:1.25rem; padding:.25em .5em; font-size:.75rem; }
  </style>
  <script src="/assets/js/ridie_agenda_boot.js?v=1"></script>
</head>
<body class="d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand brand" href="/?page=<?= $u && $role==='admin' ? 'admin_dashboard' : 'contador_dashboard' ?>">
      <?= sanitize(APP_NAME) ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="nav">
      <?php if ($u): ?>
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <?php if ($role==='admin'): ?>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'admin_dashboard') ?>" href="/?page=admin_dashboard"><span class="nav-emoji">🏠</span> Dashboard</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'admin_orders') ?>" href="/?page=admin_orders"><span class="nav-emoji">📦</span> Pedidos</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'admin_models') ?>" href="/?page=admin_models"><span class="nav-emoji">🧩</span> Modelos</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,['admin_users','admin_user_edit']) ?>" href="/?page=admin_users"><span class="nav-emoji">👥</span> Usuários</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'admin_slots') ?>" href="/?page=admin_slots"><span class="nav-emoji">🗓️</span> Agenda</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'contador_dashboard') ?>" href="/?page=contador_dashboard"><span class="nav-emoji">🏠</span> Dashboard</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,'products') ?>" href="/?page=products"><span class="nav-emoji">🛒</span> Comprar Certificado</a></li>
          <li class="nav-item"><a class="nav-link <?= is_active($curr,['orders_me','order_detail']) ?>" href="/?page=orders_me"><span class="nav-emoji">📄</span> Meus Pedidos</a></li>
        <?php endif; ?>

        <li class="nav-item">
          <a class="nav-link <?= is_active($curr, ['support','support_new','support_view']) ?>" href="/?page=support">
            <span class="nav-emoji">🆘</span> Suporte
            <?php if ($badgeCount > 0): ?>
              <span class="badge text-bg-danger badge-dot"><?= $badgeCount ?></span>
            <?php endif; ?>
          </a>
        </li>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <a class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-2" href="/?page=profile" title="Meu Perfil">
          <?php if (!empty($u['avatar_path'])): ?>
            <img class="avatar" src="/<?= ltrim($u['avatar_path'],'/') ?>" alt="avatar">
          <?php else: ?>
            <span class="nav-emoji">🧑</span>
          <?php endif; ?>
          <span class="d-none d-md-inline"><?= sanitize($u['name'] ?? '') ?></span>
        </a>
        <a class="btn btn-outline-danger btn-sm" href="/?page=logout">Sair</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</nav>

<div class="container py-4 flex-grow-1">
