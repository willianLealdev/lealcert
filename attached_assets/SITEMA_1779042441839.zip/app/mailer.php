<?php
// app/mailer.php — versão estável com fallback e logs detalhados

/* ---------- Escape seguro ---------- */
if (!function_exists('ridie_h')) {
  function ridie_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

/* ---------- Base URL ---------- */
if (!function_exists('ridie_base_url')) {
  function ridie_base_url(): string {
    if (defined('SITE_URL') && SITE_URL !== '') return rtrim(SITE_URL, '/');
    $env = getenv('SITE_URL'); if ($env) return rtrim($env, '/');
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme.'://'.$host;
  }
}

/* ---------- Envio via mail() com Fallback ---------- */
if (!function_exists('send_mail')) {
  function send_mail(string $to, string $subject, string $html): bool {
    $siteUrl   = (defined('SITE_URL') && SITE_URL !== '') ? SITE_URL : (getenv('SITE_URL') ?: '');
    $host      = parse_url($siteUrl, PHP_URL_HOST) ?: 'localhost';
    $fromHdr   = getenv('MAIL_FROM') ?: ('REDIECERT <no-reply@'.$host.'>');
    $forceNoF  = (string)getenv('MAIL_FORCE_NO_ENVELOPE') === '1';
    $debugOut  = (string)getenv('MAIL_DEBUG') === '1';

    if (preg_match('/<([^>]+)>/', $fromHdr, $m)) { $fromEmail = $m[1]; } else { $fromEmail = $fromHdr; }

    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: {$fromHdr}\r\n";
    $headers .= "Reply-To: {$fromEmail}\r\n";
    @ini_set('sendmail_from', $fromEmail);

    $encSubject = '=?UTF-8?B?'.base64_encode($subject).'?=';

    $okA = false; $okB = false;
    $lastErrA = ''; $lastErrB = '';

    if (!$forceNoF) {
      $okA = @mail($to, $encSubject, $html, $headers, "-f{$fromEmail}");
      $err = error_get_last();
      if ($err && !$okA) $lastErrA = (string)($err['message'] ?? '');
    }

    if ($forceNoF || !$okA) {
      $okB = @mail($to, $encSubject, $html, $headers);
      $err = error_get_last();
      if ($err && !$okB) $lastErrB = (string)($err['message'] ?? '');
    }

    $ok = $okA || $okB;

    $logDir = __DIR__.'/../storage';
    if (!is_dir($logDir)) @mkdir($logDir, 0775, true);
    $log  = date('c')
          ." to=$to subj=$subject ok=".($ok?'1':'0')
          ." tryA=".($okA?'1':'0')." errA=".preg_replace('/\s+/', ' ', $lastErrA)
          ." tryB=".($okB?'1':'0')." errB=".preg_replace('/\s+/', ' ', $lastErrB)
          ." sendmail_path=".ini_get('sendmail_path')
          ." MAIL_FROM=".$fromHdr
          ."\n";
    @file_put_contents($logDir.'/mail.log', $log, FILE_APPEND);

    if ($debugOut) {
      $out = __DIR__.'/../storage/mail_outbox';
      if (!is_dir($out)) @mkdir($out, 0775, true);
      $file = $out.'/'.date('Ymd_His').'_'.preg_replace('/[^a-z0-9]+/i','_', $to).'.html';
      @file_put_contents($file, $html);
    }

    return $ok;
  }
}

/* =========================
   E-mail: Protocolo
   ========================= */
if (!function_exists('notify_protocol_assigned')) {
  function notify_protocol_assigned(PDO $pdo, int $orderId): bool {
    $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
    $st->execute([$orderId]);
    $o = $st->fetch(PDO::FETCH_ASSOC);
    if (!$o) return false;

    $ust = $pdo->prepare("SELECT name,email FROM users WHERE id=?");
    $ust->execute([(int)$o['user_id']]);
    $u = $ust->fetch(PDO::FETCH_ASSOC);
    if (!$u || !filter_var($u['email']??'', FILTER_VALIDATE_EMAIL)) return false;

    $orderNo   = $o['order_number'] ?: ('#'.$orderId);
    $when      = !empty($o['scheduled_at']) ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '—';
    $proto     = trim($o['protocol_number'] ?? '');
    $detailUrl = ridie_base_url().'/?page=order_detail&id='.$orderId;
    $app       = defined('APP_NAME') ? APP_NAME : 'REDIECERT';

    $html =
      '<div style="background:#f6f9fc;padding:24px 0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;">
         <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
           <tr><td align="center">
             <table width="600" cellspacing="0" cellpadding="0" style="max-width:600px;background:#ffffff;border-radius:12px;box-shadow:0 6px 18px rgba(16,24,40,.08);overflow:hidden">
               <tr><td style="padding:28px 32px">
                 <h1 style="margin:0 0 8px;font-size:22px;line-height:1.3;color:#111827">Protocolo liberado 🎉</h1>
                 <p style="margin:0 0 18px;color:#4b5563;font-size:14px">Olá, '.ridie_h($u['name'] ?? '').'</p>
                 <p style="margin:0 0 10px;color:#374151;font-size:15px">
                   O pedido <strong>#'.ridie_h($orderNo).'</strong> foi atualizado para <strong>Protocolo</strong>.
                 </p>
                 <div style="margin:14px 0 8px;padding:14px 16px;border:1px dashed #d1d5db;border-radius:10px;background:#f9fafb">
                   <div style="color:#6b7280;font-size:12px;margin-bottom:4px">PROTOCOLO</div>
                   <div style="font-size:20px;letter-spacing:.5px;color:#111827"><strong>'.ridie_h($proto ?: '—').'</strong></div>
                 </div>
                 <p style="margin:10px 0 16px;color:#374151;font-size:14px"><strong>Data/horário para emissão:</strong> '.ridie_h($when).'</p>
                 <p style="margin:0 0 18px;color:#374151;font-size:14px">
                   Guarde este protocolo — ele será solicitado no processo de <strong>validação e emissão</strong>.
                 </p>
                 <p style="text-align:center;margin:24px 0 6px">
                   <a href="'.ridie_h($detailUrl).'"
                      style="display:inline-block;background:#1e66f5;color:#fff;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:600;font-size:14px">
                     Ver detalhes do pedido
                   </a>
                 </p>
                 <hr style="border:none;border-top:1px solid #e5e7eb;margin:22px 0">
                 <p style="margin:16px 0 0;color:#111827;font-size:14px">Abraços,<br><strong>'.ridie_h($app).'</strong></p>
               </td></tr>
             </table>
           </td></tr>
         </table>
       </div>';

    return send_mail($u['email'], "Protocolo disponível — Pedido {$orderNo}", $html);
  }
}

/* =========================
   E-mail: Certificado Concluído (com código chave)
   ========================= */
if (!function_exists('notify_codigo_concluido')) {
  function notify_codigo_concluido(PDO $pdo, int $orderId): bool {
    $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
    $st->execute([$orderId]);
    $o = $st->fetch(PDO::FETCH_ASSOC);
    if (!$o) return false;

    $ust = $pdo->prepare("SELECT name,email FROM users WHERE id=?");
    $ust->execute([(int)$o['user_id']]);
    $u = $ust->fetch(PDO::FETCH_ASSOC);
    if (!$u || !filter_var($u['email']??'', FILTER_VALIDATE_EMAIL)) return false;

    $orderNo = $o['order_number'] ?: ('#'.$orderId);
    $proto   = trim($o['protocol_number'] ?? '—');
    $codigo  = trim($o['codigo_chave'] ?? '—');
    $app     = defined('APP_NAME') ? APP_NAME : 'REDIECERT';

    $html =
      '<div style="background:#f6f9fc;padding:24px 0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;">
         <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
           <tr><td align="center">
             <table width="600" cellspacing="0" cellpadding="0" style="max-width:600px;background:#ffffff;border-radius:12px;box-shadow:0 6px 18px rgba(16,24,40,.08);overflow:hidden">
               <tr><td style="padding:28px 32px">
                 <h1 style="margin:0 0 8px;font-size:22px;line-height:1.3;color:#111827">Certificado Concluído 🎉</h1>
                 <p style="margin:0 0 18px;color:#4b5563;font-size:14px">Olá, '.ridie_h($u['name'] ?? '').'</p>
                 <p style="margin:0 0 10px;color:#374151;font-size:15px">
                   Seu pedido <strong>#'.ridie_h($orderNo).'</strong> foi concluído com sucesso.
                 </p>
                 <div style="margin:14px 0 8px;padding:14px 16px;border:1px dashed #d1d5db;border-radius:10px;background:#f9fafb">
                   <div style="color:#6b7280;font-size:12px;margin-bottom:4px">PROTOCOLO</div>
                   <div style="font-size:20px;letter-spacing:.5px;color:#111827"><strong>'.ridie_h($proto).'</strong></div>
                 </div>
                 <div style="margin:14px 0 8px;padding:14px 16px;border:1px dashed #10b981;border-radius:10px;background:#ecfdf5">
                   <div style="color:#059669;font-size:12px;margin-bottom:4px">CÓDIGO 🔑</div>
                   <div style="font-size:20px;letter-spacing:.5px;color:#065f46"><strong>'.ridie_h($codigo).'</strong></div>
                 </div>
                 <p style="margin:10px 0 16px;color:#374151;font-size:14px">
                   Obrigado por realizar o seu certificado conosco!<br>
                   Endereço para emissão: <a href="https://mp.syngularid.com.br">https://mp.syngularid.com.br</a>
                 </p>
                 <hr style="border:none;border-top:1px solid #e5e7eb;margin:22px 0">
                 <p style="margin:16px 0 0;color:#111827;font-size:14px">Abraços,<br><strong>'.ridie_h($app).'</strong></p>
               </td></tr>
             </table>
           </td></tr>
         </table>
       </div>';

    return send_mail($u['email'], "Certificado Concluído — Pedido {$orderNo}", $html);
  }
}
