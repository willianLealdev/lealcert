<?php
require_role('admin');
include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Novo Modelo</h1>
<form method="post" action="/?page=admin_model_save">
  <div class="mb-3"><label class="form-label">Nome</label><input name="name" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Descrição</label><textarea name="description" class="form-control" rows="4"></textarea></div>
  <div class="mb-3"><label class="form-label">Preço (R$)</label><input name="price" type="number" step="0.01" class="form-control" required></div>
  <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="active" checked><label class="form-check-label">Ativo</label></div>
  <button class="btn btn-primary">Salvar</button>
</form>
<?php include __DIR__ . '/../views/_footer.php'; ?>
