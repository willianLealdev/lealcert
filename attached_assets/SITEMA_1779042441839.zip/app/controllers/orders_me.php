<?php
// app/controllers/orders_me.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

$u = auth_user(); $userId = (int)$u['id'];
$p = max(1,(int)($_GET['p']??1)); $perPage=20; $offset=($p-1)*$perPage;

/* total */
$stc = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id=?");
$stc->execute([$userId]);
$totalRows = (int)$stc->fetchColumn();
$totalPages = max(1,(int)ceil($totalRows/$perPage));

/* page rows */
$st = $pdo->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
$st->execute([$userId]);
$orders = $st->fetchAll();

include __DIR__ . '/../views/_header.php';

function om_status_label($s) {
  return [
    'created'           => 'Criado',
    'pending_payment'   => 'Aguardando pagamento',
    'paid'              => 'Pago',
    'protocol_assigned' => 'Protocolo',
    'completed'         => 'Concluído',
  ][$s] ?? $s;
}
function esc($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Meus Pedidos</h1>
  <a class="btn btn-outline-secondary" href="/?page=products">Comprar certificado</a>
</div>

<div class="table-responsive">
  <table class="table table-sm align-middle">
    <thead class="table-light">
      <tr>
        <th>#</th><th>Pedido</th><th>Cliente</th><th>Doc</th><th>Razão/CNPJ</th>
        <th>Agendamento</th><th>Total</th><th>Protocolo</th><th>Status</th><th class="text-end">Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$orders): ?>
        <tr><td colspan="10" class="text-center text-muted py-4">Nenhum pedido.</td></tr>
      <?php else: foreach ($orders as $o):
        $ag   = $o['scheduled_at'] ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '—';
        $tot  = number_format((float)$o['total'], 2, ',', '.');
        $stat = $o['status']; $prot = $o['protocol_number'] ?: '—';
      ?>
      <tr>
        <td><?= (int)$o['id'] ?></td>
        <td><?= esc($o['order_number']) ?></td>
        <td><?= esc($o['customer_name']) ?></td>
        <td><?= esc($o['customer_cpf_cnpj'] ?: '—') ?></td>
        <td><?= esc(($o['RAZAOSOCIAL'] ?: '—') . ($o['CNPJ'] ? ' / '.$o['CNPJ'] : '')) ?></td>
        <td><?= esc($ag) ?></td>
        <td>R$ <?= $tot ?></td>
        <td><?= esc($prot) ?></td>
        <td><?= esc(om_status_label($stat)) ?></td>
        <td class="text-end">
          <div class="btn-group btn-group-sm">
            <?php if ($stat === 'protocol_assigned'): ?>
              <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$o['id'] ?>">Detalhes</a>
            <?php else: ?>
              <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$o['id'] ?>">Detalhes</a>
              <?php if ($stat === 'pending_payment'): ?>
                <a class="btn btn-outline-success" href="/?page=pay&id=<?= (int)$o['id'] ?>" target="">Checkout</a>
              <?php endif; ?>
              <a class="btn btn-outline-primary" href="/?page=order_edit&id=<?= (int)$o['id'] ?>">Editar</a>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php if ($totalPages>1): ?>
<nav aria-label="Paginação">
  <ul class="pagination justify-content-center">
    <?php $base='/?page=orders_me&p='; for($i=1;$i<=$totalPages;$i++): ?>
      <li class="page-item <?= $i===$p?'active':'' ?>"><a class="page-link" href="<?= $base.$i ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<?php include __DIR__ . '/../views/_footer.php';
