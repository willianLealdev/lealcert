<?php

// app/controllers/new_order.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

/* ===== helpers ===== */
function table_exists(PDO $pdo, string $t): bool { try { $pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true; } catch(Throwable $e){ return false; } }
function col_exists(PDO $pdo, string $t, string $c): bool { try { return (bool)$pdo->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->fetch(); } catch(Throwable $e){ return false; } }

/* Conversor robusto de preço: aceita "90", "90.00", "90,00", "1.234,56", "1,234.56" */
function parse_price($v): float {
  if (is_numeric($v)) return (float)$v;
  $s = preg_replace('/[^\d,.\-]/', '', (string)$v);
  if ($s === '' || $s === null) return 0.0;

  $hasDot   = strpos($s, '.') !== false;
  $hasComma = strpos($s, ',') !== false;

  if ($hasComma && !$hasDot) {
    // "90,00" → decimal = vírgula
    $s = str_replace('.', '', $s);     // (se vier com milhares, remove)
    $s = str_replace(',', '.', $s);   // vírgula como decimal
    return (float)$s;
  }
  if ($hasDot && !$hasComma) {
    // "90.00" → decimal = ponto (não remove o ponto!)
    return (float)$s;
  }
  if ($hasDot && $hasComma) {
    // Tem os dois. O último separador é o decimal.
    $lastDot    = strrpos($s, '.');
    $lastComma = strrpos($s, ',');
    if ($lastComma > $lastDot) {
      // "1.234,56" → decimal = vírgula; ponto é milhar
      $s = str_replace('.', '', $s);
      $s = str_replace(',', '.', $s);
      return (float)$s;
    } else {
      // "1,234.56" → decimal = ponto; vírgula é milhar
      $s = str_replace(',', '', $s);
      return (float)$s;
    }
  }
  // fallback
  return (float)$s;
}

/* ===== Modelo selecionado ===== */
$model_id = isset($_GET['model_id']) ? (int)$_GET['model_id'] : 0;
if ($model_id <= 0) { http_response_code(400); echo "Modelo inválido."; exit; }

$tbl = table_exists($pdo,'certificate_models') ? 'certificate_models' : (table_exists($pdo,'products') ? 'products' : null);
if (!$tbl) { http_response_code(500); echo "Tabela de modelos não encontrada."; exit; }

$nameCol  = 'name';  foreach (['name','title','label','descricao'] as $c)  if (col_exists($pdo,$tbl,$c)) { $nameCol=$c; break; }
$priceCol = 'price'; foreach (['price','valor','amount','preco','value'] as $c) if (col_exists($pdo,$tbl,$c)) { $priceCol=$c; break; }

$stm = $pdo->prepare("SELECT id, `$nameCol` AS name, `$priceCol` AS price FROM `$tbl` WHERE id=?");
$stm->execute([$model_id]);
$model = $stm->fetch(PDO::FETCH_ASSOC);
if (!$model) { http_response_code(404); echo "Modelo não encontrado."; exit; }

/* ===== Heurística do tipo ===== */
$rawName   = mb_strtolower((string)$model['name']);
$isCNPJ    = (strpos($rawName,'cnpj') !== false) || (strpos($rawName,'pj') !== false) || (strpos($rawName,'empresa') !== false);
$modelType = $isCNPJ ? 'cnpj' : 'cpf';

/* ===== Garantia estendida via GET ===== */
$extw = (isset($_GET['extw']) && $_GET['extw'] === '1');

/* preço base robusto */
$base_price = parse_price($model['price'] ?? 0);
$total_view = $base_price + ($extw ? 15.00 : 0.00);

include __DIR__ . '/../views/_header.php';
?>


<div class="row g-3 mb-3">
  <div class="col-md-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-muted small">Produto</div>
            <div class="fw-semibold"><?= sanitize($model['name']) ?></div>
          </div>
          <div class="text-end">
            <div class="text-muted small">Preço base</div>
            <div class="fw-semibold">R$ <?= number_format($base_price, 2, ',', '.') ?></div>
          </div>
        </div>
        <?php if ($extw): ?>
          <hr>
          <div class="d-flex justify-content-between">
            <div><span class="badge text-bg-primary">Garantia estendida</span></div>
            <div>+ R$ <?= number_format(15.00, 2, ',', '.') ?></div>
          </div>
        <?php endif; ?>
        <hr>
        <div class="d-flex justify-content-between fw-bold">
          <div>Total estimado</div>
          <div>R$ <?= number_format($total_view, 2, ',', '.') ?></div>
        </div>
        <div class="small text-muted mt-2">
          O valor final exibido no checkout considera os itens acima.
        </div>
      </div>
    </div>
  </div>
</div>
<h1 class="h5 mb-3">Dados para Emissão </h1>
<form id="newOrderForm" method="post" action="/?page=do_new_order" enctype="multipart/form-data" class="row g-3" autocomplete="off">
  <input type="hidden" name="model_id" value="<?= (int)$model['id'] ?>">
  <input type="hidden" name="model_type" value="<?= $modelType ?>">
  <input type="hidden" name="schedule_at" id="schedule_at">
  <input type="hidden" name="extended_warranty" value="<?= $extw ? '1' : '0' ?>">
  <input type="hidden" name="MAX_FILE_SIZE" value="2097152">

  <div class="col-md-6">
    <label class="form-label">Nome do Cliente <span class="text-danger">*</span></label>
    <input type="text" name="client_name" class="form-control" required>
  </div>

  <div class="col-md-6">
    <label class="form-label">CPF do Titular <span class="text-danger">*</span></label>
    <input type="text" name="client_cpf" id="client_cpf" class="form-control" inputmode="numeric" maxlength="14" required>
    <div class="form-text">Formato: 000.000.000-00</div>
  </div>

  <!-- Empresa (obrigatório só se CNPJ) -->
  <div class="col-md-6 company-fields">
    <label class="form-label">Razão Social (Empresa) <span class="text-danger company-req">*</span></label>
    <input type="text" name="company_name" id="company_name" class="form-control">
  </div>
  <div class="col-md-6 company-fields">
    <label class="form-label">CNPJ da Empresa <span class="text-danger company-req">*</span></label>
    <input type="text" name="company_cnpj" id="company_cnpj" class="form-control" inputmode="numeric" maxlength="18">
    <div class="form-text">Formato: 00.000.000/0001-00</div>
  </div>

  <div class="col-md-6">
    <label class="form-label">E-mail do Cliente <span class="text-danger">*</span></label>
    <input type="email" name="client_email" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Telefone do Cliente <span class="text-danger">*</span></label>
    <input type="text" name="client_phone" class="form-control" required>
    <div class="form-text">Contato para videoconferência.</div>
  </div>

  

  <div class="col-md-6">
    <label class="form-label">Número INSS (CEI/CAEPF/CNO) <small class="text-muted">(opcional)</small></label>
    <input type="text" name="inss_number" class="form-control" placeholder="Ex.: 12.345.67890/12">
  </div>

  <div class="col-md-6">
    <label class="form-label">CNH (PDF) — máx 2MB <span class="text-danger">*</span></label>
    <input type="file" name="cnh_file" id="cnh_file" class="form-control" accept="application/pdf" required>
    <div id="cnhHelp" class="form-text">Apenas arquivo PDF é aceito.</div>
  </div>

  <div class="col-md-3">
    <label class="form-label">Data do Agendamento (Pode ocorrer alteracoes na data) <span class="text-danger">*</span></label>
    <input type="date" id="ridie-date" name="schedule_date" class="form-control" required>
  </div>
  <div class="col-12">
    <label class="form-label d-block">Horários disponíveis <span class="text-danger">*</span></label>
    <div id="ridie-slot-list" class="d-flex flex-wrap gap-2"></div>
    <input type="hidden" id="ridie-time" name="schedule_time">
    <div id="slotHelp" class="form-text text-danger" style="display:none;">Selecione um horário disponível.</div>
  </div>
  
  <!-- NOVOS CAMPOS DE ENDEREÇO -->
  <div class="col-12"><h4 class="h6 text-muted mt-3">Dados para o Boleto de Cobrança</h4></div>
  <div class="col-md-3">
    <label for="address_zipcode" class="form-label">CEP <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_zipcode" name="address_zipcode" required maxlength="9" oninput="this.value = this.value.replace(/\D/g,'')">
  </div>
  <div class="col-md-6">
    <label for="address_street" class="form-label">Rua <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_street" name="address_street" required>
  </div>
  <div class="col-md-3">
    <label for="address_number" class="form-label">Número <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_number" name="address_number" required>
  </div>
  <div class="col-md-4">
    <label for="address_neighborhood" class="form-label">Bairro <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_neighborhood" name="address_neighborhood" required>
  </div>
  <div class="col-md-5">
    <label for="address_city" class="form-label">Cidade <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_city" name="address_city" required>
  </div>
  <div class="col-md-3">
    <label for="address_state" class="form-label">UF <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="address_state" name="address_state" required maxlength="2" oninput="this.value = this.value.toUpperCase()">
  </div>

  <div class="col-12 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Salvar e Ir para Checkout</button>
    <a class="btn btn-outline-secondary" href="/?page=products">Cancelar</a>
  </div>
</form>

<script>
(function(){
  function onlyDigits(s){ return (s||'').replace(/\D+/g,''); }

  function maskCPF(v){
    v = onlyDigits(v).slice(0,11);
    v = v.replace(/^(\d{3})(\d)/, '$1.$2');
    v = v.replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
    v = v.replace(/^(\d{3})\.(\d{3})\.(\d{3})(\d{1,2})$/, '$1.$2.$3-$4');
    return v;
  }
  function maskCNPJ(v){
    v = onlyDigits(v).slice(0,14);
    v = v.replace(/^(\d{2})(\d)/, '$1.$2');
    v = v.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
    v = v.replace(/^(\d{2})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3/$4');
    v = v.replace(/^(\d{2})\.(\d{3})\.(\d{3})\/(\d{4})(\d{1,2})$/, '$1.$2.$3/$4-$5');
    return v;
  }

  document.addEventListener('DOMContentLoaded', function(){
    const cpfEl  = document.getElementById('client_cpf');
    const cnpjEl = document.getElementById('company_cnpj');
    if (cpfEl)  cpfEl.addEventListener('input', e => e.target.value = maskCPF(e.target.value));
    if (cnpjEl) cnpjEl.addEventListener('input', e => e.target.value = maskCNPJ(e.target.value));

    const MODEL_TYPE = '<?= $modelType ?>';
    const companyFields = document.querySelectorAll('.company-fields');
    const companyName = document.getElementById('company_name');
    const companyCnpj = document.getElementById('company_cnpj');
    function applyCompanyReq(){
      const isCNPJ = (MODEL_TYPE==='cnpj');
      companyFields.forEach(el => el.style.display = isCNPJ ? '' : 'none');
      if (companyName) companyName.required = isCNPJ;
      if (companyCnpj) companyCnpj.required = isCNPJ;
    }
    applyCompanyReq();

    function isWeekend(d){ const w=d.getDay(); return w===0||w===6; }
    function nextBusinessDay(from){
      let d=new Date(from.getFullYear(),from.getMonth(),from.getDate()+1);
      while(isWeekend(d)) d.setDate(d.getDate()+1);
      return d;
    }
    function fmtISO(d){ return d.toISOString().slice(0,10); }

    const dateEl = document.getElementById('ridie-date');
    const listEl = document.getElementById('ridie-slot-list');
    const timeEl = document.getElementById('ridie-time');
    const schedAtEl = document.getElementById('schedule_at');
    const slotHelp = document.getElementById('slotHelp');

    const today = new Date();
    const minDate = nextBusinessDay(today);
    const minDateStr = fmtISO(minDate);

    dateEl.min = minDateStr;
    if (!dateEl.value) dateEl.value = minDateStr;

    function makeBtn(hh,mm){
      const btn = document.createElement('button');
      btn.type='button';
      btn.className='btn btn-outline-secondary btn-sm';
      btn.textContent = `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
      btn.addEventListener('click', ()=>{
        listEl.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        timeEl.value = btn.textContent;
        slotHelp.style.display = 'none';
        updateScheduleAt();
      });
      return btn;
    }
    function renderSlots(){
      const v = dateEl.value; listEl.innerHTML=''; timeEl.value='';
      if (!v) return;
      const d = new Date(v+'T00:00:00');
      if (isWeekend(d)){ listEl.innerHTML = '<div class="text-muted">Sem horários aos sábados e domingos.</div>'; return; }
      let startMin = 9*60, endMin = 15*60, step=30;
      if (v === minDateStr) startMin = 12*60; // dia seguinte: só depois de 12h
      for(let m=startMin; m<=endMin; m+=step){
        const hh = Math.floor(m/60), mm = m%60;
        listEl.appendChild(makeBtn(hh,mm));
      }
      updateScheduleAt();
    }
    function updateScheduleAt(){
      const d = dateEl.value, t = timeEl.value || '';
      schedAtEl.value = (d && t) ? `${d} ${t}:00` : '';
    }
    dateEl.addEventListener('change', ()=>{ renderSlots(); updateScheduleAt(); });
    renderSlots();

    // validação inline da CNH (PDF <= 2MB)
    const cnh = document.getElementById('cnh_file');
    const cnhHelp = document.getElementById('cnhHelp');
    if (cnh) cnh.addEventListener('change', function(){
      cnhHelp.classList.remove('text-danger');
      cnhHelp.textContent = 'Apenas arquivo PDF é aceito.';
      if (!cnh.files || !cnh.files[0]) return;
      const file = cnh.files[0];
      const ext  = (file.name.split('.').pop()||'').toLowerCase();
      if (ext !== 'pdf'){
        cnhHelp.textContent = 'A CNH deve ser enviada em PDF.';
        cnhHelp.classList.add('text-danger');
        cnh.value = '';
      } else if (file.size > 2*1024*1024){
        cnhHelp.textContent = 'Arquivo de CNH acima de 2MB. Reduza o tamanho.';
        cnhHelp.classList.add('text-danger');
        cnh.value = '';
      }
    });

    const form = document.getElementById('newOrderForm');
    form.addEventListener('submit', function(){
      updateScheduleAt();
      if (!timeEl.value) { slotHelp.style.display = 'block'; }
    });
  });
})();
</script>

<?php include __DIR__ . '/../views/_footer.php'; ?>
