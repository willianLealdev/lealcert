<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php'; // config já carrega mailer

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function only_digits_local($s){ return preg_replace('/\D+/', '', (string)$s); }
function col_exists(PDO $pdo, string $table, string $col): bool {
  try { $q=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?"); $q->execute([$col]); return (bool)$q->fetch(); }
  catch(Throwable $e){ return false; }
}

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  header('Location: /?page=register'); exit;
}

// Campos
$name         = trim($_POST['name'] ?? '');
$email        = trim($_POST['email'] ?? '');
$cpf_cnpj     = only_digits_local($_POST['cpf_cnpj'] ?? '');
$password     = (string)($_POST['password'] ?? '');
$city         = trim($_POST['city'] ?? '');
$state        = strtoupper(trim($_POST['state'] ?? ''));
$office_phone = trim($_POST['office_phone'] ?? '');
$company_name = trim($_POST['company_name'] ?? '');

// Validações mínimas
$errors = [];
if ($name === '') $errors[] = 'Informe o nome.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';
if (!($cpf_cnpj && (strlen($cpf_cnpj) === 11 || strlen($cpf_cnpj) === 14))) $errors[] = 'CPF/CNPJ inválido.';
if (strlen($password) < 6) $errors[] = 'Senha muito curta.';
if ($city === '') $errors[] = 'Informe a cidade.';
if ($state === '' || strlen($state) !== 2) $errors[] = 'UF inválida.';
if ($office_phone === '') $errors[] = 'Informe o telefone do escritório.';
if ($company_name === '') $errors[] = 'Informe o nome do escritório.';

if ($errors) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger"><strong>Erro ao salvar seu cadastro:</strong><ul class="mb-0">';
  foreach ($errors as $e) echo '<li>'.h($e).'</li>';
  echo '</ul></div><a class="btn btn-secondary" href="javascript:history.back()">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

// Evita duplicidade por e-mail ou CPF/CNPJ
try {
  $du = $pdo->prepare(
    "SELECT COUNT(*) FROM users
     WHERE email = ?
        OR REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj,'.',''),'-',''),'/', ''),' ','') = ?"
  );
  $du->execute([$email, $cpf_cnpj]);
  if ((int)$du->fetchColumn() > 0) {
    include __DIR__ . '/../views/_header.php';
    echo '<div class="alert alert-danger">E-mail ou CPF/CNPJ já cadastrado.</div>';
    echo '<a class="btn btn-secondary" href="javascript:history.back()">Voltar</a>';
    include __DIR__ . '/../views/_footer.php';
    exit;
  }
} catch (Throwable $e) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger">Falha ao validar duplicidade: '.h($e->getMessage()).'</div>';
  echo '<a class="btn btn-secondary" href="javascript:history.back()">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

// Monta INSERT dinâmico conforme colunas existentes
$cols = [];
$cols['name']          = $name;
$cols['email']         = $email;
$cols['cpf_cnpj']      = $cpf_cnpj;
$cols['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
$cols['role']          = 'contador';

if (col_exists($pdo,'users','city'))          $cols['city']          = $city;
if (col_exists($pdo,'users','state'))         $cols['state']         = $state;
if (col_exists($pdo,'users','office_phone'))  $cols['office_phone']  = $office_phone;
if (col_exists($pdo,'users','company_name'))  $cols['company_name']  = $company_name;
// compat com telas antigas
if (col_exists($pdo,'users','phone'))         $cols['phone']         = $office_phone;

$hasTokenCol     = col_exists($pdo,'users','email_verification_token');
$hasEmailVerified= col_exists($pdo,'users','email_verified');
$hasIsActive     = col_exists($pdo,'users','is_active');

// token 64 chars
$token = $hasTokenCol ? bin2hex(random_bytes(32)) : null;

if ($hasTokenCol) {
  $cols['email_verification_token'] = $token;
  if ($hasEmailVerified) $cols['email_verified'] = 0;
  if ($hasIsActive)      $cols['is_active'] = 0;
} else {
  if ($hasEmailVerified) $cols['email_verified'] = 1;
  if ($hasIsActive)      $cols['is_active'] = 1;
}

if (col_exists($pdo,'users','created_at')) {
  $cols['created_at'] = date('Y-m-d H:i:s');
}

$colNames = array_keys($cols);
$place    = array_fill(0, count($colNames), '?');
$sql      = "INSERT INTO users (".implode(',', $colNames).") VALUES (".implode(',', $place).")";
$params   = array_values($cols);

try {
  $ins = $pdo->prepare($sql);
  $ins->execute($params);
  $uid = (int)$pdo->lastInsertId();

  $base = function_exists('app_base_url') ? app_base_url() : (rtrim(getenv('SITE_URL') ?: '', '/'));
  $app  = defined('APP_NAME') ? APP_NAME : 'RIDIECERT';

  if ($hasTokenCol && $token) {
    $link = $base.'/?page=verify_email&token='.$token;
    $html = "<p>Olá, ".h($name)."</p>
             <p>Confirme seu e-mail para ativar sua conta no <strong>".h($app)."</strong>:</p>
             <p><a href=\"".h($link)."\">".h($link)."</a></p>
             <p>Se você não criou esta conta, ignore esta mensagem.</p>
             <p>".h($app)."</p>";
    @send_mail($email, "Confirme seu e-mail — ".$app, $html);

    include __DIR__ . '/../views/_header.php';
    echo '<div class="alert alert-success">Cadastro recebido! Enviamos um link de confirmação para o seu e-mail. Verifique sua caixa de entrada.</div>';
    echo '<a class="btn btn-primary" href="/?page=login">Ir para o login</a>';
    include __DIR__ . '/../views/_footer.php';
    exit;

  } else {
    $loginUrl = $base.'/?page=login';
    if (function_exists('send_welcome_email')) {
      @send_welcome_email($email, $name, $loginUrl);
    } else {
      $html = "<p>Olá, ".h($name)."</p>
               <p>Sua conta no <strong>".h($app)."</strong> foi criada e está ativa.</p>
               <p>Você já pode acessar: <a href=\"".$loginUrl."\">".$loginUrl."</a></p>
               <p>".h($app)."</p>";
      @send_mail($email, "Bem-vindo(a) — ".$app, $html);
    }

    include __DIR__ . '/../views/_header.php';
    echo '<div class="alert alert-success">Cadastro concluído! Você já pode acessar com seu e-mail e senha.</div>';
    echo '<a class="btn btn-primary" href="/?page=login">Ir para o login</a>';
    include __DIR__ . '/../views/_footer.php';
    exit;
  }

} catch (Throwable $e) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger"><strong>Erro ao salvar seu cadastro:</strong><br><span class="small">'.h($e->getMessage()).'</span></div>';
  echo '<a class="btn btn-secondary" href="javascript:history.back()">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}
