<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['contador','admin']); // admin também pode ver

$me = auth_user();

include __DIR__ . '/../views/_header.php'; ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<div class="container py-3">
  <h1 class="h5 mb-3">Meu Dashboard</h1>

  <!-- Filtros -->
  <form class="row g-2 mb-3" method="get" onsubmit="return false;">
    <div class="col-auto">
      <select id="range" class="form-select" onchange="toggleCustom(this.value);loadStats();">
        <option value="today">Hoje</option>
        <option value="7d">Últimos 7 dias</option>
        <option value="15d">Últimos 15 dias</option>
        <option value="30d" selected>Últimos 30 dias</option>
        <option value="90d">Últimos 3 meses</option>
        <option value="custom">Personalizado</option>
      </select>
    </div>
    <div class="col-auto">
      <input type="text" id="from" class="form-control" placeholder="De (YYYY-MM-DD)" disabled>
    </div>
    <div class="col-auto">
      <input type="text" id="to" class="form-control" placeholder="Até (YYYY-MM-DD)" disabled>
    </div>
    <div class="col-auto">
      <button class="btn btn-primary" onclick="loadStats()">Aplicar</button>
    </div>
  </form>

  <!-- Cards -->
  <div class="row g-3 mb-3" id="cards">
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div>Total de Pedidos</div><h3 id="c_total">0</h3></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div>Aguardando Pagamento</div><h3 id="c_pending">0</h3></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div>Pagos</div><h3 id="c_paid">0</h3></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div>Com Protocolo</div><h3 id="c_proto">0</h3></div></div></div>
  </div>

  <div class="row g-3">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h6 class="mb-2">Pedidos por dia</h6>
          <canvas id="chartOrders"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h6 class="mb-2">Tipos de Certificado</h6>
          <canvas id="chartModels"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h6 class="mb-2">Pedidos por Status</h6>
          <canvas id="chartStatus"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h6 class="mb-2">Próximos Agendamentos</h6>
          <ul id="nextAppointments" class="mb-0 small"></ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
let chOrders, chModels, chStatus;

function toggleCustom(v){
  const dis = (v!=='custom');
  document.getElementById('from').disabled = dis;
  document.getElementById('to').disabled   = dis;
}

flatpickr('#from',{dateFormat:'Y-m-d'});
flatpickr('#to',{dateFormat:'Y-m-d'});

function rangeBounds(){
  const v = document.getElementById('range').value;
  if (v==='custom') {
    return {range:'custom', from:document.getElementById('from').value, to:document.getElementById('to').value};
  }
  return {range:v};
}

function loadStats(){
  const r = rangeBounds();
  const params = new URLSearchParams(r).toString();
  fetch(`/?page=contador_stats_api&${params}`)
    .then(r=>r.json())
    .then(j=>{
      document.getElementById('c_total').innerText  = j.cards.total || 0;
      document.getElementById('c_pending').innerText= j.cards.pending || 0;
      document.getElementById('c_paid').innerText   = j.cards.paid || 0;
      document.getElementById('c_proto').innerText  = j.cards.protocol || 0;

      if (chOrders) chOrders.destroy();
      chOrders = new Chart(document.getElementById('chartOrders'), {
        type:'line',
        data:{ labels: j.orders_per_day.map(x=>x.d), datasets:[{label:'Pedidos',data:j.orders_per_day.map(x=>x.c)}] }
      });

      if (chModels) chModels.destroy();
      chModels = new Chart(document.getElementById('chartModels'), {
        type:'doughnut',
        data:{ labels: j.models_breakdown.map(x=>x.label), datasets:[{data:j.models_breakdown.map(x=>x.c)}] }
      });

      if (chStatus) chStatus.destroy();
      chStatus = new Chart(document.getElementById('chartStatus'), {
        type:'bar',
        data:{ labels: j.status_breakdown.map(x=>x.status),
               datasets:[{label:'Qtd', data:j.status_breakdown.map(x=>x.c)}] }
      });

      const ul = document.getElementById('nextAppointments');
      ul.innerHTML='';
      (j.next_appointments||[]).forEach(a=>{
        const li = document.createElement('li');
        li.textContent = `${a.dt} — Pedido ${a.order_no}`;
        ul.appendChild(li);
      });
    });
}

// inicial
loadStats();
</script>
