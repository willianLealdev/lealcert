<?php
require_role('admin');
$id = intval($_GET['id'] ?? 0);
$newpass = bin2hex(random_bytes(4));
$hash = password_hash($newpass, PASSWORD_BCRYPT);
$stmt = $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?");
$stmt->execute([$hash,$id]);
include __DIR__ . '/../views/_header.php';
?>
<div class="alert alert-success">Senha redefinida com sucesso. Nova senha temporária: <strong><?= sanitize($newpass) ?></strong></div>
<a href="/?page=admin_users" class="btn btn-primary">Voltar</a>
<?php include __DIR__ . '/../views/_footer.php'; ?>
