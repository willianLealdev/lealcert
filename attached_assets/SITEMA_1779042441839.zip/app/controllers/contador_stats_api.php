<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

require_login();
header('Content-Type: application/json; charset=utf-8');

$me  = auth_user();
$uid = (int)($me['id'] ?? 0);

/* ==== helpers para auto-detecção de schema ==== */
function col_exists(PDO $pdo, string $table, string $col): bool {
  try {
    $q = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$col'");
    return (bool)$q->fetch();
  } catch (Throwable $e) { return false; }
}
function pick_col(PDO $pdo, string $table, array $cands, ?string $fallback=null): ?string {
  foreach ($cands as $c) if (col_exists($pdo, $table, $c)) return $c;
  return $fallback;
}
function table_exists(PDO $pdo, string $table): bool {
  try { $pdo->query("SELECT 1 FROM `$table` LIMIT 1"); return true; }
  catch (Throwable $e) { return false; }
}
function pick_table(PDO $pdo, array $cands): ?string {
  foreach ($cands as $t) if (table_exists($pdo,$t)) return $t;
  return null;
}

/* ==== detectar colunas/tabelas ==== */
$oTbl         = 'orders';
$ownerCol     = pick_col($pdo, $oTbl, ['user_id','contador_id','owner_id','created_by']);
$createdCol   = pick_col($pdo, $oTbl, ['created_at','created','created_on','createdAt','dt_created','inserted_at','data_criacao']);
$scheduleCol  = pick_col($pdo, $oTbl, ['schedule_datetime','scheduled_at','appointment_at','appointment_datetime','agendamento','agendamento_datetime']);
$statusCol    = pick_col($pdo, $oTbl, ['status','order_status'], 'status');
$orderNoCol   = pick_col($pdo, $oTbl, ['order_number','numero_pedido','numero','ref','id'], 'id');
$modelIdCol   = pick_col($pdo, $oTbl, ['model_id','certificate_model_id','product_id']);

$modelsTbl    = pick_table($pdo, ['certificate_models','products','product_models','models']);
$modelsNameCol= 'name';
if ($modelsTbl) {
  // escolhe coluna de nome disponível
  foreach (['name','title','label','descricao'] as $nm) {
    if (col_exists($pdo, $modelsTbl, $nm)) { $modelsNameCol = $nm; break; }
  }
}

/* ==== intervalo recebido ==== */
$range = $_GET['range'] ?? '30d';
$from  = $_GET['from'] ?? null;
$to    = $_GET['to']   ?? null;

$tz = new DateTimeZone(date_default_timezone_get() ?: 'America/Sao_Paulo');
$now = new DateTimeImmutable('now', $tz);

if ($range === 'custom' && $from && $to) {
  $start = (new DateTime($from.' 00:00:00', $tz))->format('Y-m-d H:i:s');
  $end   = (new DateTime($to  .' 23:59:59', $tz))->format('Y-m-d H:i:s');
} else {
  switch ($range) {
    case 'today': $start=$now->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '7d':    $start=$now->modify('-6 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '15d':   $start=$now->modify('-14 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '90d':   $start=$now->modify('-89 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '30d':
    default:      $start=$now->modify('-29 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
  }
}

/* ==== montar WHERE dinâmico ==== */
$where = [];
$params = [];

$periodCol = $createdCol ?: $scheduleCol; // usa created; se não existir, usa schedule
if ($periodCol) {
  $where[] = "o.`$periodCol` BETWEEN ? AND ?";
  $params[] = $start; $params[] = $end;
}

if ($ownerCol && $uid > 0) {
  $where[] = "o.`$ownerCol` = ?";
  $params[] = $uid;
}
// se não tiver ownerCol, mostramos tudo para não ficar zerado
if (!$where) { $where[] = '1=1'; }

$W = implode(' AND ', $where);

/* ==== CARDS ==== */
$sqlCards = "
  SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN o.`$statusCol` IN ('pending_payment','aguardando_pagamento','pendente','pending') THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN o.`$statusCol` IN ('paid','pago') THEN 1 ELSE 0 END) AS paid,
    SUM(CASE WHEN o.`$statusCol` IN ('protocol_assigned','protocolo','com_protocolo') THEN 1 ELSE 0 END) AS protocol
  FROM `$oTbl` o
  WHERE $W
";
$st = $pdo->prepare($sqlCards); $st->execute($params);
$cards = $st->fetch(PDO::FETCH_ASSOC) ?: ['total'=>0,'pending'=>0,'paid'=>0,'protocol'=>0];

/* ==== pedidos por dia ==== */
$perDay = [];
if ($periodCol) {
  $sqlDay = "
    SELECT DATE(o.`$periodCol`) AS d, COUNT(*) AS c
    FROM `$oTbl` o
    WHERE $W
    GROUP BY DATE(o.`$periodCol`)
    ORDER BY d
  ";
  $st = $pdo->prepare($sqlDay); $st->execute($params);
  $perDay = $st->fetchAll(PDO::FETCH_ASSOC);
}

/* ==== modelos ==== */
$models = [];
if ($modelsTbl && $modelIdCol) {
  $sqlModels = "
    SELECT m.`$modelsNameCol` AS label, COUNT(*) AS c
    FROM `$oTbl` o
    JOIN `$modelsTbl` m ON m.id = o.`$modelIdCol`
    WHERE $W
    GROUP BY m.id
    ORDER BY c DESC
  ";
  $st = $pdo->prepare($sqlModels); $st->execute($params);
  $models = $st->fetchAll(PDO::FETCH_ASSOC);
}

/* ==== status breakdown ==== */
$sqlStatus = "
  SELECT o.`$statusCol` AS status, COUNT(*) AS c
  FROM `$oTbl` o
  WHERE $W
  GROUP BY o.`$statusCol`
  ORDER BY c DESC
";
$st = $pdo->prepare($sqlStatus); $st->execute($params);
$statuses = $st->fetchAll(PDO::FETCH_ASSOC);

/* ==== próximos agendamentos (7 próximos) ==== */
$next = [];
if ($scheduleCol) {
  $q = $pdo->prepare("
    SELECT o.`$orderNoCol` AS order_no, o.`$scheduleCol` AS dt
    FROM `$oTbl` o
    WHERE ($W) AND o.`$scheduleCol` >= NOW()
    ORDER BY o.`$scheduleCol` ASC
    LIMIT 7
  ");
  $q->execute($params);
  $rows = $q->fetchAll(PDO::FETCH_ASSOC);
  foreach ($rows as $r) {
    $next[] = [
      'order_no' => $r['order_no'] ?: '',
      'dt'       => $r['dt'] ? date('d/m/Y H:i', strtotime($r['dt'])) : '',
    ];
  }
}

/* ==== retorno ==== */
echo json_encode([
  'cards'             => array_map('intval', [
    'total'    => (int)($cards['total'] ?? 0),
    'pending'  => (int)($cards['pending'] ?? 0),
    'paid'     => (int)($cards['paid'] ?? 0),
    'protocol' => (int)($cards['protocol'] ?? 0),
  ]),
  'orders_per_day'    => $perDay,
  'models_breakdown'  => $models,
  'status_breakdown'  => $statuses,
  'next_appointments' => $next,
  // debug leve para sabermos o que foi escolhido:
  'meta' => [
    'ownerCol'    => $ownerCol,
    'createdCol'  => $createdCol,
    'scheduleCol' => $scheduleCol,
    'statusCol'   => $statusCol,
    'orderNoCol'  => $orderNoCol,
    'modelsTbl'   => $modelsTbl,
    'modelsName'  => $modelsNameCol,
    'range'       => [$start,$end],
  ],
]);
