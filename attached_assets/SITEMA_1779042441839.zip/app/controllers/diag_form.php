<?php
ini_set('display_errors','1'); error_reporting(E_ALL);
?>
<!doctype html><meta charset="utf-8">
<h3>Form de teste</h3>
<form method="post" action="/?page=diag_recv" enctype="multipart/form-data">
  <input type="hidden" name="model_id" value="1">
  <input type="text" name="client_name" value="Teste Cliente"><br><br>
  <input type="file" name="cnh_file" accept="application/pdf"><br><br>
  <button>Enviar</button>
</form>
