<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

$u = auth_user();

include __DIR__ . '/../views/_header.php';
?>
<style>
  .auth-wrap { min-height: 65vh; display:flex; align-items:center; justify-content:center; }
  .card-auth { width: 100%; max-width: 460px; border: 0; border-radius: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,.06); }
  .card-auth .card-header { border-bottom:0; text-align:center; background: linear-gradient(180deg,#f8fbff,#ffffff); border-radius:1rem 1rem 0 0; }
  .brand-badge { font-weight: 900; font-size: 1.75rem; letter-spacing:.6px; }
</style>

<div class="auth-wrap">
  <div class="card card-auth">
    <div class="card-header py-4">
      <div class="brand-badge"><?= sanitize(APP_NAME) ?></div>
      <div class="small text-muted">Acesse sua conta</div>
    </div>
    <div class="card-body p-4">

      <?php if ($u): ?>
        <div class="alert alert-info d-flex justify-content-between align-items-center">
          <span>Você já está logado como <strong><?= sanitize($u['name'] ?? '') ?></strong>.</span>
          <a class="btn btn-sm btn-primary" href="/?page=<?= $u['role']==='admin'?'admin_dashboard':'contador_dashboard' ?>">Ir para o painel</a>
        </div>
      <?php endif; ?>

      <?php
        // mensagem de bloqueio (conta inativa)
        if (!empty($_SESSION['LOGIN_BLOCKED'])) {
          echo '<div class="alert alert-warning">'.sanitize($_SESSION['LOGIN_BLOCKED']).'</div>';
          unset($_SESSION['LOGIN_BLOCKED']);
        }
      ?>

      <form method="post" action="/?page=do_login" autocomplete="off" class="row g-3">
        <div class="col-12">
          <label class="form-label">CPF ou CNPJ <span class="text-danger">*</span></label>
          <input type="text" name="cpf_cnpj" class="form-control" placeholder="Apenas números" required>
        </div>
        <div class="col-12">
          <label class="form-label">Senha <span class="text-danger">*</span></label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="col-12 d-grid">
          <button class="btn btn-primary py-2">Entrar</button>
        </div>
        <div class="col-12 d-flex justify-content-between">
          <a href="/?page=forgot_password">Esqueci a senha</a>
          <a href="/?page=register">Criar conta (Contador)</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../views/_footer.php'; ?>
