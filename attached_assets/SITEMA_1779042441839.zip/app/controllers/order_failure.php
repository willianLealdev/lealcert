<?php include __DIR__ . '/../views/_header.php'; ?>
<div class="alert alert-danger">Pagamento falhou ou foi cancelado.</div>
<a href="/?page=orders_me" class="btn btn-primary">Meus Pedidos</a>
<?php include __DIR__ . '/../views/_footer.php'; ?>
