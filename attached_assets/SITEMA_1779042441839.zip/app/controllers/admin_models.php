<?php
require_role('admin');
$models = $pdo->query("SELECT * FROM certificate_models ORDER BY id DESC")->fetchAll();
include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Modelos de Certificado</h1>
<a href="/?page=admin_model_new" class="btn btn-primary mb-3">Novo Modelo</a>
<div class="table-responsive">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Nome</th><th>Preço</th><th>Ativo</th><th>Ações</th></tr></thead>
  <tbody>
  <?php foreach ($models as $m): ?>
    <tr>
      <td><?= $m['id'] ?></td>
      <td><?= sanitize($m['name']) ?></td>
      <td>R$ <?= number_format($m['price'],2,',','.') ?></td>
      <td><?= $m['active'] ? 'Sim':'Não' ?></td>
      <td><a class="btn btn-sm btn-outline-primary" href="/?page=admin_model_edit&id=<?= $m['id'] ?>">Editar</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
