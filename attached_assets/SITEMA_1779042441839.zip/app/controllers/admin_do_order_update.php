<?php
// app/controllers/admin_order_update.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');
require_once __DIR__ . '/../lib/mailer.php';
require_once __DIR__ . '/../mailer.php';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }

// Somente POST
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
  http_response_code(405);
  echo "Método não permitido."; exit;
}

$id              = (int)($_POST['id'] ?? 0);
$status          = trim($_POST['status'] ?? '');
$protocol_number = trim($_POST['protocol_number'] ?? '');
$codigo_chave    = trim($_POST['codigo_chave'] ?? '');

if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

// Carrega pedido ANTES (para comparar)
$st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st->execute([$id]);
$before = $st->fetch();
if (!$before) { http_response_code(404); echo "Pedido não encontrado."; exit; }

$set = [];
$params = [];

// Atualizações permitidas
if ($status !== '')           { $set[] = "status=?";           $params[] = $status; }
if ($protocol_number !== '')  { $set[] = "protocol_number=?";  $params[] = $protocol_number; }
if ($codigo_chave   !== '')   { $set[] = "codigo_chave=?";     $params[] = $codigo_chave; }
$set[] = "updated_at=NOW()";

if (count($set)) {
  $params[] = $id;
  $sql = "UPDATE orders SET ".implode(',', $set)." WHERE id=?";
  $up = $pdo->prepare($sql);
  $up->execute($params);
}

// Carrega pedido DEPOIS (dados atualizados)
$st2 = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st2->execute([$id]);
$after = $st2->fetch();

// =================== EMAILS AUTOMÁTICOS ===================

// Antes/depois
$beforeStatus = $before['status'] ?? '';
$afterStatus  = $after['status']  ?? '';
$protoBefore  = trim($before['protocol_number'] ?? '');
$protoAfter   = trim($after['protocol_number'] ?? '');
$codigoBefore = trim($before['codigo_chave'] ?? '');
$codigoAfter  = trim($after['codigo_chave'] ?? '');

// 🔹 Caso 1: protocolo atribuído → email padrão
$fireMailProto = false;
if ($afterStatus === 'protocol_assigned' && $beforeStatus !== 'protocol_assigned') $fireMailProto = true;
if ($protoAfter !== '' && $protoAfter !== $protoBefore) $fireMailProto = true;

if ($fireMailProto) {
  notify_protocol_assigned($pdo, (int)$after['id']);
}

// 🔹 Caso 2: pedido concluído + código chave informado → email novo
$fireMailCodigo = false;
if ($afterStatus === 'completed' && $beforeStatus !== 'completed' && $codigoAfter !== '') $fireMailCodigo = true;
if ($codigoAfter !== '' && $codigoAfter !== $codigoBefore && $afterStatus === 'completed') $fireMailCodigo = true;

if ($fireMailCodigo) {
  notify_codigo_concluido($pdo, (int)$after['id']);
}

// ==========================================================

// Volta para a página de edição ou detalhes
$redir = "/?page=admin_order_edit&id=".$id;
header("Location: ".$redir."&ok=1");
exit;
