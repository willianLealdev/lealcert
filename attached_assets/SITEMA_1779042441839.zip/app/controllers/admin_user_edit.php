<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

// Busca usuário
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();
if (!$user) { http_response_code(404); echo "Usuário não encontrado."; exit; }

// Salvar alterações
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_user') {
  $name          = trim($_POST['name'] ?? '');
  $email         = trim($_POST['email'] ?? '');
  $cpf_cnpj      = trim($_POST['cpf_cnpj'] ?? '');
  $city          = trim($_POST['city'] ?? '');
  $state         = trim($_POST['state'] ?? '');
  $company_name  = trim($_POST['company_name'] ?? '');
  $company_cnpj  = trim($_POST['company_cnpj'] ?? '');
  $office_phone  = trim($_POST['office_phone'] ?? '');
  $role          = trim($_POST['role'] ?? $user['role']);
  $is_active     = isset($_POST['is_active']) ? 1 : 0;
  $email_verified= isset($_POST['email_verified']) ? 1 : 0;

  // Upload de avatar (opcional)
  $avatar_path = $user['avatar_path'] ?? null;
  if (!empty($_FILES['avatar']['name']) && is_uploaded_file($_FILES['avatar']['tmp_name'])) {
    $dir = __DIR__ . '/../../storage/uploads/avatars';
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $fname = 'u'.$id.'_'.time().'.'.strtolower(preg_replace('/[^a-z0-9]+/i','',$ext));
    $dest = $dir . '/' . $fname;
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $dest)) {
      $avatar_path = 'storage/uploads/avatars/'.$fname;
    }
  }

  $upd = $pdo->prepare("
    UPDATE users SET
      name = ?, email = ?, cpf_cnpj = ?, city = ?, state = ?,
      company_name = ?, company_cnpj = ?, office_phone = ?,
      role = ?, is_active = ?, email_verified = ?, avatar_path = ?
    WHERE id = ?
  ");
  $upd->execute([
    $name, $email, $cpf_cnpj, $city, $state,
    $company_name, $company_cnpj, $office_phone,
    $role, $is_active, $email_verified, $avatar_path,
    $id
  ]);

  header("Location: /?page=admin_user_edit&id={$id}&ok=1");
  exit;
}

include __DIR__ . '/../views/_header.php';
?>
<h1 class="h5 mb-3">Editar Usuário #<?= (int)$id ?></h1>

<?php if (!empty($_GET['ok'])): ?>
  <div class="alert alert-success">Alterações salvas com sucesso.</div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="row g-3">
  <input type="hidden" name="action" value="save_user">
  <div class="col-md-6">
    <label class="form-label">Nome</label>
    <input class="form-control" name="name" value="<?= sanitize($user['name'] ?? '') ?>">
  </div>
  <div class="col-md-6">
    <label class="form-label">E-mail</label>
    <input type="email" class="form-control" name="email" value="<?= sanitize($user['email'] ?? '') ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">CPF/CNPJ</label>
    <input class="form-control" name="cpf_cnpj" value="<?= sanitize($user['cpf_cnpj'] ?? '') ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">Cidade</label>
    <input class="form-control" name="city" value="<?= sanitize($user['city'] ?? '') ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">UF</label>
    <input class="form-control" name="state" maxlength="2" value="<?= sanitize($user['state'] ?? '') ?>">
  </div>

  <div class="col-md-6">
    <label class="form-label">Nome do Escritório</label>
    <input class="form-control" name="company_name" value="<?= sanitize($user['company_name'] ?? '') ?>">
  </div>
  <div class="col-md-3">
    <label class="form-label">CNPJ do Escritório</label>
    <input class="form-control" name="company_cnpj" value="<?= sanitize($user['company_cnpj'] ?? '') ?>">
  </div>
  <div class="col-md-3">
    <label class="form-label">Telefone do Escritório</label>
    <input class="form-control" name="office_phone" value="<?= sanitize($user['office_phone'] ?? '') ?>">
  </div>

  <div class="col-md-4">
    <label class="form-label">Perfil</label>
    <select class="form-select" name="role">
      <option value="contador" <?= ($user['role']==='contador'?'selected':'') ?>>Contador</option>
      <option value="admin" <?= ($user['role']==='admin'?'selected':'') ?>>Admin</option>
    </select>
  </div>
  <div class="col-md-4">
    <label class="form-label d-block">Ativo</label>
    <div class="form-check form-switch">
      <input class="form-check-input" type="checkbox" name="is_active" value="1" <?= !empty($user['is_active'])?'checked':'' ?>>
      <span class="form-check-label">Liberar acesso</span>
    </div>
  </div>
  <div class="col-md-4">
    <label class="form-label d-block">E-mail verificado</label>
    <div class="form-check form-switch">
      <input class="form-check-input" type="checkbox" name="email_verified" value="1" <?= !empty($user['email_verified'])?'checked':'' ?>>
      <span class="form-check-label">Marcar como verificado</span>
    </div>
  </div>

  <div class="col-md-6">
    <label class="form-label">Avatar / Logo (opcional)</label>
    <input type="file" class="form-control" name="avatar" accept="image/*">
    <?php if (!empty($user['avatar_path'])): ?>
      <small class="text-muted d-block mt-1">Atual: <a href="/<?= sanitize($user['avatar_path']) ?>" target="_blank">ver arquivo</a></small>
    <?php endif; ?>
  </div>

  <div class="col-12 d-flex gap-2">
    <button class="btn btn-primary">Salvar alterações</button>
    <a class="btn btn-outline-secondary" href="/?page=admin_users">Cancelar</a>
  </div>
</form>

<?php include __DIR__ . '/../views/_footer.php'; ?>
