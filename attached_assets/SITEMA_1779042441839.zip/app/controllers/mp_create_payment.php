<?php
// app/controllers/mp_create_payment.php — Endpoint chamado pelo Payment Brick
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
header('Content-Type: application/json; charset=UTF-8');

try {
  $u       = auth_user();
  $uid     = (int)($u['id'] ?? 0);
  $isAdmin = ($u['role'] ?? '') === 'admin';

  $body = json_decode(file_get_contents('php://input'), true) ?: [];
  $order_id = (int)($body['order_id'] ?? 0);
  $formData = $body['formData'] ?? null;

  if ($order_id <= 0 || !$formData) {
    http_response_code(400);
    echo json_encode(['error'=>'payload_invalido']); exit;
  }

  // Carrega pedido
  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
  $st->execute([$order_id]);
  $o = $st->fetch(PDO::FETCH_ASSOC);
  if (!$o) { http_response_code(404); echo json_encode(['error'=>'pedido_nao_encontrado']); exit; }

  // Permissão
  if (!$isAdmin && (int)$o['user_id'] !== $uid) {
    http_response_code(403); echo json_encode(['error'=>'sem_permissao']); exit;
  }

  // Valor (em decimal) — usa a coluna que existir
  $amount = null;
  foreach (['total','total_amount','amount','price','valor'] as $c) {
    if (array_key_exists($c, $o) && $o[$c] !== null && $o[$c] !== '') {
      $amount = (float)$o[$c]; break;
    }
  }
  if ($amount === null) $amount = 0.0;

  // Monta payload p/ /v1/payments
  // A recomendação é usar os dados do Brick, mas SEM confiar no amount do cliente
  // então forçamos transaction_amount e complementamos alguns campos.
  $payload = $formData;
  $payload['transaction_amount'] = round($amount, 2);
  $payload['description']        = 'Pedido '.($o['order_number'] ?: '#'.$order_id);
  $payload['metadata'] = array_merge($payload['metadata'] ?? [], ['order_id' => $order_id]);

  // Se não vier e-mail no formData, use o do dono do pedido
  if (empty($payload['payer']['email'])) {
    $ust = $pdo->prepare("SELECT email FROM users WHERE id=?");
    $ust->execute([(int)$o['user_id']]);
    $email = (string)($ust->fetchColumn() ?: '');
    if ($email) {
      $payload['payer'] = $payload['payer'] ?? [];
      $payload['payer']['email'] = $email;
    }
  }

  // Chama API de pagamentos
  $ch = curl_init('https://api.mercadopago.com/v1/payments');
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
      'Authorization: Bearer '.MP_ACCESS_TOKEN,
      'Content-Type: application/json'
    ],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
  ]);
  $resp = curl_exec($ch);
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $cerr = curl_error($ch);
  curl_close($ch);

  $data = json_decode($resp, true);

  // Log opcional em storage, ajuda a depurar
  $logDir = __DIR__ . '/../../storage';
  if (!is_dir($logDir)) @mkdir($logDir, 0775, true);
  @file_put_contents($logDir.'/mp_payments.log',
    date('c')." order_id=$order_id http=$http err=$cerr body=".substr($resp ?? '',0,8000)."\n",
    FILE_APPEND
  );

  if ($http === 201 && is_array($data) && !empty($data['status'])) {
    $mpStatus = (string)$data['status']; // approved | in_process | rejected | ...
    $mpId     = (string)($data['id'] ?? '');
    $newStatus = ($mpStatus === 'approved') ? 'paid' : (($mpStatus === 'in_process') ? 'pending_payment' : 'created');

    $up = $pdo->prepare("UPDATE orders SET status=?, mp_payment_id=?, updated_at=NOW() WHERE id=?");
    $up->execute([$newStatus, $mpId, $order_id]);

    echo json_encode(['status'=>$mpStatus, 'id'=>$mpId]); exit;
  }

  http_response_code(400);
  echo json_encode(['error'=>'mp_error','http'=>$http,'resp'=>$data]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error'=>'exception','msg'=>$e->getMessage()]);
}
