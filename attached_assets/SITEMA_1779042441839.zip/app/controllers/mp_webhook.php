<?php
// app/controllers/mp_webhook.php
require_once __DIR__ . '/../config.php';

// Valida secret do webhook (query string)
$secretReq = $_GET['secret'] ?? '';
$secretEnv = getenv('WEBHOOK_SECRET') ?: (defined('WEBHOOK_SECRET') ? WEBHOOK_SECRET : '');
if (!$secretEnv || !hash_equals($secretEnv, $secretReq)) {
  http_response_code(403);
  echo "forbidden"; exit;
}

header('Content-Type: application/json');

// Util simples
function jexit($arr){ echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function mp_token(){
  $t = getenv('MP_ACCESS_TOKEN') ?: (defined('MP_ACCESS_TOKEN') ? MP_ACCESS_TOKEN : '');
  return trim($t);
}
function mp_get($url){
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
      'Authorization: Bearer '.mp_token(),
      'Content-Type: application/json',
    ],
    CURLOPT_TIMEOUT => 30,
  ]);
  $resp = curl_exec($ch);
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err  = curl_error($ch);
  curl_close($ch);
  if ($resp === false) return [null, 0, $err];
  $data = json_decode($resp, true);
  return [$data, $http, null];
}
function map_status($mp){
  $s = strtolower((string)($mp['status'] ?? ''));
  return $s === 'approved' ? 'paid' : 'pending_payment';
}
function update_order_from_payment(PDO $pdo, array $pay){
  // Tenta descobrir o pedido
  $ext = (string)($pay['external_reference'] ?? '');
  $orderId = null;
  if (preg_match('/^order-(\d+)/', $ext, $m)) {
    $orderId = (int)$m[1];
  }
  // Se não veio external_reference, tenta por mp_payment_id
  if (!$orderId && !empty($pay['id'])) {
    $st = $pdo->prepare("SELECT id FROM orders WHERE mp_payment_id=? LIMIT 1");
    $st->execute([(string)$pay['id']]);
    $row = $st->fetch();
    if ($row) $orderId = (int)$row['id'];
  }
  if (!$orderId) return false;

  $mpId = (string)($pay['id'] ?? '');
  $newStatus = map_status($pay);

  // Atualiza
  $sql = "UPDATE orders SET status=:st, mp_payment_id=COALESCE(mp_payment_id, :mp) WHERE id=:id";
  $up = $pdo->prepare($sql);
  $up->execute([':st'=>$newStatus, ':mp'=>$mpId, ':id'=>$orderId]);
  return true;
}

// Lê payload (funciona tanto no formato novo quanto legado)
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) $body = [];

// Formatos possíveis:
// - Novo: { "type":"payment", "data": { "id":"123" } }
// - Legado: topic=payment&id=123 via query
$paymentId = null;

if (isset($body['data']['id']) && ($body['type'] ?? $body['action'] ?? '') === 'payment') {
  $paymentId = $body['data']['id'];
}
if (!$paymentId) {
  $topic = $_GET['topic'] ?? $_GET['type'] ?? '';
  if ($topic === 'payment' && isset($_GET['id'])) {
    $paymentId = $_GET['id'];
  }
}

if (!$paymentId) {
  // Apenas ack
  jexit(['ok'=>true,'msg'=>'noop']);
}

// Busca o pagamento no MP
$token = mp_token();
if (!$token) jexit(['ok'=>false,'error'=>'ACCESS_TOKEN ausente.']);

list($pay, $http, $err) = mp_get('https://api.mercadopago.com/v1/payments/'.urlencode($paymentId));
if ($err) jexit(['ok'=>false,'error'=>'Falha ao consultar o MP: '.$err]);
if ($http >= 400 || !is_array($pay)) jexit(['ok'=>false,'error'=>'Erro MP HTTP '.$http]);

// Atualiza pedido
try {
  $ok = update_order_from_payment($pdo, $pay);
  jexit(['ok'=>true, 'updated'=>$ok, 'status'=>$pay['status'] ?? null, 'id'=>$pay['id'] ?? null]);
} catch (Throwable $e) {
  jexit(['ok'=>false,'error'=>$e->getMessage()]);
}
