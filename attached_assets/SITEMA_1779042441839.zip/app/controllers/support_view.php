<?php
// app/controllers/support_view.php — detalhes do chamado + respostas/fechamento
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../mailer.php'; // garante as funções de e-mail
require_login();

function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// helpers de schema
function col_exists(PDO $pdo, string $t, string $c): bool {
  try { $st = $pdo->prepare("SHOW COLUMNS FROM `$t` LIKE ?"); $st->execute([$c]); return (bool)$st->fetch(); }
  catch (Throwable $e) { return false; }
}

$u       = auth_user();
$uid     = (int)($u['id'] ?? 0);
$isAdmin = (($u['role'] ?? '') === 'admin');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); echo "Chamado inválido."; exit; }

// carrega ticket
$st = $pdo->prepare("SELECT t.*, (SELECT name FROM users WHERE id=t.user_id) AS user_name FROM support_tickets t WHERE t.id=? LIMIT 1");
$st->execute([$id]);
$t = $st->fetch(PDO::FETCH_ASSOC);
if (!$t) { http_response_code(404); echo "Chamado não encontrado."; exit; }

// permissão: admin ou dono do ticket
if (!$isAdmin && (int)$t['user_id'] !== $uid) {
  http_response_code(403); echo "Acesso negado."; exit;
}

// badge colorida
function status_badge(string $status): string {
  switch ($status) {
    case 'aberto':               return '<span class="badge text-bg-success">Aberto</span>';
    case 'respondido_cliente':   return '<span class="badge" style="background:#fb923c;color:#111">Cliente respondeu</span>';
    case 'respondido_admin':     return '<span class="badge text-bg-warning">Respondido — Suporte</span>';
    case 'finalizado':           return '<span class="badge text-bg-danger">Finalizado</span>';
    default:                     return '<span class="badge text-bg-secondary">'.esc($status).'</span>';
  }
}

// ações: responder / finalizar
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action  = $_POST['action'] ?? '';
  $message = trim($_POST['message'] ?? '');

  // saber se há coluna updated_at
  $hasUpdatedAt = col_exists($pdo, 'support_tickets', 'updated_at');
  $setUpdated   = $hasUpdatedAt ? ", updated_at=NOW()" : "";

  if ($action === 'reply') {
    if ($message === '') {
      $err = "Escreva uma mensagem.";
    } else {
      // grava resposta
      $ins = $pdo->prepare("INSERT INTO support_messages (ticket_id, sender_role, message, created_at) VALUES (?,?,?,NOW())");
      $ins->execute([$id, $isAdmin ? 'admin' : 'contador', $message]);

      if ($isAdmin) {
        // admin respondeu -> status e badge para cliente, notifica cliente
        $pdo->prepare("UPDATE support_tickets SET status='respondido_admin', unread_client=1, unread_admin=0 {$setUpdated} WHERE id=?")
            ->execute([$id]);

        if (function_exists('notify_support_admin_replied_user')) {
          @notify_support_admin_replied_user($pdo, $id, $message);
        }
      } else {
        // cliente respondeu -> status e badge para admin, notifica admins
        $pdo->prepare("UPDATE support_tickets SET status='respondido_cliente', unread_admin=1, unread_client=0 {$setUpdated} WHERE id=?")
            ->execute([$id]);

        if (function_exists('notify_support_user_replied_admin')) {
          @notify_support_user_replied_admin($pdo, $id, $message);
        }
      }

      header("Location: /?page=support_view&id=".$id."&ok=1"); exit;
    }
  }

  if ($action === 'close') {
    // pode fechar se for admin OU o dono do ticket
    $pdo->prepare("UPDATE support_tickets SET status='finalizado', unread_admin=0, unread_client=0 {$setUpdated} WHERE id=?")
        ->execute([$id]);

    // registra uma nota de sistema
    $note = $isAdmin ? "Chamado finalizado pelo Suporte." : "Chamado finalizado pelo cliente.";
    $pdo->prepare("INSERT INTO support_messages (ticket_id, sender_role, message, created_at) VALUES (?,?,?,NOW())")
        ->execute([$id, $isAdmin ? 'admin' : 'contador', $note]);

    // notifica usuário quando fechar
    if (function_exists('notify_support_closed_for_user')) {
      @notify_support_closed_for_user($pdo, $id);
    }

    header("Location: /?page=support_view&id=".$id."&ok=1"); exit;
  }
}

// carrega mensagens
$ms = $pdo->prepare("SELECT * FROM support_messages WHERE ticket_id=? ORDER BY created_at ASC, id ASC");
$ms->execute([$id]);
$msgs = $ms->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Chamado #<?= (int)$t['id'] ?> — <?= esc($t['subject'] ?? '') ?></h1>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary" href="/?page=support">Voltar</a>
    <?php if (($t['status'] ?? '') !== 'finalizado'): ?>
      <form method="post" class="d-inline" onsubmit="return confirm('Finalizar este chamado?');">
        <input type="hidden" name="action" value="close">
        <button class="btn btn-danger">Finalizar</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php if (isset($_GET['ok'])): ?>
  <div class="alert alert-success">Ação realizada com sucesso.</div>
<?php endif; ?>
<?php if ($err): ?>
  <div class="alert alert-danger"><?= esc($err) ?></div>
<?php endif; ?>

<div class="card mb-3">
  <div class="card-body">
    <div><strong>Status:</strong> <?= status_badge((string)($t['status'] ?? '')) ?></div>
    <div><strong>Categoria:</strong> <?= esc(ucfirst((string)($t['category'] ?? ''))) ?></div>
    <div><strong>Cliente:</strong> <?= esc($t['user_name'] ?? ('#'.(int)$t['user_id'])) ?></div>
    <div><strong>Pedido:</strong>
      <?= !empty($t['order_id']) ? '<a href="/?page=order_detail&id='.(int)$t['order_id'].'">#'.(int)$t['order_id'].'</a>' : '—' ?>
    </div>
    <div><strong>Aberto em:</strong> <?= !empty($t['created_at']) ? esc(date('d/m/Y H:i', strtotime($t['created_at']))) : '—' ?></div>
  </div>
</div>

<div class="card mb-3">
  <div class="card-header">Mensagens</div>
  <div class="card-body">
    <?php if (!$msgs): ?>
      <div class="text-muted">Sem mensagens.</div>
    <?php else: foreach ($msgs as $m): ?>
      <div class="mb-3">
        <div class="small text-muted">
          <strong><?= ($m['sender_role'] ?? '') === 'admin' ? 'Suporte' : 'Cliente' ?></strong>
          — <?= !empty($m['created_at']) ? esc(date('d/m/Y H:i', strtotime($m['created_at']))) : '' ?>
        </div>
        <div><?= nl2br(esc($m['message'] ?? '')) ?></div>
      </div>
      <hr>
    <?php endforeach; endif; ?>
  </div>
</div>

<?php if (($t['status'] ?? '') !== 'finalizado'): ?>
<div class="card">
  <div class="card-header">Responder</div>
  <div class="card-body">
    <form method="post">
      <input type="hidden" name="action" value="reply">
      <div class="mb-3">
        <textarea name="message" rows="5" class="form-control" required></textarea>
      </div>
      <button class="btn btn-primary">Enviar</button>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../views/_footer.php';
