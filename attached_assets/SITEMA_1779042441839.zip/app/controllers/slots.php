<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

$date = $_GET['date'] ?? null; // YYYY-MM-DD
if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
  echo json_encode(['error' => 'invalid_date']); exit;
}

// Config da agenda (fáceis de ajustar no futuro)
$OPEN_HOUR  = 9;    // início 09:00
$CLOSE_HOUR = 15;   // último slot às 15:00
$STEP_MIN   = 30;   // intervalo 30 min

$tz = new DateTimeZone('America/Sao_Paulo');
$day = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $date . ' 00:00:00', $tz);
if (!$day) { echo json_encode(['error' => 'invalid_date']); exit; }

// Bloqueia sábado (6) e domingo (7)
$weekday = intval($day->format('N')); // 1=Seg ... 7=Dom
if ($weekday >= 6) {
  echo json_encode(['date' => $date, 'weekend' => true, 'slots' => []]); exit;
}

$start = new DateTimeImmutable($date . sprintf(' %02d:00:00', $OPEN_HOUR), $tz);
$end   = new DateTimeImmutable($date . sprintf(' %02d:00:00', $CLOSE_HOUR), $tz);
$step  = new DateInterval('PT' . $STEP_MIN . 'M');

$now = new DateTimeImmutable('now', $tz);
$isToday = $start->format('Y-m-d') === $now->format('Y-m-d');

// Marca como ocupados pedidos com estes status:
$q = $pdo->prepare("SELECT DATE_FORMAT(scheduled_at, '%Y-%m-%d %H:%i:00') AS s
                    FROM orders
                    WHERE DATE(scheduled_at)=?
                      AND status IN ('pending_payment','paid','protocol_assigned','completed')");
$q->execute([$date]);
$busy = array_fill_keys(array_map(fn($r)=>$r['s'], $q->fetchAll()), true);

// Gera slots
$out = [];
for ($t = $start; $t <= $end; $t = $t->add($step)) {
  $key = $t->format('Y-m-d H:i:00');
  $label = $t->format('H:i');
  $available = !isset($busy[$key]);
  if ($isToday && $t <= $now) $available = false;
  $out[] = ['value' => $key, 'label' => $label, 'available' => $available];
}

echo json_encode(['date' => $date, 'slots' => $out, 'weekend' => false]);
