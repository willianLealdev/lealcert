<?php
include __DIR__ . '/../views/_header.php';
$models = $pdo->query("SELECT * FROM certificate_models WHERE active=1 ORDER BY id DESC")->fetchAll();
?>
<h1 class="h4 mb-3">Modelos de Certificado</h1>
<div class="row g-3">
<?php foreach ($models as $m): ?>
  <div class="col-md-6 col-lg-4">
    <div class="card shadow-sm h-100">
      <div class="card-body d-flex flex-column">
        <h5 class="card-title"><?= sanitize($m['name']) ?></h5>
        <p class="card-text flex-grow-1"><?= sanitize($m['description']) ?></p>
        <div class="h5 mb-3">R$ <?= number_format($m['price'],2,',','.') ?></div>
        <a href="/?page=new_order&model_id=<?= $m['id'] ?>" class="btn btn-primary mt-auto">Comprar</a>
      </div>
    </div>
  </div>
<?php endforeach; ?>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
