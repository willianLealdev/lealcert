<?php
ini_set('display_errors','1'); error_reporting(E_ALL);
require_once __DIR__ . '/../config.php'; // usa o mesmo PDO do app
header('Content-Type: text/plain; charset=utf-8');

try {
  $pdo->query("SELECT 1");
  echo "DB: OK (conectou)\n";
  $pdo->exec("CREATE TABLE IF NOT EXISTS diag_ping (
    id INT AUTO_INCREMENT PRIMARY KEY,
    created_at DATETIME,
    note VARCHAR(255)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $st = $pdo->prepare("INSERT INTO diag_ping (created_at, note) VALUES (NOW(), ?)");
  $st->execute(['hello']);
  echo "INSERT: OK (id=".(int)$pdo->lastInsertId().")\n";
} catch (Throwable $e) {
  echo "DB ERRO: " . $e->getMessage() . "\n";
}
