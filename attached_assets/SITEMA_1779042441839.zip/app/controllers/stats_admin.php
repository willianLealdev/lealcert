<?php
$rows = $pdo->query("SELECT DATE(created_at) d, COUNT(*) c FROM orders GROUP BY DATE(created_at) ORDER BY d DESC LIMIT 14")->fetchAll();
$rows = array_reverse($rows);
$labels = array_map(fn($r)=>date('d/m', strtotime($r['d'])), $rows);
$values = array_map(fn($r)=>(int)$r['c'], $rows);
header('Content-Type: application/json');
echo json_encode(['labels'=>$labels,'values'=>$values]);
