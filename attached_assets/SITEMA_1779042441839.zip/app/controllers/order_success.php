<?php include __DIR__ . '/../views/_header.php'; ?>
<div class="alert alert-success">Pagamento aprovado! Em breve o administrador incluirá seu número de protocolo para validação do certificado.</div>
<a href="/?page=orders_me" class="btn btn-primary">Meus Pedidos</a>
<?php include __DIR__ . '/../views/_footer.php'; ?>
