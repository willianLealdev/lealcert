<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

$id = intval($_GET['id'] ?? 0);
if (!$id) { http_response_code(400); echo json_encode(['error'=>'missing_id']); exit; }

$u = auth_user();

// agora traz também modelo (nome e preço)
$sql = "SELECT o.id, o.user_id, o.order_number, o.status, o.model_id, o.total,
               o.customer_name, o.customer_cpf_cnpj, o.customer_email, o.customer_phone,
               o.scheduled_at, o.cnh_path, o.protocol_number,
               o.mp_preference_id, o.mp_payment_id,
               m.name AS model_name, m.price AS model_price
        FROM orders o
        JOIN certificate_models m ON m.id=o.model_id
        WHERE o.id=? LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$o = $stmt->fetch();

if (!$o || intval($o['user_id']) !== intval($u['id'])) {
  http_response_code(403); echo json_encode(['error'=>'forbidden']); exit;
}

echo json_encode([
  'id'               => (int)$o['id'],
  'order_number'     => $o['order_number'],
  'status'           => $o['status'],
  'model_id'         => (int)$o['model_id'],
  'model_name'       => $o['model_name'],
  'model_price'      => (float)$o['model_price'],
  'total'            => (float)$o['total'],
  'customer_name'    => $o['customer_name'],
  'customer_cpf_cnpj'=> $o['customer_cpf_cnpj'],
  'customer_email'   => $o['customer_email'],
  'customer_phone'   => $o['customer_phone'],
  'scheduled_at'     => $o['scheduled_at'] ? date('Y-m-d H:i:00', strtotime($o['scheduled_at'])) : null,
  'cnh_path'         => $o['cnh_path'],
  'protocol_number'  => $o['protocol_number'],
  'mp_preference_id' => $o['mp_preference_id'],
  'mp_payment_id'    => $o['mp_payment_id'],
]);
