<?php
// app/controllers/admin_orders_sync_all.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

function sync_all_log($label,$data=[]) {
  try{
    $dir=__DIR__ . '/../../storage/logs';
    if(!is_dir($dir)) @mkdir($dir,0775,true);
    @file_put_contents($dir.'/sync_all.log','['.date('Y-m-d H:i:s')."] $label | ".json_encode($data,JSON_UNESCAPED_UNICODE).PHP_EOL,FILE_APPEND);
  }catch(Throwable $e){}
}

// Busca IDs de pedidos que merecem sincronizar (evita fazer em já concluídos)
$st = $pdo->query("SELECT id FROM orders WHERE status IN ('created','pending_payment')");
$ids = $st->fetchAll(PDO::FETCH_COLUMN, 0);

$totalChecked=0; $updated=0; $errors=0;

foreach ($ids as $id) {
  $totalChecked++;
  // consulta o pagamento por external_reference
  $ch = curl_init();
  curl_setopt_array($ch, [
    CURLOPT_URL            => "https://api.mercadopago.com/v1/payments/search?sort=date_created&criteria=desc&external_reference=" . urlencode((string)$id),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
      "Authorization: Bearer " . MP_ACCESS_TOKEN,
      "Content-Type: application/json"
    ],
    CURLOPT_TIMEOUT        => 20,
  ]);
  $body = curl_exec($ch);
  $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err  = curl_error($ch);
  curl_close($ch);

  if ((int)$http !== 200) { $errors++; sync_all_log('search_http_error',['id'=>$id,'http'=>$http,'err'=>$err]); continue; }

  $j = json_decode($body,true);
  $res = $j['results'][0] ?? null;
  if (!$res) { continue; } // sem pagamento encontrado

  $mpid     = $res['id'] ?? null;
  $statusMp = $res['status'] ?? null;
  $total    = $res['transaction_amount'] ?? null;

  $newStatus = 'pending_payment';
  if ($statusMp === 'approved') $newStatus='paid';
  elseif (in_array($statusMp, ['pending','in_process'],true)) $newStatus='pending_payment';

  try {
    $sql = "UPDATE orders SET status=:st, updated_at=NOW()";
    $params = [':st'=>$newStatus, ':id'=>$id];
    if ($mpid)  { $sql .= ", mp_payment_id=:mpid"; $params[':mpid']=(string)$mpid; }
    if ($total) { $sql .= ", total=:tot";         $params[':tot']=(float)$total; }
    $sql .= " WHERE id=:id";
    $upd = $pdo->prepare($sql);
    $upd->execute($params);
    $updated++;
  } catch(Throwable $e) {
    $errors++; sync_all_log('update_error',['id'=>$id,'err'=>$e->getMessage()]);
  }
}

sync_all_log('done',['checked'=>$totalChecked,'updated'=>$updated,'errors'=>$errors]);
header('Location: /?page=admin_orders&msg=synced_all&checked='.$totalChecked.'&updated='.$updated.'&errors='.$errors);
exit;
