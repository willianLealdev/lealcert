<?php
// app/controllers/admin_order_edit.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

$h = function($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); };
$moneyFmt = function($v){ return number_format((float)$v, 2, ',', '.'); };

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

// carrega pedido
$st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st->execute([$id]);
$order = $st->fetch();
if (!$order) { http_response_code(404); echo "Pedido não encontrado."; exit; }

$flashOk = $flashErr = null;

// salvar alterações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // captura campos
  $order_number = trim($_POST['order_number'] ?? ($order['order_number'] ?? ''));
  $status       = trim($_POST['status']       ?? ($order['status'] ?? 'created'));
  $protocol     = trim($_POST['protocol_number'] ?? ($order['protocol_number'] ?? ''));
  $total        = str_replace([','], ['.'], trim($_POST['total'] ?? (string)($order['total'] ?? 0)));

  $customer_name  = trim($_POST['customer_name']  ?? ($order['customer_name']  ?? ''));
  $customer_email = trim($_POST['customer_email'] ?? ($order['customer_email'] ?? ''));
  $customer_phone = trim($_POST['customer_phone'] ?? ($order['customer_phone'] ?? ''));
  $doc            = trim($_POST['customer_cpf_cnpj'] ?? ($order['customer_cpf_cnpj'] ?? ''));
  $razao          = trim($_POST['RAZAOSOCIAL']      ?? ($order['RAZAOSOCIAL'] ?? ''));
  $cnpj           = trim($_POST['CNPJ']             ?? ($order['CNPJ'] ?? ''));
  $inss           = trim($_POST['inss_number']      ?? ($order['inss_number'] ?? ''));

  // datetime-local -> Y-m-d H:i:s
  $sched_local = trim($_POST['scheduled_at'] ?? '');
  if ($sched_local !== '') {
    // vem como 2025-08-15T14:30
    $scheduled_at = str_replace('T', ' ', $sched_local) . ':00';
  } else {
    $scheduled_at = null;
  }

  // snapshot anterior p/ lógica de e-mail
  $status_before = trim($order['status'] ?? '');
  $proto_before  = trim($order['protocol_number'] ?? '');

  // upload de CNH opcional (PDF até 5MB)
  $cnh_path = $order['cnh_path'] ?? null;
  if (!empty($_FILES['cnh_file']['name']) && is_uploaded_file($_FILES['cnh_file']['tmp_name'])) {
    if ((int)$_FILES['cnh_file']['size'] > 5*1024*1024) {
      $flashErr = "CNH acima de 5MB.";
    } else {
      $fi = new finfo(FILEINFO_MIME_TYPE);
      $mime = $fi->file($_FILES['cnh_file']['tmp_name']);
      if ($mime !== 'application/pdf') {
        $flashErr = "A CNH deve ser PDF.";
      } else {
        $dir = __DIR__ . '/../../storage/uploads/cnh';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $fname = 'cnh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.pdf';
        $dest = $dir . '/' . $fname;
        if (move_uploaded_file($_FILES['cnh_file']['tmp_name'], $dest)) {
          $cnh_path = 'storage/uploads/cnh/'.$fname;
        } else {
          $flashErr = "Falha ao salvar CNH.";
        }
      }
    }
  }

  if (!$flashErr) {
    try {
      // se protocolo informado e status ainda não for protocol_assigned, força
      if ($protocol !== '' && $status !== 'protocol_assigned') {
        $status = 'protocol_assigned';
      }

      $sql = "UPDATE orders SET
                order_number=?,
                status=?,
                protocol_number=?,
                total=?,
                scheduled_at=?,
                customer_name=?,
                customer_email=?,
                customer_phone=?,
                customer_cpf_cnpj=?,
                RAZAOSOCIAL=?,
                CNPJ=?,
                inss_number=?,
                updated_at=NOW()";
      $params = [
        $order_number,
        $status,
        $protocol,
        (float)$total,
        $scheduled_at,
        $customer_name,
        $customer_email,
        $customer_phone,
        $doc,
        $razao,
        $cnpj,
        $inss
      ];

      if ($cnh_path !== null) {
        $sql .= ", cnh_path=?";
        $params[] = $cnh_path;
      }
      $sql .= " WHERE id=?";

      $params[] = $id;
      $up = $pdo->prepare($sql);
      $up->execute($params);

      $flashOk = "Pedido atualizado com sucesso.";

      // recarrega
      $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
      $st->execute([$id]);
      $order = $st->fetch();

      // decide se manda e-mail
      $fireMail = false;
      if ($status === 'protocol_assigned' && $status_before !== 'protocol_assigned') $fireMail = true;
      if ($protocol !== '' && $protocol !== $proto_before) $fireMail = true;

      if ($fireMail) {
        if (function_exists('notify_protocol_assigned')) {
          @notify_protocol_assigned($pdo, (int)$id);
        } elseif (function_exists('notify_protoco_assigned')) {
          @notify_protoco_assigned($pdo, (int)$id);
        }
      }

    } catch (Throwable $e) {
      $flashErr = "Falha ao salvar: " . $e->getMessage();
    }
  }
}

include __DIR__ . '/../views/_header.php';

// preenche campos p/ o form
$dt_local = '';
if (!empty($order['scheduled_at'])) {
  $dt_local = date('Y-m-d\TH:i', strtotime($order['scheduled_at']));
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h5 mb-0">Editar Pedido — <?= $h($order['order_number'] ?? ('#'.$id)) ?></h1>
  <div>
    <a class="btn btn-outline-secondary" href="/?page=admin_orders">Voltar</a>
    <a class="btn btn-outline-info" href="/?page=order_detail&id=<?= (int)$id ?>">Ver Detalhes</a>
    <a class="btn btn-outline-dark" href="/?page=checkout&id=<?= (int)$id ?>">Checkout</a>
  </div>
</div>

<?php if ($flashOk): ?>
  <div class="alert alert-success"><?= $h($flashOk) ?></div>
<?php endif; ?>
<?php if ($flashErr): ?>
  <div class="alert alert-danger"><?= $h($flashErr) ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Pedido</div>
      <div class="card-body">
        <div class="mb-3">
          <label class="form-label">Número do Pedido</label>
          <input type="text" name="order_number" class="form-control" value="<?= $h($order['order_number'] ?? '') ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php
              $opts = [
                'created'           => 'Criado',
                'pending_payment'   => 'Aguardando pagamento',
                'paid'              => 'Pago',
                'protocol_assigned' => 'Protocolo',
                'completed'         => 'Concluído'
              ];
              $cur = $order['status'] ?? 'created';
              foreach ($opts as $val=>$label):
            ?>
              <option value="<?= $h($val) ?>" <?= $val===$cur?'selected':'' ?>><?= $h($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Protocolo</label>
          <input type="text" name="protocol_number" class="form-control" value="<?= $h($order['protocol_number'] ?? '') ?>">
          <div class="form-text">Ao preencher um protocolo, o status será ajustado para <strong>Protocolo</strong> e será enviado e-mail ao contador.</div>
        </div>

        <div class="mb-3">
          <label class="form-label">Agendamento</label>
          <input type="datetime-local" name="scheduled_at" class="form-control" value="<?= $h($dt_local) ?>">
        </div>

        <div class="mb-0">
          <label class="form-label">Total (R$)</label>
          <input type="number" step="0.01" name="total" class="form-control" value="<?= $h((string)($order['total'] ?? 0)) ?>">
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Cliente / Empresa</div>
      <div class="card-body">
        <div class="mb-3">
          <label class="form-label">Nome do Cliente</label>
          <input type="text" name="customer_name" class="form-control" value="<?= $h($order['customer_name'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">E-mail</label>
          <input type="email" name="customer_email" class="form-control" value="<?= $h($order['customer_email'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Telefone</label>
          <input type="text" name="customer_phone" class="form-control" value="<?= $h($order['customer_phone'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">CPF/CNPJ (Titular)</label>
          <input type="text" name="customer_cpf_cnpj" class="form-control" value="<?= $h($order['customer_cpf_cnpj'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Razão Social</label>
          <input type="text" name="RAZAOSOCIAL" class="form-control" value="<?= $h($order['RAZAOSOCIAL'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">CNPJ</label>
          <input type="text" name="CNPJ" class="form-control" value="<?= $h($order['CNPJ'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Nº INSS (CEI/CAEPF/CNO)</label>
          <input type="text" name="inss_number" class="form-control" value="<?= $h($order['inss_number'] ?? '') ?>">
        </div>
        <div class="mb-0">
          <label class="form-label">Substituir CNH (PDF até 5MB)</label>
          <input type="file" name="cnh_file" class="form-control" accept="application/pdf">
          <?php if (!empty($order['cnh_path'])): ?>
            <div class="form-text">Arquivo atual: <a href="/<?= $h($order['cnh_path']) ?>" target="_blank">abrir</a></div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 d-grid">
    <button class="btn btn-primary btn-lg" type="submit">Salvar Alterações</button>
  </div>
</form>

<?php include __DIR__ . '/../views/_footer.php';
