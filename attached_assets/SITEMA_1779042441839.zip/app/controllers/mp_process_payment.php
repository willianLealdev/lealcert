<?php
// app/controllers/mp_process_payment.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

header('Content-Type: application/json');

/* --------- util --------- */
function ridie_jexit(array $arr){ echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function ridie_digits($v){ return preg_replace('/\D+/', '', (string)$v); }
function ridie_log($msg){
  try {
    $dir = __DIR__ . '/../../storage';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($dir.'/mp_debug.log', date('c').' '.$msg."\n", FILE_APPEND);
  } catch(Throwable $e){}
}

/* leitura segura de estrutura aninhada */
function _get_in($arr, $path){
  if (!is_array($arr)) return null;
  $keys = is_array($path) ? $path : explode('.', (string)$path);
  $cur = $arr;
  foreach ($keys as $k) {
    if (!is_array($cur) || !array_key_exists($k,$cur)) return null;
    $cur = $cur[$k];
  }
  return $cur;
}
function _first_non_empty($arr, $paths){
  foreach ($paths as $p){
    $alts = is_array($p) ? $p : (strpos($p,'|')!==false ? explode('|',$p) : [$p]);
    foreach ($alts as $pp){
      $v = _get_in($arr, $pp);
      if ($v !== null && $v !== '') return $v;
    }
  }
  return null;
}
function _ord_first($order, array $cands){
  foreach ($cands as $c){
    if (isset($order[$c]) && $order[$c] !== '') return $order[$c];
  }
  return null;
}

/* --------- autenticação/owner --------- */
$user    = auth_user();
$uid     = (int)($user['id'] ?? 0);
$isAdmin = (($user['role'] ?? '') === 'admin');

$orderId = (int)($_GET['id'] ?? 0);
if ($orderId <= 0) ridie_jexit(['ok'=>false,'error'=>'Pedido inválido.']);

if ($isAdmin) {
  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
  $st->execute([$orderId]);
} else {
  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? AND user_id=? LIMIT 1");
  $st->execute([$orderId, $uid]);
}
$order = $st->fetch(PDO::FETCH_ASSOC);
if (!$order) ridie_jexit(['ok'=>false,'error'=>'Pedido não encontrado.']);

/* --------- corpo recebido do Brick --------- */
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) $body = [];

ridie_log("REQ id=$orderId body=".substr($raw ?? '',0,500));

/* --------- valor --------- */
$amount = _first_non_empty($body, [
  'transaction_amount|transactionAmount',
  'payment.transaction_amount|payment.transactionAmount',
  'formData.transaction_amount|formData.transactionAmount',
]) ?? ($order['total'] ?? $order['total_amount'] ?? 0);
$amount = round((float)$amount, 2);
if ($amount <= 0) ridie_jexit(['ok'=>false,'error'=>'Valor inválido.']);

/* --------- método (PIX/BOLETO) --------- */
$paymentData = $body['formData'] ?? $body;
$pmid  = _first_non_empty($paymentData, [
  'payment_method_id|paymentMethodId',
  'payment.payment_method_id|payment.paymentMethodId',
  'payment_method.id'
]);
$ptype = _first_non_empty($paymentData, [
  'payment_type_id|paymentTypeId|payment_type',
  'payment.payment_type_id|payment.paymentTypeId',
  'payment_method.payment_type_id'
]);
$pmid  = is_string($pmid)  ? strtolower($pmid)  : null;
$ptype = is_string($ptype) ? strtolower($ptype) : null;

$method = $pmid ?: null;
if (!$method && $ptype) {
  if ($ptype === 'bank_transfer') $method = 'pix';
  elseif ($ptype === 'ticket')    $method = 'bolbradesco';
}
if ($method === 'ticket') $method = 'bolbradesco';

$allowed = ['pix','bolbradesco','bolbradesco_v2','pec','pec_v1'];
if (!in_array((string)$method, $allowed, true)) {
  ridie_jexit(['ok'=>false,'error'=>'Método inválido/indisponível. Selecione Pix ou Boleto.','debug'=>['pmid'=>$pmid,'ptype'=>$ptype,'method'=>$method]]);
}

/* --------- pagador --------- */
$payerEmail = _first_non_empty($body, [
  'payer.email','payment.payer.email','formData.payer.email','email'
]) ?: ($order['customer_email'] ?? ($user['email'] ?? ''));
if (!$payerEmail) ridie_jexit(['ok'=>false,'error'=>'E-mail do pagador ausente.']);

/* dados básicos */
$orderNo   = $order['order_number'] ?: ('#'.$orderId);
$desc      = 'Pedido '.$orderNo;
$extRef    = 'order-'.$orderId;

/* Nome (só melhora boleto) */
$fullName  = $user['name'] ?? ($user['full_name'] ?? ($order['customer_name'] ?? $order['client_name'] ?? 'Cliente'));
$parts     = preg_split('/\s+/', trim($fullName));
$firstName = $parts[0] ?? 'Cliente';
$lastName  = trim(implode(' ', array_slice($parts, 1))) ?: 'RIDIECERT';

/* payload base */
$payload = [
  'transaction_amount' => $amount,
  'description'        => $desc,
  'external_reference' => $extRef,
  'payer'              => [
    'email'      => $payerEmail,
    'first_name' => $firstName,
    'last_name'  => $lastName,
  ],
  'payment_method_id'  => $method,
];

/* boleto precisa de doc + endereço */
if ($method !== 'pix') {
  $docType   = _first_non_empty($body, ['payer.identification.type','payment.payer.identification.type','formData.payer.identification.type']);
  $docNumber = _first_non_empty($body, ['payer.identification.number','payment.payer.identification.number','formData.payer.identification.number']);

  if (!$docNumber) {
    $docNumber = _ord_first($order, [
      'customer_cpf_cnpj','client_cpf_cnpj','client_cpf','cpf','company_cnpj','cnpj'
    ]);
  }
  $docNumber = ridie_digits($docNumber);
  if (!$docType) {
    $docType = (strlen($docNumber) === 14) ? 'CNPJ' : 'CPF';
  }

  $zip_code      = ridie_digits(_ord_first($order, ['address_zipcode','cep']));
  $street_name   = _ord_first($order, ['address_street','rua']);
  $street_number = (string)_ord_first($order, ['address_number','numero']);
  $neighborhood  = _ord_first($order, ['address_neighborhood','bairro']);
  $city          = _ord_first($order, ['address_city','cidade']);
  $federal_unit  = strtoupper((string)_ord_first($order, ['address_state','estado','uf']));

  if (!$docNumber || !in_array($docType, ['CPF','CNPJ'], true)) {
    ridie_jexit(['ok'=>false,'error'=>'Documento do pagador ausente/ inválido para boleto (CPF/CNPJ).']);
  }
  if (!$zip_code || !$street_name || !$street_number || !$neighborhood || !$city || !$federal_unit) {
    ridie_jexit(['ok'=>false,'error'=>'Endereço do pagador incompleto para boleto (CEP, rua, número, bairro, cidade, UF).']);
  }

  $payload['payer']['identification'] = [
    'type'   => $docType,
    'number' => $docNumber,
  ];
  $payload['payer']['address'] = [
    'zip_code'      => $zip_code,
    'street_name'   => $street_name,
    'street_number' => $street_number,
    'neighborhood'  => $neighborhood,
    'city'          => $city,
    'federal_unit'  => $federal_unit,
  ];
}

/* webhook (se tiver) */
$site   = getenv('SITE_URL') ?: (defined('SITE_URL') ? SITE_URL : '');
$secret = getenv('WEBHOOK_SECRET') ?: (defined('WEBHOOK_SECRET') ? WEBHOOK_SECRET : '');
if ($site && $secret) {
  $payload['notification_url'] = rtrim($site,'/').'/?page=mp_webhook&secret='.urlencode($secret);
}

/* token */
$token = getenv('MP_ACCESS_TOKEN') ?: (defined('MP_ACCESS_TOKEN') ? MP_ACCESS_TOKEN : '');
if (!$token) ridie_jexit(['ok'=>false,'error'=>'ACCESS_TOKEN ausente.']);

/* idempotência (por minuto, método e valor) */
$idemp = 'order-'.$orderId.'-'.md5($orderId.'|'.$amount.'|'.$method.'|'.date('YmdHi'));

/* chamada à API */
$ch = curl_init('https://api.mercadopago.com/v1/payments');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => [
    'Authorization: Bearer '.$token,
    'Content-Type: application/json',
    'X-Idempotency-Key: '.$idemp,
  ],
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
  CURLOPT_TIMEOUT => 30,
]);
$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err  = curl_error($ch);
curl_close($ch);

if ($resp === false) {
  ridie_log("CURL ERR id=$orderId http=$http err=$err");
  ridie_jexit(['ok'=>false,'error'=>'Falha de comunicação com o Mercado Pago: '.$err]);
}

$data = json_decode($resp, true);
if ($http >= 400 || !is_array($data)) {
  $msg = 'Erro MP (HTTP '.$http.')';
  if (isset($data['message'])) $msg .= ': '.$data['message'];
  if (!empty($data['cause'][0]['description'])) $msg .= ' — '.$data['cause'][0]['description'];
  ridie_log("MP ERR id=$orderId http=$http resp=".substr($resp,0,500));
  ridie_jexit(['ok'=>false,'error'=>$msg,'raw'=>$data]);
}

/* atualiza pedido */
$mpStatus = $data['status'] ?? 'pending';
$mpId     = $data['id']      ?? null;
try {
  $newSt = ($mpStatus === 'approved') ? 'paid' : 'pending_payment';
  $up = $pdo->prepare("UPDATE orders SET mp_payment_id=:mp, status=:st WHERE id=:id");
  $up->execute([':mp'=>$mpId, ':st'=>$newSt, ':id'=>$orderId]);
} catch(Throwable $e){}

/* resposta para o front */
$out = [
  'ok'                 => true,
  'status'             => $mpStatus,
  'id'                 => $mpId,
  'payment_method_id'  => $method,
  'payment_type_id'    => $ptype,
];

$poi = $data['point_of_interaction']['transaction_data'] ?? null;
if (is_array($poi)) {
  $out['point_of_interaction'] = [
    'transaction_data' => [
      'qr_code_base64' => $poi['qr_code_base64'] ?? null,
      'qr_code'        => $poi['qr_code']        ?? null,
      'ticket_url'     => $poi['ticket_url']     ?? null,
    ],
  ];
}
$ticketFallback = $data['transaction_details']['external_resource_url'] ?? null;
if ($ticketFallback) {
  if (!isset($out['point_of_interaction'])) $out['point_of_interaction'] = ['transaction_data'=>[]];
  if (empty($out['point_of_interaction']['transaction_data']['ticket_url'])) {
    $out['point_of_interaction']['transaction_data']['ticket_url'] = $ticketFallback;
  }
}

ridie_log("OK id=$orderId method=$method status=$mpStatus idmp=$mpId");
ridie_jexit($out);
