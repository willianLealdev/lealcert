<?php
// app/controllers/admin_orders.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

function aorders_sanitize($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$q         = trim($_GET['q'] ?? '');
$status    = trim($_GET['status'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to'] ?? '');

$where = [];
$params = [];

if ($q !== '') {
  $where[] = "(o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_email LIKE ? OR o.customer_phone LIKE ? OR o.customer_cpf_cnpj LIKE ? OR o.RAZAOSOCIAL LIKE ? OR o.CNPJ LIKE ? OR o.protocol_number LIKE ?)";
  $like = "%$q%";
  array_push($params, $like, $like, $like, $like, $like, $like, $like, $like);
}
if ($status !== '') { $where[] = "o.status = ?"; $params[] = $status; }
if ($date_from !== '') { $where[] = "DATE(o.created_at) >= ?"; $params[] = $date_from; }
if ($date_to   !== '') { $where[] = "DATE(o.created_at) <= ?"; $params[] = $date_to; }

$sql = "SELECT o.*, u.name AS user_name
        FROM orders o
        LEFT JOIN users u ON u.id=o.user_id";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY o.created_at DESC LIMIT 500";

$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Pedidos (Admin)</h1>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-warning" href="/?page=admin_orders_sync_all">🔄 Sincronizar todos</a>
    <a class="btn btn-outline-secondary" href="/?page=admin_dashboard">Voltar ao dashboard</a>
  </div>
</div>

<form class="row g-2 mb-3" method="get">
  <input type="hidden" name="page" value="admin_orders">
  <div class="col-md-4">
    <input type="text" class="form-control" name="q" placeholder="Buscar (pedido, cliente, e-mail, CPF/CNPJ, razão, telefone, protocolo)" value="<?= aorders_sanitize($q) ?>">
  </div>
  <div class="col-md-2">
    <select class="form-select" name="status">
      <option value="">-- Status --</option>
      <?php
        $opts = ['created'=>'Criado','pending_payment'=>'Aguardando pagamento','paid'=>'Pago','protocol_assigned'=>'Protocolo','completed'=>'Concluído'];
        foreach ($opts as $k=>$v) {
          $sel = $status===$k ? 'selected' : '';
          echo "<option value=\"$k\" $sel>$v</option>";
        }
      ?>
    </select>
  </div>
  <div class="col-md-2">
    <input type="date" class="form-control" name="date_from" value="<?= aorders_sanitize($date_from) ?>">
  </div>
  <div class="col-md-2">
    <input type="date" class="form-control" name="date_to" value="<?= aorders_sanitize($date_to) ?>">
  </div>
  <div class="col-md-2 d-grid">
    <button class="btn btn-primary">Filtrar</button>
  </div>
</form>

<div class="table-responsive">
  <table class="table table-sm align-middle">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Pedido</th>
        <th>Cliente</th>
        <th>Doc</th>
        <th>Razão/CNPJ</th>
        <th>Agendamento</th>
        <th>Total</th>
        <th>Protocolo</th>
        <th>Status</th>
        <th>Contador</th>
        <th>Criado</th>
        <th class="text-end">Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="12" class="text-center text-muted py-4">Nenhum pedido encontrado.</td></tr>
      <?php else: foreach ($rows as $r):
        $ag = $r['scheduled_at'] ? date('d/m/Y H:i', strtotime($r['scheduled_at'])) : '—';
        $tot = number_format((float)$r['total'], 2, ',', '.');
        $statusLabel = [
          'created'=>'Criado',
          'pending_payment'=>'Aguardando pagamento',
          'paid'=>'Pago',
          'protocol_assigned'=>'Protocolo',
          'completed'=>'Concluído'
        ][$r['status']] ?? $r['status'];
        $doc = $r['customer_cpf_cnpj'] ?: '—';
        $razao = $r['RAZAOSOCIAL'] ?: '—';
        $cnpj  = $r['CNPJ'] ?: '';
        if ($cnpj) $razao .= " / $cnpj";
        $proto = $r['protocol_number'] ?: '—';
      ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><a href="/?page=order_detail&id=<?= (int)$r['id'] ?>"><?= aorders_sanitize($r['order_number']) ?></a></td>
        <td><?= aorders_sanitize($r['customer_name']) ?></td>
        <td><?= aorders_sanitize($doc) ?></td>
        <td><?= aorders_sanitize($razao) ?></td>
        <td><?= aorders_sanitize($ag) ?></td>
        <td>R$ <?= $tot ?></td>
        <td><?= aorders_sanitize($proto) ?></td>
        <td><?= aorders_sanitize($statusLabel) ?></td>
        <td><?= aorders_sanitize($r['user_name'] ?? ('#'.$r['user_id'])) ?></td>
        <td><?= aorders_sanitize(date('d/m/Y H:i', strtotime($r['created_at'] ?? 'now'))) ?></td>
        <td class="text-end">
          <div class="btn-group btn-group-sm">
            <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$r['id'] ?>">Detalhes</a>
            <a class="btn btn-outline-primary" href="/?page=admin_order_edit&id=<?= (int)$r['id'] ?>">Editar</a>
            <a class="btn btn-outline-danger" href="/?page=admin_order_delete&id=<?= (int)$r['id'] ?>"
               onclick="return confirm('Excluir pedido #<?= aorders_sanitize($r['order_number']) ?>? Esta ação não pode ser desfeita.');">
               Excluir
            </a>
          </div>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../views/_footer.php';
