<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
$usr = auth_user();

$name = trim($_POST['name'] ?? '');
$email= trim($_POST['email'] ?? '');
$city = trim($_POST['city'] ?? '');
$state= strtoupper(trim($_POST['state'] ?? ''));
$office_phone = trim($_POST['office_phone'] ?? '');
$company_name = trim($_POST['company_name'] ?? '');
$company_cnpj = trim($_POST['company_cnpj'] ?? '');

$avatar_path = $usr['avatar_path'] ?? null;

if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
  $tmp = $_FILES['avatar']['tmp_name'];
  $size= (int)$_FILES['avatar']['size'];
  $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
  if ($size > 0 && $size <= 2*1024*1024 && in_array($ext,['png','jpg','jpeg'])) {
    $dir = __DIR__ . '/../../storage/uploads/avatars';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $fname = uniqid('ava_').'.'.($ext==='jpeg'?'jpg':$ext);
    if (@move_uploaded_file($tmp, $dir.'/'.$fname)) {
      // remove anterior
      if (!empty($avatar_path)) {
        $old = $dir.'/'.basename($avatar_path);
        if (is_file($old)) @unlink($old);
      }
      $avatar_path = $fname;
    }
  }
}

$st = $pdo->prepare("UPDATE users
  SET name=?, email=?, city=?, state=?, office_phone=?, company_name=?, company_cnpj=?, avatar_path=?
  WHERE id=?");
$st->execute([$name,$email,$city,$state,$office_phone,$company_name,$company_cnpj,$avatar_path,$usr['id']]);

redirect('/?page=profile&saved=1');
