<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

$cpf = $_POST['cpf_cnpj'] ?? '';
$pwd = $_POST['password'] ?? '';

if (!auth_login($cpf, $pwd)) {
  $msg = $_SESSION['LOGIN_BLOCKED'] ?? 'CPF/CNPJ ou senha inválidos.';
  unset($_SESSION['LOGIN_BLOCKED']);
  redirect('/?page=login&err=' . urlencode($msg));
}

$user = auth_user();
if ($user && ($user['role'] ?? '') === 'admin') {
  redirect('/?page=admin_dashboard');
}
redirect('/?page=contador_dashboard');
