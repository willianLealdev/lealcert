<?php
// app/controllers/orders_probe.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

header('Content-Type: text/plain; charset=utf-8');

try {
  // 1) Pega um modelo válido (certificate_models ou products)
  $model_id = (int)($_GET['model_id'] ?? 0);
  if ($model_id <= 0) {
    $model_id = (int)$pdo->query("SELECT id FROM certificate_models LIMIT 1")->fetchColumn();
    if ($model_id <= 0) {
      $model_id = (int)$pdo->query("SELECT id FROM products LIMIT 1")->fetchColumn();
    }
  }
  if ($model_id <= 0) {
    echo "ERRO: não há modelos em certificate_models/products.\n";
    exit;
  }

  // 2) Gera order_number
  $date = date('Ymd');
  $c = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE DATE(created_at)=CURDATE()")->fetchColumn()+1;
  $order_number = $date.'-'.str_pad((string)$c,4,'0',STR_PAD_LEFT);

  // 3) Monta INSERT EXATO nas colunas que você tem
  $sql = "INSERT INTO orders
    (user_id, model_id, status, order_number, total,
     customer_name, customer_email, customer_phone, customer_cpf_cnpj,
     RAZAOSOCIAL, CNPJ, inss_number, cnh_path, scheduled_at,
     created_at, updated_at)
    VALUES
    (:user_id, :model_id, :status, :order_number, :total,
     :customer_name, :customer_email, :customer_phone, :customer_cpf_cnpj,
     :RAZAOSOCIAL, :CNPJ, :inss_number, :cnh_path, :scheduled_at,
     NOW(), NOW())";

  $user = auth_user();
  $st = $pdo->prepare($sql);
  $st->execute([
    ':user_id'           => (int)($user['id'] ?? 0),
    ':model_id'          => $model_id,
    ':status'            => 'pending_payment',
    ':order_number'      => $order_number,
    ':total'             => 0.00,
    ':customer_name'     => 'Probe Cliente',
    ':customer_email'    => 'probe@rediecert.com.br',
    ':customer_phone'    => '00000000000',
    ':customer_cpf_cnpj' => '00000000000',
    ':RAZAOSOCIAL'       => null,
    ':CNPJ'              => null,
    ':inss_number'       => null,
    ':cnh_path'          => 'storage/uploads/cnh/probe.pdf',
    ':scheduled_at'      => date('Y-m-d 14:00:00'),
  ]);

  $order_id = (int)$pdo->lastInsertId();
  echo "OK: inseriu pedido de teste (id=$order_id, order_number=$order_number)\n";
  echo "Checkout (se quiser testar MP depois): /?page=checkout&id=$order_id\n";

} catch (Throwable $e) {
  echo "ERRO INSERT orders: ".$e->getMessage()."\n";
}
