<?php
// app/controllers/do_new_order.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();


/* ================== helpers de schema (sem sobrescrever) ================== */
if (!function_exists('table_exists')) {
  function table_exists(PDO $pdo, string $t): bool {
    try { $pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true; }
    catch (Throwable $e) { return false; }
  }
}
if (!function_exists('col_exists')) {
  function col_exists(PDO $pdo, string $t, string $c): bool {
    try { return (bool)$pdo->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->fetch(); }
    catch (Throwable $e) { return false; }
  }
}
if (!function_exists('pick_col')) {
  function pick_col(PDO $pdo, string $t, array $cands, ?string $fallback=null): ?string {
    foreach ($cands as $c) { if (col_exists($pdo,$t,$c)) return $c; }
    return $fallback;
  }
}
if (!function_exists('only_digits')) {
  function only_digits($v): string {
    return preg_replace('/[^0-9]/', '', (string)$v);
  }
}
/* Conversor robusto de preço */
if (!function_exists('ridie_parse_price')) {
  function ridie_parse_price($v): float {
    if (is_numeric($v)) return (float)$v;
    $s = preg_replace('/[^\d,.\-]/', '', (string)$v);
    if ($s === '' || $s === null) return 0.0;
    $hasDot   = strpos($s, '.') !== false;
    $hasComma = strpos($s, ',') !== false;

    if ($hasComma && !$hasDot) {          // "90,00"
      $s = str_replace('.', '', $s);
      $s = str_replace(',', '.', $s);
      return (float)$s;
    }
    if ($hasDot && !$hasComma) {          // "90.00"
      return (float)$s;
    }
    if ($hasDot && $hasComma) {           // "1.234,56" ou "1,234.56"
      $lastDot  = strrpos($s, '.');
      $lastComma= strrpos($s, ',');
      if ($lastComma > $lastDot) {        // "1.234,56"
        $s = str_replace('.', '', $s);
        $s = str_replace(',', '.', $s);
        return (float)$s;
      } else {                            // "1,234.56"
        $s = str_replace(',', '', $s);
        return (float)$s;
      }
    }
    return (float)$s;
  }
}

/* ================== captura ================== */
$user      = auth_user();
$user_id   = (int)($user['id'] ?? 0);

$model_id          = (int)($_POST['model_id'] ?? 0);
$model_type        = $_POST['model_type'] ?? 'cpf';
$client_name       = trim($_POST['client_name'] ?? '');
$client_cpf        = only_digits($_POST['client_cpf'] ?? '');
$client_email      = trim($_POST['client_email'] ?? '');
$client_phone      = trim($_POST['client_phone'] ?? '');
$company_name      = trim($_POST['company_name'] ?? '');
$company_cnpj      = only_digits($_POST['company_cnpj'] ?? '');
$inss_number       = trim($_POST['inss_number'] ?? '');
$schedule_at       = trim($_POST['schedule_at'] ?? '');
$schedule_date     = trim($_POST['schedule_date'] ?? '');
$schedule_time     = trim($_POST['schedule_time'] ?? '');
$extended_warranty = ($_POST['extended_warranty'] ?? '0') === '1';

// ENDEREÇO
$address_zipcode      = trim($_POST['address_zipcode'] ?? '');
$address_street       = trim($_POST['address_street'] ?? '');
$address_number       = trim($_POST['address_number'] ?? '');
$address_neighborhood = trim($_POST['address_neighborhood'] ?? '');
$address_city         = trim($_POST['address_city'] ?? '');
$address_state        = trim($_POST['address_state'] ?? '');

/* monta schedule_at se veio separado */
if (!$schedule_at && $schedule_date && $schedule_time) {
  $schedule_at = $schedule_date.' '.$schedule_time.':00';
}

/* ================== validações ================== */
$errors = [];
if ($model_id <= 0) $errors[] = 'Modelo inválido.';
if ($client_name === '') $errors[] = 'Informe o nome do cliente.';
if ($client_email === '' || !filter_var($client_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';
if ($client_phone === '') $errors[] = 'Informe o telefone.';
if ($model_type === 'cpf'  && strlen($client_cpf)   !== 11) $errors[] = 'CPF inválido.';
if ($model_type === 'cnpj' && strlen($company_cnpj) !== 14) $errors[] = 'CNPJ inválido.';

$isCNPJ = ($model_type === 'cnpj');
if ($isCNPJ && $company_name === '') $errors[] = 'Informe a Razão Social.';
if ($schedule_at === '') $errors[] = 'Selecione data e horário do agendamento.';

// Endereço obrigatório para boleto
if ($address_zipcode === '')      $errors[] = 'Informe o CEP.';
if ($address_street === '')       $errors[] = 'Informe a rua.';
if ($address_number === '')       $errors[] = 'Informe o número.';
if ($address_neighborhood === '') $errors[] = 'Informe o bairro.';
if ($address_city === '')         $errors[] = 'Informe a cidade.';
if ($address_state === '')        $errors[] = 'Informe o estado (UF).';

/* CNH obrigatória (PDF máx 5MB) */
$cnh_path = null;
if (empty($_FILES['cnh_file']['name']) || !is_uploaded_file($_FILES['cnh_file']['tmp_name'])) {
  $errors[] = 'Envie a CNH em PDF.';
} else {
  if ((int)$_FILES['cnh_file']['size'] > 5 * 1024 * 1024) $errors[] = 'Arquivo de CNH muito grande (máx 5MB).';
  $fi = new finfo(FILEINFO_MIME_TYPE);
  $mime = $fi->file($_FILES['cnh_file']['tmp_name']);
  if ($mime !== 'application/pdf') $errors[] = 'A CNH deve ser um arquivo PDF.';
}

/* pega preço do modelo para total */
$modelsTbl = table_exists($pdo,'certificate_models') ? 'certificate_models'
           : (table_exists($pdo,'products') ? 'products' : null);
if (!$modelsTbl) $errors[] = 'Tabela de modelos não encontrada.';
$priceCol = 'price'; foreach (['price','valor','amount','preco','value'] as $c)
  if ($modelsTbl && col_exists($pdo,$modelsTbl,$c)) { $priceCol=$c; break; }

$base_price = 0.0;
if ($modelsTbl) {
  $stp = $pdo->prepare("SELECT `$priceCol` AS price FROM `$modelsTbl` WHERE id=?");
  $stp->execute([$model_id]);
  $priceRow = $stp->fetch();
  $base_price = ridie_parse_price($priceRow['price'] ?? 0);
}
$total_amount = $base_price + ($extended_warranty ? 15.00 : 0.00);

/* se erro, mostra feedback simples */
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
if ($errors) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger"><strong>Não foi possível salvar a ordem:</strong><ul class="mb-0">';
  foreach ($errors as $e) echo '<li>'.h($e).'</li>';
  echo '</ul></div><a class="btn btn-secondary" href="javascript:history.back()">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

/* salva CNH */
$dir = __DIR__ . '/../../storage/uploads/cnh';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
$fname = 'cnh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.pdf';
$dest = $dir . '/' . $fname;
if (!move_uploaded_file($_FILES['cnh_file']['tmp_name'], $dest)) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger">Falha ao salvar o arquivo de CNH.</div>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}
$cnh_path = 'storage/uploads/cnh/' . $fname;

/* ================== Inserção no orders (com detecção de colunas) ================== */
$ordersTbl = 'orders';
$orderUserCol   = pick_col($pdo,$ordersTbl,['user_id','owner_id','contador_id'],'user_id');
$orderModelCol  = pick_col($pdo,$ordersTbl,['model_id','certificate_model_id','product_id'],'model_id');
$orderStatusCol = pick_col($pdo,$ordersTbl,['status','order_status'],'status');
$orderNoCol     = pick_col($pdo,$ordersTbl,['order_number','numero_pedido','numero','ref'],'order_number');
$amountCol      = pick_col($pdo,$ordersTbl,['total','total_amount','amount','price','valor'], 'total');

$clientCpfCnpjCol = pick_col($pdo, $ordersTbl, ['customer_cpf_cnpj', 'client_cpf_cnpj', 'cpf_cnpj'], null);
$clientCpfCol     = pick_col($pdo, $ordersTbl, ['client_cpf', 'cpf'], null);
$clientCnpjCol    = pick_col($pdo, $ordersTbl, ['company_cnpj', 'cnpj'], null);
$companyNameCol   = pick_col($pdo, $ordersTbl, ['RAZAOSOCIAL', 'company_name', 'razao_social'], null);

$clientNameCol    = pick_col($pdo, $ordersTbl, ['customer_name', 'client_name', 'nome_cliente'], 'customer_name');
$clientEmailCol   = pick_col($pdo, $ordersTbl, ['customer_email', 'client_email', 'email_cliente'], 'customer_email');
$clientPhoneCol   = pick_col($pdo, $ordersTbl, ['customer_phone', 'client_phone', 'telefone_cliente'], 'customer_phone');

$inssCol          = pick_col($pdo, $ordersTbl, ['inss_number', 'inss', 'cei', 'caepf', 'cno'], null);
$cnhCol           = pick_col($pdo, $ordersTbl, ['cnh_path', 'cnh_pdf', 'cnh_file_path'], null);
$schedAtCol       = pick_col($pdo, $ordersTbl, ['scheduled_at', 'schedule_at', 'agendamento_em'], null);
$schedDateCol     = pick_col($pdo, $ordersTbl, ['schedule_date', 'data_agendamento'], null);
$schedTimeCol     = pick_col($pdo, $ordersTbl, ['schedule_time', 'hora_agendamento'], null);
$warrantyCol      = pick_col($pdo, $ordersTbl, ['extended_warranty', 'warranty_ext', 'has_warranty'], null);
$clientTypeCol    = pick_col($pdo, $ordersTbl, ['client_type', 'customer_type'], null);

// Endereço
$zipcodeCol      = pick_col($pdo, $ordersTbl, ['address_zipcode','cep'], null);
$streetCol       = pick_col($pdo, $ordersTbl, ['address_street','rua'], null);
$numberCol       = pick_col($pdo, $ordersTbl, ['address_number','numero'], null);
$neighborhoodCol = pick_col($pdo, $ordersTbl, ['address_neighborhood','bairro'], null);
$cityCol         = pick_col($pdo, $ordersTbl, ['address_city','cidade'], null);
$stateCol        = pick_col($pdo, $ordersTbl, ['address_state','estado'], null);
$extWarrantyAmountCol = pick_col($pdo, $ordersTbl, ['ext_warranty_amount','valor_garantia'], null);

/* gera número do pedido (único) */
do {
  $order_number = date('Ymd').'-'.mt_rand(1000,9999);
  $st = $pdo->prepare("SELECT 1 FROM `$ordersTbl` WHERE `$orderNoCol` = ? LIMIT 1");
  $st->execute([$order_number]);
  $exists = $st->fetchColumn();
} while ($exists);

$cols   = [];
$params = [];

if ($orderUserCol)   { $cols[]=$orderUserCol;   $params[]=$user_id; }
if ($orderModelCol)  { $cols[]=$orderModelCol;  $params[]=$model_id; }
if ($orderStatusCol) { $cols[]=$orderStatusCol; $params[]='pending_payment'; }
if ($orderNoCol)     { $cols[]=$orderNoCol;     $params[]=$order_number; }
if ($clientNameCol)  { $cols[]=$clientNameCol;  $params[]=$client_name; }
if ($clientEmailCol) { $cols[]=$clientEmailCol; $params[]=$client_email; }
if ($clientPhoneCol) { $cols[]=$clientPhoneCol; $params[]=$client_phone; }

/* documentos / tipo */
if ($clientTypeCol) { $cols[]=$clientTypeCol; $params[]=$model_type; }

/* ========= CORREÇÃO AQUI: SEMPRE preencher customer_cpf_cnpj ========= */
$cpfCnpjUnified = ($model_type === 'cnpj') ? $company_cnpj : $client_cpf;
if ($clientCpfCnpjCol) { $cols[] = $clientCpfCnpjCol; $params[] = $cpfCnpjUnified; }

/* CNPJ + Razão (se existirem colunas específicas) */
if ($clientCnpjCol)  { $cols[] = $clientCnpjCol;  $params[] = $company_cnpj ?: null; }
if ($companyNameCol) { $cols[] = $companyNameCol; $params[] = $company_name ?: null; }

/* valores */
if ($amountCol)              { $cols[]=$amountCol;              $params[]=$total_amount; }
if ($warrantyCol)            { $cols[]=$warrantyCol;            $params[]=$extended_warranty ? 1 : 0; }
if ($extWarrantyAmountCol)   { $cols[]=$extWarrantyAmountCol;   $params[]=$extended_warranty ? 15.00 : 0.00; }

/* inss/cnh */
if ($inssCol) { $cols[]=$inssCol; $params[]=$inss_number ?: null; }
if ($cnhCol)  { $cols[]=$cnhCol;  $params[]=$cnh_path; }

/* agendamento */
if ($schedAtCol) {
  $cols[]=$schedAtCol; $params[]=$schedule_at;
} else {
  if ($schedDateCol) { $cols[]=$schedDateCol; $params[] = substr($schedule_at,0,10); }
  if ($schedTimeCol) { $cols[]=$schedTimeCol; $params[] = substr($schedule_at,11,5); }
}

/* Endereço */
if ($zipcodeCol)      { $cols[]=$zipcodeCol;      $params[]=$address_zipcode; }
if ($streetCol)       { $cols[]=$streetCol;       $params[]=$address_street; }
if ($numberCol)       { $cols[]=$numberCol;       $params[]=$address_number; }
if ($neighborhoodCol) { $cols[]=$neighborhoodCol; $params[]=$address_neighborhood; }
if ($cityCol)         { $cols[]=$cityCol;         $params[]=$address_city; }
if ($stateCol)        { $cols[]=$stateCol;        $params[]=$address_state; }

/* created_at se existir */
if (col_exists($pdo,$ordersTbl,'created_at')) {
  $cols[]='created_at'; $params[] = date('Y-m-d H:i:s');
}

/* insert */
try {
  $placeholders = array_fill(0, count($cols), '?');
  $sql = "INSERT INTO `$ordersTbl` (`".implode('`,`', $cols)."`) VALUES (".implode(',', $placeholders).")";
  $st = $pdo->prepare($sql);
  $st->execute($params);
  $order_id = (int)$pdo->lastInsertId();

} catch (PDOException $e) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger"><strong>Erro ao salvar a ordem:</strong><br><br>';
  echo 'Por favor, reporte esta mensagem de erro. Ela contém informações importantes para o conserto.<br><br>';
  echo '<strong>SQL Query:</strong><pre>'.$sql.'</pre>';
  echo '<strong>Mensagem do Banco de Dados:</strong><pre>'.$e->getMessage().'</pre></div>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

/* ================== rota de checkout: usa 'pay' (igual Meus Pedidos) ================== */
$ctrlDir = __DIR__;
$checkoutPage = 'pay';
if (!file_exists($ctrlDir.'/pay.php')) {
  if (file_exists($ctrlDir.'/checkout.php'))           $checkoutPage = 'checkout';
  elseif (file_exists($ctrlDir.'/order_checkout.php')) $checkoutPage = 'order_checkout';
}
$checkoutUrl = '/?page='.$checkoutPage.'&id='.$order_id;

include __DIR__ . '/../views/_header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h1 class="h5 mb-3">Pedido criado com sucesso!</h1>

        <div class="alert alert-info">
          O agendamento <strong>só será confirmado</strong> após a confirmação do pagamento pelo sistema.<br>
          Dê prioridade para pagamentos via <strong>PIX</strong>, eles são compensados mais rápido.
        </div>

        <dl class="row">
          <dt class="col-sm-3">Nº do Pedido</dt>
          <dd class="col-sm-9"><?php echo h($order_number); ?></dd>

          <dt class="col-sm-3">Total a pagar</dt>
          <dd class="col-sm-9">R$ <?php echo number_format($total_amount, 2, ',', '.'); ?></dd>

          <dt class="col-sm-3">Garantia estendida</dt>
          <dd class="col-sm-9"><?php echo $extended_warranty ? 'Sim (+ R$ 15,00)' : 'Não'; ?></dd>
        </dl>

        <div class="d-flex gap-2">
          <a class="btn btn-primary" href="<?php echo h($checkoutUrl); ?>">💳 Pagar agora</a>
          <a class="btn btn-outline-secondary" href="/?page=orders">Ir para Meus Pedidos</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../views/_footer.php';
