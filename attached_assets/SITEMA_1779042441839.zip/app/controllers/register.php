<?php
// app/controllers/register.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';

$h = fn($v) => sanitize($v);

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex justify-content-center">
  <div class="card shadow-sm" style="max-width: 780px; width: 100%;">
    <div class="card-body p-4">
      <h1 class="h4 text-center mb-4">Criar conta (Contador)</h1>

      <form method="post" action="/?page=do_register" autocomplete="off" class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nome completo <span class="text-danger">*</span></label>
          <input type="text" name="name" class="form-control" required autofocus>
        </div>

        <div class="col-md-6">
          <label class="form-label">E-mail <span class="text-danger">*</span></label>
          <input type="email" name="email" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">CPF ou CNPJ (titular) <span class="text-danger">*</span></label>
          <input
            type="text"
            name="cpf_cnpj"
            id="cpf_cnpj"
            class="form-control"
            inputmode="numeric"
            maxlength="18"
            required
          >
          <div class="form-text">Digite apenas n&uacute;meros; a m&aacute;scara ser&aacute; aplicada (CPF ou CNPJ).</div>
        </div>

        <div class="col-md-6">
          <label class="form-label">Senha <span class="text-danger">*</span></label>
          <input type="password" name="password" minlength="6" class="form-control" required>
          <div class="form-text">M&iacute;nimo de 6 caracteres.</div>
        </div>

        <div class="col-md-6">
          <label class="form-label">Cidade <span class="text-danger">*</span></label>
          <input type="text" name="city" class="form-control" required>
        </div>

        <div class="col-md-2">
          <label class="form-label">UF <span class="text-danger">*</span></label>
          <input type="text" name="state" id="state" maxlength="2" class="form-control text-uppercase" required>
        </div>

        <div class="col-md-4">
          <label class="form-label">Telefone do escrit&oacute;rio <span class="text-danger">*</span></label>
          <input type="text" name="office_phone" class="form-control" required>
        </div>

        <div class="col-12">
          <label class="form-label">Nome do escrit&oacute;rio <span class="text-danger">*</span></label>
          <input type="text" name="company_name" class="form-control" required>
        </div>

        <div class="col-12 d-grid">
          <button class="btn btn-primary btn-lg" type="submit">Cadastrar</button>
        </div>
      </form>

      <div class="mt-3 text-center">
        <a href="/?page=login">Voltar ao login</a>
      </div>
    </div>
  </div>
</div>

<script>
// ===== M�0�1�0�3scaras (sem inserir caracteres estranhos) =====
(function() {
  function onlyDigits(s){ return (s || '').replace(/\D+/g, ''); }

  function maskCPF(v){
    v = onlyDigits(v).slice(0, 11);
    if (v.length > 9)        v = v.replace(/^(\d{3})(\d{3})(\d{3})(\d{0,2})$/, '$1.$2.$3-$4');
    else if (v.length > 6)   v = v.replace(/^(\d{3})(\d{3})(\d{0,3})$/, '$1.$2.$3');
    else if (v.length > 3)   v = v.replace(/^(\d{3})(\d{0,3})$/, '$1.$2');
    return v;
  }

  function maskCNPJ(v){
    v = onlyDigits(v).slice(0, 14);
    if (v.length > 12)       v = v.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{0,2})$/, '$1.$2.$3/$4-$5');
    else if (v.length > 8)   v = v.replace(/^(\d{2})(\d{3})(\d{3})(\d{0,4})$/, '$1.$2.$3/$4');
    else if (v.length > 5)   v = v.replace(/^(\d{2})(\d{3})(\d{0,3})$/, '$1.$2.$3');
    else if (v.length > 2)   v = v.replace(/^(\d{2})(\d{0,3})$/, '$1.$2');
    return v;
  }

  var doc = document.getElementById('cpf_cnpj');
  if (doc) {
    doc.addEventListener('input', function(e){
      var digits = onlyDigits(e.target.value);
      e.target.value = (digits.length <= 11) ? maskCPF(digits) : maskCNPJ(digits);
    });
  }

  var uf = document.getElementById('state');
  if (uf) {
    uf.addEventListener('input', function(e){
      e.target.value = (e.target.value || '').toUpperCase().replace(/[^A-Z]/g,'').slice(0,2);
    });
  }
})();
</script>

<?php include __DIR__ . '/../views/_footer.php';
