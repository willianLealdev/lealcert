<?php
// app/controllers/order_detail.php — Detalhes + (admin) atualização de protocolo/status
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

// carrega envio de e-mail/notify
require_once __DIR__ . '/../mailer.php';

function esc($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }

$u    = auth_user();
$role = $u['role'] ?? 'contador';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

$st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st->execute([$id]);
$o = $st->fetch(PDO::FETCH_ASSOC);
if (!$o) { http_response_code(404); echo "Pedido não encontrado."; exit; }

// contador só pode ver se for dono
if ($role !== 'admin' && (int)$o['user_id'] !== (int)$u['id']) {
  http_response_code(403); echo "Acesso negado."; exit;
}

$labels = [
  'created'           => 'Criado',
  'pending_payment'   => 'Aguardando pagamento',
  'paid'              => 'Pago',
  'protocol_assigned' => 'Protocolo',
  'completed'         => 'Concluído',
];

// ====== buscar modelo do certificado ======
$modeloNome = '—';
if (!empty($o['model_id'])) {
  try {
    if ($pdo->query("SHOW TABLES LIKE 'certificate_models'")->fetch()) {
      $stM = $pdo->prepare("SELECT name FROM certificate_models WHERE id=? LIMIT 1");
      $stM->execute([$o['model_id']]);
      $rowM = $stM->fetch();
      if ($rowM && !empty($rowM['name'])) $modeloNome = $rowM['name'];
    } elseif ($pdo->query("SHOW TABLES LIKE 'products'")->fetch()) {
      $stM = $pdo->prepare("SELECT name FROM products WHERE id=? LIMIT 1");
      $stM->execute([$o['model_id']]);
      $rowM = $stM->fetch();
      if ($rowM && !empty($rowM['name'])) $modeloNome = $rowM['name'];
    }
  } catch (Throwable $e) {
    $modeloNome = '—';
  }
}

// ====== ADMIN: salvar protocolo/status ======
$saveError = '';
if ($role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'admin_update') {
  $newProtocol    = trim($_POST['protocol_number'] ?? '');
  $newStatus      = trim($_POST['status'] ?? '');
  $newCodigoChave = trim($_POST['codigo_chave'] ?? '');

  if ($newStatus === '') $newStatus = $o['status'];

  try {
    $pdo->beginTransaction();

    $wasStatus = $o['status'];
    $sql = "UPDATE orders SET protocol_number = ?, codigo_chave = ?, status = ?, updated_at = NOW() WHERE id=? LIMIT 1";
    $up  = $pdo->prepare($sql);
    $up->execute([$newProtocol ?: null, $newCodigoChave ?: null, $newStatus, $id]);

    // recarrega pedido
    $st->execute([$id]);
    $o = $st->fetch(PDO::FETCH_ASSOC);

    $pdo->commit();

    // se mudou para protocolo, dispara e-mail existente
    if ($wasStatus !== 'protocol_assigned' && $newStatus === 'protocol_assigned') {
      notify_protocol_assigned($pdo, (int)$id);
    }

    // novo: se mudou para concluído e tem código_chave, dispara e-mail
    if ($wasStatus !== 'completed' && $newStatus === 'completed' && !empty($newCodigoChave)) {
      notify_codigo_concluido($pdo, (int)$id);
    }

    header("Location: /?page=order_detail&id={$id}&ok=1");
    exit;

  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    $saveError = $e->getMessage();
  }
}

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Detalhes do Pedido — <?= esc($o['order_number'] ?: ('#'.$o['id'])) ?></h1>
  <div class="d-flex gap-2">
    <?php if ($role === 'admin'): ?>
      <a class="btn btn-outline-secondary" href="/?page=admin_orders">Voltar</a>
    <?php else: ?>
      <?php
        $canEdit = !in_array(($o['status'] ?? ''), ['protocol_assigned','completed'], true)
                   && (int)$o['user_id']===(int)$u['id'];
      ?>
      <?php if ($canEdit): ?>
        <a class="btn btn-outline-primary" href="/?page=order_edit&id=<?= (int)$o['id'] ?>">Editar</a>
      <?php endif; ?>
      <a class="btn btn-outline-secondary" href="/?page=orders_me">Voltar</a>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($_GET['ok'])): ?>
  <div class="alert alert-success">Dados atualizados com sucesso.</div>
<?php endif; ?>
<?php if (!empty($saveError)): ?>
  <div class="alert alert-danger">Falha ao salvar: <?= esc($saveError) ?></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Informações do Pedido</div>
      <div class="card-body">
        <p class="mb-1"><strong>Modelo do Certificado:</strong> <?= esc($modeloNome) ?></p>
        <p class="mb-1"><strong>Nº do Pedido:</strong> <?= esc($o['order_number'] ?: ('#'.$o['id'])) ?></p>
        <p class="mb-1"><strong>Status:</strong> <?= esc($labels[$o['status']] ?? $o['status']) ?></p>
        <p class="mb-1"><strong>Protocolo:</strong> <?= esc($o['protocol_number'] ?: '—') ?></p>
        <p class="mb-1"><strong>Código 🔑:</strong> <?= esc($o['codigo_chave'] ?: '—') ?></p>
        <p class="mb-1"><strong>Total:</strong> R$ <?= number_format((float)($o['total'] ?? 0), 2, ',', '.') ?></p>
        <p class="mb-1"><strong>Criado em:</strong> <?= $o['created_at'] ? date('d/m/Y H:i', strtotime($o['created_at'])) : '—' ?></p>
        <p class="mb-0"><strong>Agendamento:</strong> <?= $o['scheduled_at'] ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '—' ?></p>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Dados do Cliente</div>
      <div class="card-body">
        <p class="mb-1"><strong>Nome:</strong> <?= esc($o['customer_name']) ?></p>
        <p class="mb-1"><strong>E-mail:</strong> <?= esc($o['customer_email']) ?></p>
        <p class="mb-1"><strong>Telefone:</strong> <?= esc($o['customer_phone']) ?></p>
        <p class="mb-1"><strong>CPF/CNPJ (Titular):</strong> <?= esc($o['customer_cpf_cnpj'] ?: '—') ?></p>
        <p class="mb-1"><strong>Razão Social:</strong> <?= esc($o['RAZAOSOCIAL'] ?: '—') ?></p>
        <p class="mb-1"><strong>CNPJ:</strong> <?= esc($o['CNPJ'] ?: '—') ?></p>
        <p class="mb-1"><strong>Nº INSS (CEI/CAEPF/CNO):</strong> <?= esc($o['inss_number'] ?: '—') ?></p>
        <p class="mb-0"><strong>CNH (PDF):</strong>
          <?php if (!empty($o['cnh_path'])): ?>
            <a target="_blank" href="/<?= esc($o['cnh_path']) ?>">Abrir CNH</a>
          <?php else: ?>—<?php endif; ?>
        </p>
      </div>
    </div>
  </div>
</div>

<?php if ($role === 'admin'): ?>
  <div class="card mt-3">
    <div class="card-header">Ações do Administrador</div>
    <div class="card-body">
      <form method="post" class="row g-3">
        <input type="hidden" name="action" value="admin_update">
        <div class="col-md-4">
          <label class="form-label">Protocolo</label>
          <input type="text" name="protocol_number" class="form-control" value="<?= esc($o['protocol_number']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Código 🔑</label>
          <input type="text" name="codigo_chave" class="form-control" value="<?= esc($o['codigo_chave']) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php foreach ($labels as $k=>$v): ?>
              <option value="<?= esc($k) ?>" <?= ($o['status']===$k?'selected':'') ?>><?= esc($v) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 d-flex gap-2">
          <button class="btn btn-primary" type="submit">Salvar</button>
          <a class="btn btn-outline-secondary" href="/?page=admin_orders">Voltar à lista</a>
        </div>
      </form>
    </div>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/../views/_footer.php';
