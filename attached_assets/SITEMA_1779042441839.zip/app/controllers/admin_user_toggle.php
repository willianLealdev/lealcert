<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login(); require_role('admin');

$id = intval($_GET['id'] ?? 0);
$pdo->prepare("UPDATE users SET is_active = IF(is_active=1,0,1) WHERE id=?")->execute([$id]);
redirect('/?page=admin_users');
