<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

$u = auth_user();

$id = intval($_POST['id'] ?? 0);
$customer_name      = trim($_POST['customer_name'] ?? '');
$customer_cpf_cnpj  = preg_replace('/\D+/', '', $_POST['customer_cpf_cnpj'] ?? '');
$customer_email     = trim($_POST['customer_email'] ?? '');
$customer_phone     = trim($_POST['customer_phone'] ?? '');
$scheduled_at_str   = $_POST['scheduled_at'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o || intval($o['user_id']) !== intval($u['id'])) {
  redirect('/?page=orders_me');
}

/* ===== validações mais brandas ===== */
$doc_ok = (strlen($customer_cpf_cnpj) >= 11 && strlen($customer_cpf_cnpj) <= 14);
if (!$customer_name || !$doc_ok) {
  redirect('/?page=orders_me&save=0');
}

/* mantém o horário atual se o campo vier vazio */
if (!$scheduled_at_str && !empty($o['scheduled_at'])) {
  $scheduled_at_str = date('Y-m-d H:i:00', strtotime($o['scheduled_at']));
}

/* valida horário/agenda (09–15h, a cada 30min, sem sáb/dom) */
try {
  $tz = new DateTimeZone('America/Sao_Paulo');
  $dt = new DateTimeImmutable($scheduled_at_str, $tz);
} catch (Throwable $e) {
  redirect('/?page=orders_me&save=0');
}
$scheduled_at = $dt->format('Y-m-d H:i:00');
$OPEN_HOUR=9; $CLOSE_HOUR=15; $STEP_MIN=30;
$weekday = intval($dt->format('N')); $h=intval($dt->format('H')); $m=intval($dt->format('i'));
if ($weekday >= 6 || $h < $OPEN_HOUR || $h > $CLOSE_HOUR || ($m % $STEP_MIN !== 0)) {
  redirect('/?page=orders_me&save=0');
}

/* colisão com outros pedidos (permite o próprio) */
$check = $pdo->prepare("SELECT COUNT(*) FROM orders
  WHERE scheduled_at=? AND id<>? AND status IN ('pending_payment','paid','protocol_assigned','completed')");
$check->execute([$scheduled_at, $id]);
if (intval($check->fetchColumn()) > 0) {
  redirect('/?page=orders_me&save=0');
}

/* upload opcional da CNH */
if (isset($_FILES['cnh']) && isset($_FILES['cnh']['error']) && $_FILES['cnh']['error'] !== UPLOAD_ERR_NO_FILE) {
  if ($_FILES['cnh']['error'] === UPLOAD_ERR_OK) {
    $filename = $_FILES['cnh']['name'];
    $tmp = $_FILES['cnh']['tmp_name'];
    $size = intval($_FILES['cnh']['size'] ?? 0);
    if ($size > 0 && $size <= 5*1024*1024) {
      $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
      if (in_array($ext, ['png','jpg','jpeg','pdf'])) {
        $mime = null;
        if (class_exists('finfo')) { $f = new finfo(FILEINFO_MIME_TYPE); $mime = @$f->file($tmp); }
        elseif (function_exists('mime_content_type')) { $mime = @mime_content_type($tmp); }
        if (!$mime) $mime = ['png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','pdf'=>'application/pdf'][$ext] ?? null;
        if ($mime && in_array($mime, ['image/png','image/jpeg','application/pdf'])) {
          $dir = __DIR__ . '/../../storage/uploads/cnh';
          if (!is_dir($dir)) @mkdir($dir, 0775, true);
          if (is_dir($dir) && is_writable($dir)) {
            $fname = uniqid('cnh_') . '.' . ($ext==='jpeg' ? 'jpg' : $ext);
            if (@move_uploaded_file($tmp, $dir.'/'.$fname)) {
              if (!empty($o['cnh_path'])) {
                $old = $dir.'/'.basename($o['cnh_path']);
                if (is_file($old)) @unlink($old);
              }
              $o['cnh_path'] = $fname;
            }
          }
        }
      }
    }
  }
}

/* persiste */
$stmt = $pdo->prepare("UPDATE orders
  SET customer_name=?, customer_cpf_cnpj=?, customer_email=?, customer_phone=?, scheduled_at=?, cnh_path=?
  WHERE id=?");
$stmt->execute([
  $customer_name, $customer_cpf_cnpj, $customer_email, $customer_phone,
  $scheduled_at, ($o['cnh_path'] ?? null), $id
]);

redirect('/?page=orders_me&save=1');
