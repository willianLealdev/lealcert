<?php
require_role('admin');
$id = intval($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
$price = (float)($_POST['price'] ?? 0);
$active = isset($_POST['active']) ? 1 : 0;
if (!$name || $price<0) redirect('/?page=admin_models');
if ($id) {
  $stmt = $pdo->prepare("UPDATE certificate_models SET name=?, description=?, price=?, active=? WHERE id=?");
  $stmt->execute([$name,$description,$price,$active,$id]);
} else {
  $stmt = $pdo->prepare("INSERT INTO certificate_models (name, description, price, active) VALUES (?,?,?,?)");
  $stmt->execute([$name,$description,$price,$active]);
}
redirect('/?page=admin_models');
