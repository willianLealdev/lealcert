<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../mailer.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

$idf = trim($_POST['identifier'] ?? '');
if ($idf === '') {
  redirect('/?page=forgot_password&err=1');
}

/* busca por e-mail OU CPF/CNPJ (somente dígitos) */
if (filter_var($idf, FILTER_VALIDATE_EMAIL)) {
  $stmt = $pdo->prepare("SELECT id,name,email FROM users WHERE email=? LIMIT 1");
  $stmt->execute([$idf]);
} else {
  $doc = preg_replace('/\D+/', '', $idf);
  $stmt = $pdo->prepare("SELECT id,name,email FROM users WHERE cpf_cnpj=? LIMIT 1");
  $stmt->execute([$doc]);
}
$u = $stmt->fetch();

/* Geramos token SEM revelar se o usuário existe (sempre redireciona com 'sent=1') */
if ($u) {
  $token = bin2hex(random_bytes(16));
  $exp = (new DateTime('+1 hour', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d H:i:s');
  $pdo->prepare("UPDATE users SET reset_password_token=?, reset_password_expires=? WHERE id=?")
      ->execute([$token,$exp,$u['id']]);

  $link = rtrim(getenv('SITE_URL') ?: '', '/') . "/?page=reset_password&token=$token";
  $_SESSION['LAST_RESET_LINK'] = $link; // para preview na tela se MAIL_DEBUG=1

  $html = "<p>Olá, ".htmlspecialchars($u['name'])."</p>
           <p>Para definir uma nova senha, acesse o link abaixo (válido por 1 hora):</p>
           <p><a href='$link'>$link</a></p>
           <p>RIDIECERT</p>";
  @send_mail($u['email'], 'Recuperação de senha - RIDIECERT', $html);
}

/* sempre mostramos 'sent=1' para não expor se a conta existe ou não */
redirect('/?page=forgot_password&sent=1');
