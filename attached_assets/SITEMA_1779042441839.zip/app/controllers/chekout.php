<?php
// app/controllers/checkout.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

try {
  $u = auth_user();
  $uid = (int)($u['id'] ?? 0);
  $role = $u['role'] ?? 'contador';

  $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
  if ($id <= 0) { http_response_code(400); throw new RuntimeException("Pedido inválido."); }

  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $order = $st->fetch(PDO::FETCH_ASSOC);
  if (!$order) { http_response_code(404); throw new RuntimeException("Pedido não encontrado."); }

  if ($role !== 'admin' && (int)$order['user_id'] !== $uid) {
    http_response_code(403);
    throw new RuntimeException("Você não tem permissão para ver este checkout.");
  }

  // Helpers
  function table_exists(PDO $pdo, string $t): bool { try { $pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true; } catch(Throwable $e){ return false; } }
  function col_exists(PDO $pdo, string $t, string $c): bool { try { return (bool)$pdo->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->fetch(); } catch(Throwable $e){ return false; } }

  // Nome e preço do modelo
  $modelsTbl = table_exists($pdo,'certificate_models') ? 'certificate_models' : (table_exists($pdo,'products') ? 'products' : null);
  $modelName = 'Certificado';
  $modelPrice = 0.00;

  if ($modelsTbl) {
    $nameCol  = 'name';  foreach (['name','title','label','descricao'] as $c)  if (col_exists($pdo,$modelsTbl,$c)) { $nameCol=$c; break; }
    $priceCol = 'price'; foreach (['price','valor','amount','preco','value'] as $c) if (col_exists($pdo,$modelsTbl,$c)) { $priceCol=$c; break; }

    $m = $pdo->prepare("SELECT `$nameCol` AS name, `$priceCol` AS price FROM `$modelsTbl` WHERE id=?");
    $m->execute([(int)$order['model_id']]);
    if ($row = $m->fetch(PDO::FETCH_ASSOC)) {
      $modelName  = (string)($row['name'] ?? 'Certificado');
      $p = (string)($row['price'] ?? '0');
      $p = str_replace(["\xC2\xA0",' '], '', $p);
      $p = str_replace('.', '', $p);
      $p = (float)str_replace(',', '.', $p);
      $modelPrice = $p;
    }
  }

  // Total confiável (sem is_finite)
  $total = 0.0;
  if (isset($order['total']) && is_numeric($order['total'])) {
    $total = (float)$order['total'];
  }

  // Diferença = garantia
  $extwAmount = max(0.0, round($total - $modelPrice, 2));
  $hasExtw = ($extwAmount >= 14.99);

  // Mercado Pago
  function mp_create_preference(array $order, float $total): array {
    $accessToken = getenv('MP_ACCESS_TOKEN') ?: (defined('MP_ACCESS_TOKEN') ? MP_ACCESS_TOKEN : '');
    $baseUrl     = (defined('SITE_URL') && SITE_URL!=='') ? SITE_URL : (getenv('SITE_URL') ?: '');
    $webhookSec  = getenv('WEBHOOK_SECRET') ?: (defined('WEBHOOK_SECRET') ? WEBHOOK_SECRET : 'changeme');

    if (!$accessToken) return ['ok'=>false, 'err'=>'Access token ausente.'];

    $title = 'RIDIECERT — ' . ($order['order_number'] ?? ('Pedido #'.$order['id']));
    $payerEmail = $order['customer_email'] ?: null;

    $payload = [
      'items' => [[
        'title'        => $title,
        'quantity'     => 1,
        'currency_id'  => 'BRL',
        'unit_price'   => (float)$total,
      ]],
      'external_reference' => (string)($order['order_number'] ?? $order['id']),
      'back_urls' => [
        'success' => rtrim($baseUrl,'/') . '/?page=order_success',
        'failure' => rtrim($baseUrl,'/') . '/?page=order_failure',
        'pending' => rtrim($baseUrl,'/') . '/?page=order_pending',
      ],
      'auto_return'      => 'approved',
      'notification_url' => rtrim($baseUrl,'/') . '/?page=mp_webhook&whsec=' . $webhookSec,
    ];
    if ($payerEmail) $payload['payer'] = ['email' => $payerEmail];

    $ch = curl_init('https://api.mercadopago.com/checkout/preferences');
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
      ],
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
      CURLOPT_TIMEOUT => 30,
    ]);
    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) return ['ok'=>false, 'err'=>$err];
    if ($http < 200 || $http >= 300) return ['ok'=>false, 'err'=>"HTTP $http: $resp"];

    $data = json_decode($resp, true);
    if (!is_array($data)) return ['ok'=>false, 'err'=>'Resposta inválida do MP'];

    $prefId   = $data['id'] ?? null;
    $payUrl   = $data['init_point'] ?? ($data['sandbox_init_point'] ?? null);
    if (!$prefId || !$payUrl) return ['ok'=>false, 'err'=>'Preferência sem id/init_point'];

    return ['ok'=>true, 'id'=>$prefId, 'url'=>$payUrl, 'raw'=>$data];
  }

  $needCreate = empty($order['mp_preference_id']) || isset($_GET['recreate']);
  $mpErr = '';
  $payUrl = null;

  if ($needCreate) {
    $mk = mp_create_preference($order, $total);
    if ($mk['ok']) {
      $payUrl = $mk['url'];
      $up = $pdo->prepare("UPDATE orders SET mp_preference_id=?, updated_at=NOW() WHERE id=?");
      $up->execute([$mk['id'], $order['id']]);
      $order['mp_preference_id'] = $mk['id'];
    } else {
      $mpErr = $mk['err'];
    }
  } else {
    $mk = mp_create_preference($order, $total);
    if ($mk['ok']) $payUrl = $mk['url']; else $mpErr = $mk['err'];
  }

} catch (Throwable $e) {
  @file_put_contents(__DIR__ . '/../../storage/error_checkout.log',
    date('c')." CHECKOUT FATAL: ".$e->getMessage()."\n".$e->getTraceAsString()."\n", FILE_APPEND);

  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger">Erro ao abrir o checkout. ';
  if (!empty($role) && $role === 'admin') {
    echo '<br><small class="text-monospace">'.sanitize($e->getMessage()).'</small>';
  }
  echo '</div>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

include __DIR__ . '/../views/_header.php';
?>
<div class="row">
  <div class="col-lg-7">
    <h1 class="h5 mb-3">Checkout do Pedido</h1>

    <div class="card mb-3 shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-muted small">Pedido</div>
            <div class="fw-semibold"><?= sanitize($order['order_number'] ?? ('#'.$order['id'])) ?></div>
          </div>
          <div class="text-end">
            <div class="text-muted small">Status</div>
            <div class="fw-semibold"><?= sanitize($order['status']) ?></div>
          </div>
        </div>

        <hr>

        <div class="row g-2">
          <div class="col-md-6">
            <div class="text-muted small">Cliente</div>
            <div class="fw-semibold"><?= sanitize($order['customer_name']) ?></div>
            <div class="small"><?= sanitize($order['customer_email']) ?></div>
            <div class="small"><?= sanitize($order['customer_phone']) ?></div>
          </div>
          <div class="col-md-6">
            <div class="text-muted small">Documento</div>
            <div class="fw-semibold"><?= sanitize($order['customer_cpf_cnpj'] ?: '—') ?></div>
            <?php if (!empty($order['RAZAOSOCIAL']) || !empty($order['CNPJ'])): ?>
              <div class="mt-2 text-muted small">Razão Social / CNPJ</div>
              <div class="fw-semibold"><?= sanitize(($order['RAZAOSOCIAL'] ?: '—') . (!empty($order['CNPJ']) ? ' / '.$order['CNPJ'] : '')) ?></div>
            <?php endif; ?>
          </div>
        </div>

        <hr>

        <div class="text-muted small">Agendamento</div>
        <div class="fw-semibold">
          <?= $order['scheduled_at'] ? sanitize(date('d/m/Y H:i', strtotime($order['scheduled_at']))) : '—' ?>
        </div>
      </div>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <h2 class="h6 mb-0">Resumo</h2>
          <?php if (($u['role'] ?? '')==='admin'): ?>
            <a class="btn btn-sm btn-outline-secondary" href="/?page=checkout&id=<?= (int)$order['id'] ?>&recreate=1">Recriar link</a>
          <?php endif; ?>
        </div>

        <div class="d-flex justify-content-between">
          <div><?= sanitize($modelName) ?></div>
          <div>R$ <?= number_format($modelPrice, 2, ',', '.') ?></div>
        </div>
        <?php if ($hasExtw): ?>
          <div class="d-flex justify-content-between">
            <div>Garantia estendida</div>
            <div>R$ <?= number_format($extwAmount, 2, ',', '.') ?></div>
          </div>
        <?php endif; ?>
        <hr>
        <div class="d-flex justify-content-between fw-bold">
          <div>Total</div>
          <div>R$ <?= number_format($total, 2, ',', '.') ?></div>
        </div>

        <?php if (!empty($mpErr)): ?>
          <div class="alert alert-danger mt-3">
            Erro ao criar preferência no Mercado Pago:
            <small class="text-monospace"><?= sanitize($mpErr) ?></small>
          </div>
        <?php else: ?>
          <div class="mt-3">
            <a class="btn btn-primary btn-lg" href="<?= sanitize($payUrl) ?>">Pagar com Mercado Pago</a>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Observações</h2>
        <ul class="small text-muted mb-0">
          <li>Após o pagamento, o status será atualizado automaticamente (webhook) para <em>Pago</em>.</li>
          <li>Em caso de dúvidas, abra um chamado em <strong>Suporte</strong>.</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../views/_footer.php';
