<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
if (!$id) { redirect('/?page=orders_me'); }

$u = auth_user();

$sql = "SELECT o.*, m.name AS mname, m.price AS mprice
        FROM orders o
        JOIN certificate_models m ON m.id=o.model_id
        WHERE o.id=? LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$o = $stmt->fetch();

if (!$o || intval($o['user_id']) !== intval($u['id'])) {
  redirect('/?page=orders_me');
}

function status_label($s){
  $map = [
    'created'=>'Criado','pending_payment'=>'Aguardando pagamento','paid'=>'Pago',
    'protocol_assigned'=>'Protocolo','completed'=>'Concluído'
  ];
  return $map[$s] ?? ucfirst($s);
}

include __DIR__ . '/../views/_header.php';
?>
<div class="container py-3">
  <h1 class="h5 mb-3">Pedido #<?= sanitize($o['order_number']) ?></h1>
  <div class="row g-3">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="mb-3"><?= sanitize($o['mname']) ?> — R$ <?= number_format($o['total'],2,',','.') ?></h5>
          <p><strong>Status:</strong> <?= status_label($o['status']) ?></p>
          <p><strong>Agendamento:</strong> <?= $o['scheduled_at'] ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '-' ?></p>
          <p><strong>Protocolo:</strong> <?= $o['protocol_number'] ? sanitize($o['protocol_number']) : '—' ?></p>
          <hr>
          <p><strong>Nome do Cliente:</strong> <?= sanitize($o['customer_name']) ?></p>
          <p><strong>CPF/CNPJ:</strong> <?= sanitize($o['customer_cpf_cnpj']) ?></p>
          <p><strong>E-mail/Telefone:</strong> <?= sanitize($o['customer_email']) ?> | <?= sanitize($o['customer_phone'] ?? '') ?></p>
          <p><strong>CNH:</strong>
            <?php if (!empty($o['cnh_path'])): ?>
              <a href="/?page=download_cnh&id=<?= $o['id'] ?>" target="_blank">baixar</a>
            <?php else: ?>—<?php endif; ?>
          </p>
          <hr>
          <p class="text-muted small">
            <strong>Mercado Pago</strong><br>
            Preference: <?= sanitize($o['mp_preference_id'] ?? '-') ?> |
            Payment: <?= sanitize($o['mp_payment_id'] ?? '-') ?>
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <a class="btn btn-outline-secondary w-100 mb-2" href="/?page=orders_me">Voltar</a>
      <?php if (!in_array($o['status'], ['protocol_assigned','completed'])): ?>
        <a class="btn btn-primary w-100" href="/?page=orders_me#edit-<?= $o['id'] ?>">Editar</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
