<?php
// app/controllers/pay.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$user = auth_user();
$uid = (int)($user['id'] ?? 0);
$isAdmin = (($user['role'] ?? '') === 'admin');

$order_id = (int)($_GET['id'] ?? 0);
if ($order_id <= 0) { http_response_code(400); echo "Pedido inválido."; exit; }

// carrega pedido (admin pode ver todos; cliente só o próprio)
if ($isAdmin) {
  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
  $st->execute([$order_id]);
} else {
  $st = $pdo->prepare("SELECT * FROM orders WHERE id=? AND user_id=? LIMIT 1");
  $st->execute([$order_id, $uid]);
}
$order = $st->fetch(PDO::FETCH_ASSOC);
if (!$order) { http_response_code(404); echo "Pedido não encontrado."; exit; }

$orderNo = $order['order_number'] ?: ('#'.$order_id);
$status = $order['status'] ?? 'pending_payment';

// total a pagar (já deve vir pronto da tabela `orders.total`)
$totalAmount = (float)($order['total'] ?? 0);

// e-mail do pagador
$customerMail = trim($order['customer_email'] ?? ($user['email'] ?? ''));

// Mercado Pago PUBLIC KEY (carregada do .env via config.php)
$MP_PUB = getenv('MP_PUBLIC_KEY') ?: '';

// Tipo e número do documento (CPF/CNPJ) do usuário logado
$docNumber = trim($user['doc_number'] ?? '');
$cleanDocNumber = preg_replace('/[^0-9]/', '', $docNumber);
$docType = (strlen($cleanDocNumber) === 11) ? 'CPF' : 'CNPJ';
$docNumber = $cleanDocNumber;

include __DIR__ . '/../views/_header.php';
?>
<script src="https://sdk.mercadopago.com/js/v2"></script>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Pagamento do pedido <span class="text-muted">#<?= h($orderNo) ?></span></h1>
  <a class="btn btn-outline-secondary" href="/?page=orders">Voltar a Meus Pedidos</a>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <div id="paymentBrick_container" class="mb-2"></div>
        <div id="pay-msg" class="alert d-none"></div>
        <div class="small text-muted">
          Pagamento processado diretamente nesta página. Opções: <strong>Pix</strong> e <strong>Boleto</strong>-- PAGAMENTO REALIZADO POR <strong>MERCADO PAGO</strong>..
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="text-muted mb-3">Resumo</h6>
        <div class="d-flex justify-content-between"><span>Pedido</span><span class="fw-semibold">#<?= h($orderNo) ?></span></div>
        <div class="d-flex justify-content-between"><span>Status</span><span class="fw-semibold"><?= h($status) ?></span></div>
        <hr>
        <div class="d-flex justify-content-between"><span>Total</span>
          <span class="fw-bold">R$ <?= number_format($totalAmount, 2, ',', '.') ?></span>
        </div>
        <div class="small text-muted mt-2">Após aprovação, o pedido será atualizado automaticamente.</div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Configura SDK no front
  const mp = new MercadoPago(<?= json_encode($MP_PUB) ?>, { locale: 'pt-BR' });

  const amount = <?= json_encode((float)$totalAmount) ?>;
  const payer = { 
    email: <?= json_encode($customerMail) ?> || undefined,
    identification: {
      type: '<?= h($docType) ?>',
      number: '<?= h($docNumber) ?>'
    }
  };
  const orderId = <?= (int)$order_id ?>;
  const orderNo = <?= json_encode($orderNo) ?>;

  const msgBox = document.getElementById('pay-msg');
  function showMsg(kind, text, extraHtml='') {
    msgBox.className = 'alert alert-' + kind;
    msgBox.innerHTML = text + (extraHtml ? '<div class="mt-2">'+extraHtml+'</div>' : '');
    msgBox.classList.remove('d-none');
  }

  mp.bricks().create('payment', 'paymentBrick_container', {
    initialization: {
      amount: amount,
      payer: payer
    },
    customization: {
      paymentMethods: {
        bankTransfer: ['pix'],
        ticket: 'all',
        creditCard: [],
        debitCard:  [],
        atm: []
      },
      visual: { style: { theme: 'flat' } }
    },
    callbacks: {
      onReady: () => {},
      onError: (error) => {
        console.error('Payment Brick error:', error);
        const msg = (error && (error.message || error.error || error.cause || error.toString()))
                     || 'Não foi possível carregar o formulário de pagamento.';
        const fb  = '<a class="btn btn-outline-primary" href="/?page=checkout&id='+orderId+'" target="_blank">Abrir no Mercado Pago</a>';
        showMsg('danger', msg, fb);
      },
      onSubmit: (formData) => {
        const payload = {
          ...formData,
          transaction_amount: Number(amount),
          description: 'Pedido ' + orderNo
        };

        return new Promise((resolve, reject) => {
          fetch('/?page=mp_process_payment&id=' + orderId, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          })
          .then(r => r.json())
          .then(data => {
            console.log('Resposta completa do backend:', data);

            if (data && data.ok) {
              if (data.status === 'approved') {
                showMsg('success', 'Pagamento aprovado! Atualizando…');
                setTimeout(()=>{ window.location.href='/?page=orders'; }, 1200);
                resolve();
              } else if (data.status === 'pending' || data.status === 'in_process') {
                const poi = data.point_of_interaction || {};
                const td  = poi.transaction_data || {};
                let paymentHtml = '';

                if (td.qr_code_base64 || td.qr_code) {
                  const qrCodeBase64 = td.qr_code_base64 || '';
                  const qrCodeText   = td.qr_code || '';
                  paymentHtml = `
                    <h6 class="text-center">Escaneie o QR Code com o app do seu banco</h6>
                    <div class="text-center my-3">
                      ${qrCodeBase64 ? `<img src="data:image/png;base64,${qrCodeBase64}" alt="QR Code Pix" style="max-width: 250px;">` : ''}
                    </div>
                    ${qrCodeText ? `
                      <h6 class="text-center">Ou copie o código para pagamento:</h6>
                      <div class="input-group">
                        <input type="text" class="form-control" value="${qrCodeText}" readonly>
                        <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('${qrCodeText}')">Copiar</button>
                      </div>` : ''}
                  `;
                }
                else if (td.ticket_url || td.external_resource_url) {
                  const ticketUrl = td.ticket_url || td.external_resource_url;
                  paymentHtml = `
                    <p class="text-center">Seu boleto foi gerado com sucesso. Clique no botão para visualizar.</p>
                    <div class="text-center">
                      <a href="${ticketUrl}" target="_blank" class="btn btn-primary">Ver Boleto</a>
                    </div>
                  `;
                }

                if (paymentHtml) {
                  document.getElementById('paymentBrick_container').innerHTML = '';
                  showMsg('info', 'Pedido criado. Use as informações abaixo para finalizar o pagamento.', paymentHtml);
                } else {
                  showMsg('warning', 'Pagamento pendente/aguardando. Você pode acompanhar em “Meus Pedidos”.');
                }

                resolve();
              } else {
                showMsg('secondary', 'Status do pagamento: '+ (data.status || 'desconhecido') +'. Acompanhe em “Meus Pedidos”.');
                resolve();
              }
            } else {
              const fb = '<a class="btn btn-outline-primary" href="/?page=checkout&id='+orderId+'" target="_blank">Abrir no Mercado Pago</a>';
              showMsg('danger', (data && data.error) ? data.error : 'Falha ao processar o pagamento.', fb);
              reject();
            }
          })
          .catch(err => {
            console.error(err);
            const fb = '<a class="btn btn-outline-primary" href="/?page=checkout&id='+orderId+'" target="_blank">Abrir no Mercado Pago</a>';
            showMsg('danger', 'Erro de comunicação ao processar o pagamento.', fb);
            reject();
          });
        });
      }
    }
  });
})();

function copyToClipboard(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      alert('Código copiado com sucesso!');
    }).catch(err => {
      console.error('Falha ao copiar o texto: ', err);
      fallbackCopyTextToClipboard(text);
    });
  } else {
    fallbackCopyTextToClipboard(text);
  }
}

function fallbackCopyTextToClipboard(text) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
    alert('Código copiado com sucesso! (método fallback)');
  } catch (err) {
    console.error('Fallback: Falha ao copiar o texto', err);
  }
  document.body.removeChild(textArea);
}
</script>

<?php include __DIR__ . '/../views/_footer.php'; ?>