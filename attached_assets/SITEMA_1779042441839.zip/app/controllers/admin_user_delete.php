<?php
// app/controllers/admin_user_delete.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

$h = fn($v)=>htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

// Não permitir excluir a si mesmo
$me = auth_user();
if ((int)$me['id'] === $id) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-warning">Você não pode excluir a própria conta.</div>';
  echo '<a class="btn btn-secondary" href="/?page=admin_users">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

// Carrega usuário alvo
$st = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id=? LIMIT 1");
$st->execute([$id]);
$u = $st->fetch(PDO::FETCH_ASSOC);
if (!$u) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger">Usuário não encontrado.</div>';
  echo '<a class="btn btn-secondary" href="/?page=admin_users">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

// Se for admin, garantir que não é o último
if (($u['role'] ?? '') === 'admin') {
  $stc = $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'");
  $qtdAdmins = (int)$stc->fetchColumn();
  if ($qtdAdmins <= 1) {
    include __DIR__ . '/../views/_header.php';
    echo '<div class="alert alert-warning">Não é possível excluir o último administrador.</div>';
    echo '<a class="btn btn-secondary" href="/?page=admin_users">Voltar</a>';
    include __DIR__ . '/../views/_footer.php';
    exit;
  }
}

// Verifica se há pedidos vinculados
$hasOrders = false;
try {
  $sto = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id=?");
  $sto->execute([$id]);
  $hasOrders = ((int)$sto->fetchColumn() > 0);
} catch (Throwable $e) {
  // se der erro, por segurança trata como se tivesse pedidos
  $hasOrders = true;
}

include __DIR__ . '/../views/_header.php';

if ($hasOrders) {
  echo '<div class="alert alert-danger">';
  echo 'Este usuário possui pedidos vinculados e não pode ser excluído por segurança.<br>';
  echo 'Sugestão: edite o usuário e marque como inativo (is_active=0).';
  echo '</div>';
  echo '<a class="btn btn-secondary" href="/?page=admin_users">Voltar</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

// Prossegue exclusão
try {
  $del = $pdo->prepare("DELETE FROM users WHERE id=?");
  $del->execute([$id]);

  echo '<div class="alert alert-success">Usuário excluído com sucesso.</div>';
  echo '<a class="btn btn-primary" href="/?page=admin_users">Voltar à lista</a>';

} catch (Throwable $e) {
  echo '<div class="alert alert-danger">Falha ao excluir: '.$h($e->getMessage()).'</div>';
  echo '<a class="btn btn-secondary" href="/?page=admin_users">Voltar</a>';
}

include __DIR__ . '/../views/_footer.php';
