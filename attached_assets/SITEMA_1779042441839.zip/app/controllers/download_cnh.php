<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
if (!$id) { http_response_code(400); echo "missing id"; exit; }

$stmt = $pdo->prepare("SELECT id, user_id, cnh_path FROM orders WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o || empty($o['cnh_path'])) { http_response_code(404); echo "not found"; exit; }

$u = auth_user();
$is_admin = isset($u['role']) && $u['role'] === 'admin';
if (!$is_admin && intval($o['user_id']) !== intval($u['id'])) {
  http_response_code(403); echo "forbidden"; exit;
}

$file = __DIR__ . '/../../storage/uploads/cnh/' . basename($o['cnh_path']);
if (!is_file($file)) { http_response_code(404); echo "not found"; exit; }

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$mime = [
  'png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','pdf'=>'application/pdf'
][$ext] ?? 'application/octet-stream';

header('Content-Type: '.$mime);
header('Content-Length: '.filesize($file));
header('Content-Disposition: inline; filename="'.basename($file).'"');
readfile($file);
