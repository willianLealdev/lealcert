<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT o.*, u.name uname, m.name mname FROM orders o
JOIN users u ON u.id=o.user_id
JOIN certificate_models m ON m.id=o.model_id
WHERE o.id=?");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o) redirect('/?page=admin_orders');

function status_label($s){
  $map = [
    'created'=>'Criado','pending_payment'=>'Aguardando pagamento','paid'=>'Pago',
    'protocol_assigned'=>'Protocolo','completed'=>'Concluído'
  ];
  return $map[$s] ?? ucfirst($s);
}

include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Pedido #<?= sanitize($o['order_number']) ?></h1>
<div class="mb-2">
  <a class="btn btn-sm btn-outline-primary" href="/?page=admin_order_edit&id=<?= $o['id'] ?>">Editar</a>
</div>

<div class="row g-3">
  <div class="col-md-8">
    <div class="card shadow-sm"><div class="card-body">
      <h5 class="mb-3"><?= sanitize($o['mname']) ?> — R$ <?= number_format($o['total'],2,',','.') ?></h5>
      <p><strong>Status:</strong> <?= status_label($o['status']) ?></p>
      <p><strong>Cliente:</strong> <?= sanitize($o['customer_name']) ?> — CPF/CNPJ: <?= sanitize($o['customer_cpf_cnpj']) ?></p>
      <p><strong>Contato:</strong> <?= sanitize($o['customer_email']) ?> | <?= sanitize($o['customer_phone']) ?></p>
      <p><strong>Agendamento:</strong> <?= $o['scheduled_at'] ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '-' ?></p>
      <p><strong>CNH:</strong>
        <?php if ($o['cnh_path']): ?>
          <a href="/?page=download_cnh&id=<?= $o['id'] ?>" target="_blank">baixar</a>
        <?php else: ?>
          —
        <?php endif; ?>
      </p>
      <p><strong>MP Preference ID:</strong> <?= sanitize($o['mp_preference_id'] ?? '-') ?> |
         <strong>MP Payment ID:</strong> <?= sanitize($o['mp_payment_id'] ?? '-') ?></p>
    </div></div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm"><div class="card-body">
      <form method="post" action="/?page=admin_order_update">
        <input type="hidden" name="id" value="<?= $o['id'] ?>">
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php
              $opts = ['created'=>'Criado','pending_payment'=>'Aguardando pagamento','paid'=>'Pago','protocol_assigned'=>'Protocolo','completed'=>'Concluído'];
              foreach ($opts as $k=>$v): ?>
              <option value="<?= $k ?>" <?= $o['status']===$k?'selected':'' ?>><?= $v ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Nº Protocolo (após pagamento)</label>
          <input type="text" name="protocol_number" value="<?= sanitize($o['protocol_number']) ?>" class="form-control">
        </div>
        <button class="btn btn-primary w-100 mb-2">Salvar</button>
        <a href="/?page=admin_order_sync&id=<?= $o['id'] ?>" class="btn btn-outline-secondary w-100 mb-2">Sincronizar com Mercado Pago</a>
      </form>
      <form method="post" action="/?page=admin_order_delete"
            onsubmit="return confirm('Tem certeza que deseja excluir este pedido? Esta ação não pode ser desfeita.');">
        <input type="hidden" name="id" value="<?= $o['id'] ?>">
        <button class="btn btn-danger w-100">Excluir pedido</button>
      </form>
    </div></div>
  </div>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
