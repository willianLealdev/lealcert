<?php
require_role('admin');
$id = intval($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$cpf_cnpj = only_digits($_POST['cpf_cnpj'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$role = $_POST['role'] ?? 'contador';
if (!$id || !$name || !is_cpf_cnpj($cpf_cnpj)) redirect('/?page=admin_users');
$stmt = $pdo->prepare("UPDATE users SET name=?, email=?, cpf_cnpj=?, phone=?, role=? WHERE id=?");
$stmt->execute([$name,$email,$cpf_cnpj,$phone,$role,$id]);
redirect('/?page=admin_users');
