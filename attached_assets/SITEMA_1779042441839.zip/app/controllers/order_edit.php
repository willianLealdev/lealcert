<?php
// app/controllers/order_edit.php — edição do pedido (contador/admin)
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

function esc($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function only_digits_local($s){ return preg_replace('/\D+/', '', (string)($s ?? '')); }

$u    = auth_user();
$role = $u['role'] ?? 'contador';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "ID inválido."; exit; }

$st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st->execute([$id]);
$o = $st->fetch(PDO::FETCH_ASSOC);
if (!$o) { http_response_code(404); echo "Pedido não encontrado."; exit; }

$ownerOk   = ((int)$o['user_id'] === (int)($u['id'] ?? 0));
$status    = $o['status'] ?? 'created';
$editableStatus = !in_array($status, ['protocol_assigned','completed'], true);

// regra: contador só edita se for dono e status permitir; admin pode sempre
$canEdit = ($role === 'admin') || ($ownerOk && $editableStatus);
if (!$canEdit) {
  // sem permissão para editar → volta para detalhes
  header("Location: /?page=order_detail&id={$id}");
  exit;
}

$errors = [];
$ok     = isset($_GET['ok']);

// POST: salvar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
  $customer_name   = trim($_POST['customer_name'] ?? '');
  $customer_email  = trim($_POST['customer_email'] ?? '');
  $customer_phone  = trim($_POST['customer_phone'] ?? '');
  $customer_doc    = only_digits_local($_POST['customer_cpf_cnpj'] ?? ''); // CPF/CNPJ (titular)
  $razao_social    = trim($_POST['RAZAOSOCIAL'] ?? '');
  $cnpj            = only_digits_local($_POST['CNPJ'] ?? '');
  $inss_number     = trim($_POST['inss_number'] ?? '');
  $schedule_date   = trim($_POST['schedule_date'] ?? '');
  $schedule_time   = trim($_POST['schedule_time'] ?? '');
  $scheduled_at    = ($schedule_date && $schedule_time) ? ($schedule_date.' '.$schedule_time.':00') : '';

  if ($customer_name === '') $errors[] = 'Informe o nome do cliente.';
  if ($customer_email === '' || !filter_var($customer_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';
  if ($customer_phone === '') $errors[] = 'Informe o telefone.';
  if ($customer_doc === '' || !(strlen($customer_doc)===11 || strlen($customer_doc)===14)) $errors[] = 'CPF/CNPJ do titular inválido.';
  if ($scheduled_at === '') $errors[] = 'Selecione data e horário do agendamento.';

  // CNH opcional (se enviar, precisa ser PDF até 2MB)
  $cnh_path = $o['cnh_path'] ?? null;
  $replaceCnh = false;
  if (!empty($_FILES['cnh_file']['name']) && is_uploaded_file($_FILES['cnh_file']['tmp_name'])) {
    if ((int)$_FILES['cnh_file']['size'] > 2*1024*1024) $errors[] = 'Arquivo de CNH muito grande (máx 2MB).';
    $fi   = new finfo(FILEINFO_MIME_TYPE);
    $mime = $fi->file($_FILES['cnh_file']['tmp_name']);
    if ($mime !== 'application/pdf') $errors[] = 'A CNH deve ser um arquivo PDF.';
    $replaceCnh = empty($errors);
  }

  if (!$errors) {
    try {
      if ($replaceCnh) {
        $dir = __DIR__ . '/../../storage/uploads/cnh';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $fname = 'cnh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.pdf';
        $dest  = $dir . '/' . $fname;
        if (!move_uploaded_file($_FILES['cnh_file']['tmp_name'], $dest)) {
          $errors[] = 'Falha ao salvar o arquivo de CNH.';
        } else {
          $cnh_path = 'storage/uploads/cnh/' . $fname;
        }
      }
    } catch (Throwable $e) {
      $errors[] = 'Erro ao processar CNH: ' . $e->getMessage();
    }
  }

  if (!$errors) {
    try {
      $pdo->beginTransaction();

      $fields = [
        'customer_name'     => $customer_name,
        'customer_email'    => $customer_email,
        'customer_phone'    => $customer_phone,
        'customer_cpf_cnpj' => $customer_doc,
        'RAZAOSOCIAL'       => ($razao_social !== '' ? $razao_social : null),
        'CNPJ'              => ($cnpj !== '' ? $cnpj : null),
        'inss_number'       => ($inss_number !== '' ? $inss_number : null),
        'scheduled_at'      => $scheduled_at,
      ];
      if ($replaceCnh) $fields['cnh_path'] = $cnh_path;

      $sets   = [];
      $params = [];
      foreach ($fields as $col=>$val) { $sets[] = "$col=?"; $params[] = $val; }
      $sets[] = "updated_at=NOW()";
      $sql = "UPDATE orders SET ".implode(',', $sets)." WHERE id=? LIMIT 1";
      $params[] = $id;

      $up = $pdo->prepare($sql);
      $up->execute($params);

      $pdo->commit();
      header("Location: /?page=order_detail&id={$id}&ok=1");
      exit;

    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = $e->getMessage();
    }
  }
}

// valores para preencher o form
$customer_name  = $o['customer_name'] ?? '';
$customer_email = $o['customer_email'] ?? '';
$customer_phone = $o['customer_phone'] ?? '';
$customer_doc   = $o['customer_cpf_cnpj'] ?? '';
$razao_social   = $o['RAZAOSOCIAL'] ?? '';
$cnpj           = $o['CNPJ'] ?? '';
$inss_number    = $o['inss_number'] ?? '';
$scheduled_at   = $o['scheduled_at'] ?? null;
$curr_date      = $scheduled_at ? date('Y-m-d', strtotime($scheduled_at)) : '';
$curr_time      = $scheduled_at ? date('H:i',    strtotime($scheduled_at)) : '';

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Editar Pedido — <?= esc($o['order_number'] ?: ('#'.$o['id'])) ?></h1>
  <div>
    <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$o['id'] ?>">Voltar</a>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <strong>Não foi possível salvar:</strong>
    <ul class="mb-0">
      <?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="post" enctype="multipart/form-data" id="editOrderForm" class="row g-3" autocomplete="off">
      <input type="hidden" name="action" value="save">

      <div class="col-md-6">
        <label class="form-label">Nome do Cliente <span class="text-danger">*</span></label>
        <input type="text" name="customer_name" class="form-control" value="<?= esc($customer_name) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">E-mail do Cliente <span class="text-danger">*</span></label>
        <input type="email" name="customer_email" class="form-control" value="<?= esc($customer_email) ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">CPF/CNPJ do Titular <span class="text-danger">*</span></label>
        <input type="text" name="customer_cpf_cnpj" id="customer_cpf_cnpj" class="form-control" value="<?= esc($customer_doc) ?>" inputmode="numeric" maxlength="18" required>
        <div class="form-text">Digite apenas números; a máscara será aplicada (CPF ou CNPJ).</div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Telefone do Cliente <span class="text-danger">*</span></label>
        <input type="text" name="customer_phone" class="form-control" value="<?= esc($customer_phone) ?>" required>
        <div class="form-text">Contato para videoconferência.</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Razão Social (opcional)</label>
        <input type="text" name="RAZAOSOCIAL" class="form-control" value="<?= esc($razao_social) ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">CNPJ (opcional)</label>
        <input type="text" name="CNPJ" id="field_cnpj" class="form-control" value="<?= esc($cnpj) ?>" inputmode="numeric" maxlength="18">
      </div>

      <div class="col-md-6">
        <label class="form-label">Nº INSS (CEI/CAEPF/CNO) (opcional)</label>
        <input type="text" name="inss_number" class="form-control" value="<?= esc($inss_number) ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">CNH (PDF) — máx 2MB (opcional)</label>
        <input type="file" name="cnh_file" id="cnh_file" class="form-control" accept="application/pdf">
        <div class="form-text">Enviar apenas se quiser substituir a já enviada.</div>
        <?php if (!empty($o['cnh_path'])): ?>
          <div class="mt-1">Atual: <a target="_blank" href="/<?= esc($o['cnh_path']) ?>">abrir</a></div>
        <?php endif; ?>
      </div>

      <div class="col-md-3">
        <label class="form-label">Data do Agendamento <span class="text-danger">*</span></label>
        <input type="date" id="ridie-date" name="schedule_date" class="form-control" value="<?= esc($curr_date) ?>" required>
      </div>
      <div class="col-12">
        <label class="form-label d-block">Horários disponíveis <span class="text-danger">*</span></label>
        <div id="ridie-slot-list" class="d-flex flex-wrap gap-2"></div>
        <input type="hidden" id="ridie-time" name="schedule_time" value="<?= esc($curr_time) ?>">
        <div id="slotHelp" class="form-text text-danger" style="display:none;">Selecione um horário disponível.</div>
      </div>

      <div class="col-12 d-flex gap-2">
        <button class="btn btn-primary" type="submit">Salvar alterações</button>
        <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$o['id'] ?>">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<script>
(function(){
  function onlyDigits(s){ return (s||'').replace(/\D+/g,''); }
  function maskCPF(v){
    v = onlyDigits(v).slice(0,11);
    v = v.replace(/^(\d{3})(\d)/, '$1.$2');
    v = v.replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
    v = v.replace(/^(\d{3})\.(\d{3})\.(\d{3})(\d{1,2})$/, '$1.$2.$3-$4');
    return v;
  }
  function maskCNPJ(v){
    v = onlyDigits(v).slice(0,14);
    v = v.replace(/^(\d{2})(\d)/, '$1.$2');
    v = v.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
    v = v.replace(/^(\d{2})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3/$4');
    v = v.replace(/^(\d{2})\.(\d{3})\.(\d{3})\/(\d{4})(\d{1,2})$/, '$1.$2.$3/$4-$5');
    return v;
  }

  // máscara doc: se tiver 12+ dígitos, formata como CNPJ, senão CPF
  const docEl  = document.getElementById('customer_cpf_cnpj');
  const cnpjEl = document.getElementById('field_cnpj');
  if (docEl) {
    docEl.addEventListener('input', e=>{
      const raw = onlyDigits(e.target.value);
      e.target.value = (raw.length > 11) ? maskCNPJ(raw) : maskCPF(raw);
    });
  }
  if (cnpjEl) cnpjEl.addEventListener('input', e=> e.target.value = maskCNPJ(e.target.value));

  // slots agenda
  function isWeekend(d){ const w=d.getDay(); return w===0||w===6; }
  function nextBusinessDay(from){
    let d=new Date(from.getFullYear(),from.getMonth(),from.getDate()+1);
    while(isWeekend(d)) d.setDate(d.getDate()+1);
    return d;
  }
  function fmtISO(d){ return d.toISOString().slice(0,10); }

  const dateEl = document.getElementById('ridie-date');
  const listEl = document.getElementById('ridie-slot-list');
  const timeEl = document.getElementById('ridie-time');
  const slotHelp = document.getElementById('slotHelp');

  const today   = new Date();
  const minDate = nextBusinessDay(today);
  const minDateStr = fmtISO(minDate);

  if (!dateEl.value) dateEl.value = minDateStr;
  dateEl.min = minDateStr;

  function makeBtn(hh,mm){
    const btn = document.createElement('button');
    btn.type='button';
    btn.className='btn btn-outline-secondary btn-sm';
    const txt = `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
    btn.textContent = txt;
    if (timeEl.value === txt) btn.classList.add('active');
    btn.addEventListener('click', ()=>{
      listEl.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      timeEl.value = txt;
      slotHelp.style.display = 'none';
    });
    return btn;
  }

  function renderSlots(){
    const v = dateEl.value; listEl.innerHTML='';
    if (!v) return;
    const d = new Date(v+'T00:00:00');
    if (isWeekend(d)){ listEl.innerHTML='<div class="text-muted">Sem horários aos sábados e domingos.</div>'; return; }
    let startMin = 9*60, endMin = 15*60, step=30;
    if (v === minDateStr) startMin = 12*60; // dia útil seguinte só a partir de 12:00
    for (let m=startMin; m<=endMin; m+=step){
      listEl.appendChild(makeBtn(Math.floor(m/60), m%60));
    }
  }
  renderSlots();
  dateEl.addEventListener('change', renderSlots);

  document.getElementById('editOrderForm').addEventListener('submit', function(){
    if (!timeEl.value) { slotHelp.style.display='block'; }
  });
})();
</script>

<?php include __DIR__ . '/../views/_footer.php';
