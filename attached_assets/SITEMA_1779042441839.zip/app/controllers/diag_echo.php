<?php
ini_set('display_errors', '1'); error_reporting(E_ALL);
header('Content-Type: text/plain; charset=utf-8');
echo "router_ok\n";
echo "php_version: " . PHP_VERSION . "\n";
