<?php
require_role('admin');
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $dt = $_POST['slot_datetime'] ?? '';
  if ($dt) { try { $stmt = $pdo->prepare("INSERT INTO available_slots (slot_datetime,active) VALUES (?,1)"); $stmt->execute([$dt]); } catch (Exception $e) {} }
  if (isset($_POST['del'])) { $id = (int)$_POST['del']; $pdo->prepare("DELETE FROM available_slots WHERE id=?")->execute([$id]); }
  redirect('/?page=admin_slots');
}
$slots = $pdo->query("SELECT * FROM available_slots ORDER BY slot_datetime ASC")->fetchAll();
include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Agenda — Datas Disponíveis</h1>
<form method="post" class="row g-3">
  <div class="col-md-4"><label class="form-label">Adicionar slot (AAAA-MM-DD HH:MM:SS)</label><input type="text" name="slot_datetime" class="form-control" placeholder="2025-08-15 09:00:00"></div>
  <div class="col-md-2 align-self-end"><button class="btn btn-primary">Adicionar</button></div>
</form>
<div class="table-responsive mt-3">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Data/Hora</th><th>Ações</th></tr></thead>
  <tbody>
  <?php foreach ($slots as $s): ?>
    <tr>
      <td><?= $s['id'] ?></td>
      <td><?= $s['slot_datetime'] ?></td>
      <td><form method="post" class="d-inline"><input type="hidden" name="del" value="<?= $s['id'] ?>"><button class="btn btn-sm btn-outline-danger">Remover</button></form></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
