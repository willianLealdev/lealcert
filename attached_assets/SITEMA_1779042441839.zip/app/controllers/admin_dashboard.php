<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

include __DIR__ . '/../views/_header.php';
?>

<h1 class="h5 mb-3">Dashboard — Admin</h1>

<form class="row g-2 mb-3" onsubmit="return false;">
  <div class="col-auto">
    <select id="range" class="form-select" onchange="toggleCustom(this.value);loadAdminStats();">
      <option value="today">Hoje</option>
      <option value="7d">Últimos 7 dias</option>
      <option value="15d">Últimos 15 dias</option>
      <option value="30d" selected>Últimos 30 dias</option>
      <option value="90d">Últimos 3 meses</option>
      <option value="custom">Personalizado</option>
    </select>
  </div>
  <div class="col-auto"><input id="from" class="form-control" type="text" placeholder="De (YYYY-MM-DD)" disabled></div>
  <div class="col-auto"><input id="to"   class="form-control" type="text" placeholder="Até (YYYY-MM-DD)" disabled></div>
  <div class="col-auto"><button class="btn btn-primary" onclick="loadAdminStats()">Aplicar</button></div>
</form>

<!-- cards principais -->
<div class="row g-3 mb-3">
  <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Contadores (total)</div><h3 id="c_total_users">0</h3></div></div></div>
  <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Novos cadastros (período)</div><h3 id="c_new_users">0</h3></div></div></div>
  <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Pedidos (período)</div><h3 id="c_orders_period">0</h3></div></div></div>
  <div class="col-md-3"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Contadores que compraram</div><h3 id="c_buyers_period">0</h3></div></div></div>
</div>

<!-- cards por status -->
<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Aguardando pagamento</div><h3 id="c_pending_period">0</h3></div></div></div>
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Pagos</div><h3 id="c_paid_period">0</h3></div></div></div>
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="small text-muted">Com protocolo</div><h3 id="c_protocol_period">0</h3></div></div></div>
</div>

<!-- NOVOS: faturamento -->
<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body">
    <div class="small text-muted">Vendas Hoje</div><h3 id="rev_today">R$ 0,00</h3>
  </div></div></div>
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body">
    <div class="small text-muted">Vendas no Mês</div><h3 id="rev_month">R$ 0,00</h3>
  </div></div></div>
  <div class="col-md-4"><div class="card shadow-sm"><div class="card-body">
    <div class="small text-muted">Vendas Totais</div><h3 id="rev_all">R$ 0,00</h3>
  </div></div></div>
</div>

<!-- gráficos -->
<div class="row g-3">
  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Cadastros por dia</h6>
      <canvas id="chUsers"></canvas>
    </div></div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Pedidos por dia</h6>
      <canvas id="chOrders"></canvas>
    </div></div>
  </div>

  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Tipos de Certificado (pagos/protocolo)</h6>
      <canvas id="chModels"></canvas>
    </div></div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Pedidos por Status (período)</h6>
      <canvas id="chStatus"></canvas>
    </div></div>
  </div>

  <!-- NOVO: Faturamento 12 meses -->
  <div class="col-12">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Faturamento — últimos 12 meses</h6>
      <canvas id="chRevenue12"></canvas>
      <small class="text-muted d-block mt-2">Barras: R$ faturado | Linha: quantidade de certificados</small>
    </div></div>
  </div>

  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Distribuição por Estado (Top 12)</h6>
      <canvas id="chStates"></canvas>
    </div></div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-2">Top compradores no período (Top 10)</h6>
      <canvas id="chTopPeriod"></canvas>
    </div></div>
  </div>

  <div class="col-12">
    <div class="card shadow-sm"><div class="card-body">
      <h6 class="mb-3">Ranking por fidelidade (lifetime) — Top / VIP / Gold</h6>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th>#</th><th>Contador</th><th>Doc</th><th>Pedidos</th><th>Última compra</th><th>Tier</th></tr></thead>
          <tbody id="tblTiers"></tbody>
        </table>
      </div>
      <small class="text-muted d-block mt-2" id="tierInfo"></small>
    </div></div>
  </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
let chU, chO, chS, chTP, chM, chSt, chR12;

function toggleCustom(v){
  const dis = (v!=='custom');
  from.disabled = dis; to.disabled = dis;
}
flatpickr('#from',{dateFormat:'Y-m-d'}); flatpickr('#to',{dateFormat:'Y-m-d'});

function rng(){
  const v = range.value;
  return v==='custom' ? {range:'custom', from:from.value, to:to.value} : {range:v};
}
const brl = n => 'R$ ' + (Number(n||0)).toLocaleString('pt-BR',{minimumFractionDigits:2, maximumFractionDigits:2});

function loadAdminStats(){
  const p = new URLSearchParams(rng()).toString();
  fetch('/?page=admin_stats_api&'+p)
    .then(r=>r.json())
    .then(j=>{
      // cards
      c_total_users.innerText   = j.cards.total_users||0;
      c_new_users.innerText     = j.cards.new_users||0;
      c_orders_period.innerText = j.cards.orders_period||0;
      c_buyers_period.innerText = j.cards.buyers_period||0;
      c_pending_period.innerText  = j.cards.pending_period||0;
      c_paid_period.innerText      = j.cards.paid_period||0;
      c_protocol_period.innerText  = j.cards.protocol_period||0;

      // faturamento
      rev_today.innerText = brl(j.revenue.today);
      rev_month.innerText = brl(j.revenue.month);
      rev_all.innerText   = brl(j.revenue.all);

      // séries
      if (chU) chU.destroy();
      chU = new Chart(chUsers, {type:'line',
        data:{labels:j.users_per_day.map(x=>x.d),
              datasets:[{label:'Cadastros', data:j.users_per_day.map(x=>x.c)}]}});

      if (chO) chO.destroy();
      chO = new Chart(chOrders, {type:'line',
        data:{labels:j.orders_per_day.map(x=>x.d),
              datasets:[{label:'Pedidos', data:j.orders_per_day.map(x=>x.c)}]}});

      if (chM) chM.destroy();
      chM = new Chart(chModels, {type:'doughnut',
        data:{labels:j.models_breakdown.map(x=>x.label),
              datasets:[{data:j.models_breakdown.map(x=>x.c)}]}});

      if (chSt) chSt.destroy();
      chSt = new Chart(chStatus, {type:'bar',
        data:{labels:j.status_breakdown.map(x=>x.status),
              datasets:[{label:'Qtd', data:j.status_breakdown.map(x=>x.c)}]}});

      // Revenue 12 meses (bar = R$, line = contagem)
      if (chR12) chR12.destroy();
      chR12 = new Chart(chRevenue12, {
        type:'bar',
        data:{
          labels: j.revenue12.labels,
          datasets:[
            {type:'bar',  label:'Faturamento (R$)', data:j.revenue12.values},
            {type:'line', label:'Certificados',     data:j.revenue12.counts, yAxisID:'y1'}
          ]
        },
        options:{scales:{y:{beginAtZero:true}, y1:{beginAtZero:true, position:'right'}}}
      });

      // estados
      if (chS) chS.destroy();
      chS = new Chart(chStates, {type:'doughnut',
        data:{labels:j.geo_states.map(x=>x.label),
              datasets:[{data:j.geo_states.map(x=>x.c)}]}});

      // top compradores
      if (chTP) chTP.destroy();
      chTP = new Chart(chTopPeriod, {type:'bar',
        data:{labels:j.top_buyers_period.map(x=>x.name),
              datasets:[{label:'Pedidos', data:j.top_buyers_period.map(x=>x.c)}]}});

      // tiers
      const tb = document.getElementById('tblTiers'); tb.innerHTML='';
      j.tiers_all_time.forEach((r,i)=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${i+1}</td><td>${r.name||''}</td><td>${r.doc||''}</td>
                        <td>${r.c}</td><td>${r.last||''}</td>
                        <td><span class="badge ${r.tier==='gold'?'bg-warning text-dark':(r.tier==='vip'?'bg-primary':'bg-success')} text-uppercase">${r.tier}</span></td>`;
        tb.appendChild(tr);
      });
      tierInfo.innerText = `Regras: TOP ≥ ${j.meta.tiers.top}, VIP ≥ ${j.meta.tiers.vip}, GOLD ≥ ${j.meta.tiers.gold} compras (lifetime).`;
    });
}
loadAdminStats();
</script>

<?php include __DIR__ . '/../views/_footer.php'; ?>
