<?php
require_once __DIR__ . '/config.php';

function mp_create_preference($title, $qty, $unit_price, $order_number) {
  if (!MP_ACCESS_TOKEN) { throw new Exception("MP_ACCESS_TOKEN não configurado no .env"); }
  if (!function_exists('curl_init')) { throw new Exception("Extensão cURL não está habilitada no PHP"); }

  $payload = [
    "items" => [[
      "title" => $title,
      "quantity" => (int)$qty,
      "currency_id" => "BRL",
      "unit_price" => (float)$unit_price
    ]],
    "external_reference" => $order_number,
    "notification_url" => SITE_URL . "/?page=mp_webhook&secret=" . urlencode(WEBHOOK_SECRET),
    "back_urls" => [
      "success" => SITE_URL . "/?page=order_success&order=" . urlencode($order_number),
      "failure" => SITE_URL . "/?page=order_failure&order=" . urlencode($order_number),
      "pending" => SITE_URL . "/?page=order_pending&order=" . urlencode($order_number),
    ],
    "auto_return" => "approved"
  ];

  $ch = curl_init("https://api.mercadopago.com/checkout/preferences");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer " . MP_ACCESS_TOKEN,
    "Content-Type: application/json"
  ]);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
  $resp = curl_exec($ch);
  if ($resp === false) { throw new Exception("Erro cURL: " . curl_error($ch)); }
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($code < 200 || $code >= 300) { throw new Exception("Erro MP HTTP $code: " . $resp); }
  $data = json_decode($resp, true);
  return $data;
}
