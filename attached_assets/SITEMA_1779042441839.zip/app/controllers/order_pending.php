<?php include __DIR__ . '/../views/_header.php'; ?>
<div class="alert alert-warning">Pagamento pendente. Assim que o Mercado Pago aprovar, sua compra será atualizada.</div>
<a href="/?page=orders_me" class="btn btn-primary">Meus Pedidos</a>
<?php include __DIR__ . '/../views/_footer.php'; ?>
