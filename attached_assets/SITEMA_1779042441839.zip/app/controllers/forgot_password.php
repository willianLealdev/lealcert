<?php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

$sent = isset($_GET['sent']);
$err  = isset($_GET['err']);
$preview_link = null;
if (getenv('MAIL_DEBUG') === '1' && !empty($_SESSION['LAST_RESET_LINK'])) {
  $preview_link = $_SESSION['LAST_RESET_LINK'];
  unset($_SESSION['LAST_RESET_LINK']);
}

include __DIR__ . '/../views/_header.php'; ?>
<div class="container py-4" style="max-width:520px">
  <h1 class="h5 mb-3">Recuperar senha</h1>

  <?php if ($sent): ?>
    <div class="alert alert-success">
      Se existir uma conta com os dados informados, enviamos um link para redefinir a senha.
      <br><small>Verifique também sua caixa de spam.</small>
      <?php if ($preview_link): ?>
        <hr class="my-2">
        <div class="small">
          <strong>DEBUG ATIVO:</strong> clique para testar agora:
          <a href="<?= htmlspecialchars($preview_link) ?>" class="link-primary">Abrir link de redefinição</a>
        </div>
      <?php endif; ?>
    </div>
  <?php elseif ($err): ?>
    <div class="alert alert-danger">Informe seu e-mail ou CPF/CNPJ.</div>
  <?php endif; ?>

  <form method="post" action="/?page=do_forgot_password">
    <div class="mb-3">
      <label class="form-label">E-mail ou CPF/CNPJ</label>
      <input class="form-control" type="text" name="identifier" required>
    </div>
    <button class="btn btn-primary w-100">Enviar link</button>
  </form>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
