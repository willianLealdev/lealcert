<?php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

$token = $_GET['token'] ?? '';
$err = $_GET['err'] ?? null;
$ok  = $_GET['ok']  ?? null;

$valid = false;
$name  = '';
if ($token) {
  $stmt = $pdo->prepare("SELECT id, name, reset_password_expires FROM users WHERE reset_password_token=? LIMIT 1");
  $stmt->execute([$token]);
  $u = $stmt->fetch();
  if ($u) {
    $expires_ts = strtotime($u['reset_password_expires'] ?? '1970-01-01 00:00:00');
    if ($expires_ts !== false && $expires_ts >= time()) {
      $valid = true;
      $name  = $u['name'];
    }
  }
}

include __DIR__ . '/../views/_header.php'; ?>
<div class="container py-4" style="max-width:520px">
  <h1 class="h5 mb-3">Definir nova senha</h1>

  <?php if ($ok==='1'): ?>
    <div class="alert alert-success">Senha alterada com sucesso. Você já pode acessar com a nova senha.</div>
    <a class="btn btn-primary w-100" href="/?page=login">Ir para o login</a>
  <?php elseif (!$token): ?>
    <div class="alert alert-danger">Link inválido: token ausente. Solicite novamente em <a href="/?page=forgot_password">Esqueci a senha</a>.</div>
  <?php elseif (!$valid): ?>
    <div class="alert alert-danger">
      Este link é inválido ou expirou. Gere um novo em <a href="/?page=forgot_password">Esqueci a senha</a>.
    </div>
  <?php else: ?>
    <?php if ($err==='1'): ?>
      <div class="alert alert-danger">Informe uma senha com pelo menos 6 caracteres.</div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <p class="mb-2">Olá, <strong><?= htmlspecialchars($name ?: 'usuário') ?></strong>. Defina sua nova senha abaixo:</p>
        <form method="post" action="/?page=do_reset_password">
          <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
          <div class="mb-3">
            <label class="form-label">Nova senha</label>
            <input class="form-control" type="password" name="password" required minlength="6" autocomplete="new-password">
          </div>
          <button class="btn btn-primary w-100">Salvar nova senha</button>
        </form>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
