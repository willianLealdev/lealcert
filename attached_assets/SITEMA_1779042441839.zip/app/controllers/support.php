<?php
// app/controllers/support.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();

$u = auth_user();
$isAdmin = ($u['role'] ?? '') === 'admin';
function esc($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function table_exists(PDO $pdo, string $t): bool {
  try { $pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true; }
  catch (Throwable $e) { return false; }
}

$supportOK = table_exists($pdo,'support_tickets') && table_exists($pdo,'support_messages');

$p = max(1,(int)($_GET['p']??1));
$perPage = 15;
$offset  = ($p-1)*$perPage;

$rows = [];
$totalRows = 0;
$totalPages = 1;
$errorMsg = '';

if ($supportOK) {
  try {
    $where  = $isAdmin ? "1=1" : "t.user_id=:uid";
    $params = $isAdmin ? [] : [':uid'=>(int)$u['id']];

    // total
    $stc = $pdo->prepare("SELECT COUNT(*) FROM support_tickets t WHERE $where");
    $stc->execute($params);
    $totalRows  = (int)$stc->fetchColumn();
    $totalPages = max(1,(int)ceil($totalRows/$perPage));

    // Ordem de prioridade:
    // 1) respondido_cliente  2) aberto  3) respondido_admin  4) outros  9) finalizado
    $orderBy =
      "CASE t.status
         WHEN 'respondido_cliente' THEN 1
         WHEN 'aberto'            THEN 2
         WHEN 'respondido_admin'  THEN 3
         WHEN 'finalizado'        THEN 9
         ELSE 4
       END ASC,
       COALESCE(t.created_at, NOW()) DESC,
       t.id DESC";

    $sql = "SELECT t.*,
                   (SELECT u.name FROM users u WHERE u.id=t.user_id) AS user_name
            FROM support_tickets t
            WHERE $where
            ORDER BY $orderBy
            LIMIT ".(int)$offset.", ".(int)$perPage;

    $st = $pdo->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    // zera alertas (unread) ao abrir a lista
    if ($isAdmin) {
      $pdo->query("UPDATE support_tickets SET unread_admin=0 WHERE unread_admin=1 AND status!='finalizado'");
    } else {
      $mk = $pdo->prepare("UPDATE support_tickets SET unread_client=0 WHERE user_id=? AND unread_client=1 AND status!='finalizado'");
      $mk->execute([(int)$u['id']]);
    }
  } catch (Throwable $e) {
    $supportOK = false;
    $errorMsg  = $e->getMessage();
  }
}

// helpers de status
function status_label($s){
  $map = [
    'aberto'             => 'Aberto',
    'respondido_admin'   => 'Respondido — Suporte',
    'respondido_cliente' => 'Respondido — Cliente',
    'finalizado'         => 'Finalizado',
  ];
  return $map[$s] ?? $s;
}
function status_badge($s){
  $label = status_label($s);
  $cls   = 'bg-secondary';
  switch ($s) {
    case 'aberto':             $cls = 'bg-success'; break;               // verde
    case 'respondido_admin':   $cls = 'bg-warning text-dark'; break;     // amarelo
    case 'respondido_cliente': $cls = 'bg-orange'; break;                // laranja (custom)
    case 'finalizado':         $cls = 'bg-danger'; break;                // vermelho
  }
  return '<span class="badge '.$cls.'">'.esc($label).'</span>';
}

include __DIR__ . '/../views/_header.php';
?>
<style>
  /* cor laranja para "respondido_cliente" */
  .badge.bg-orange{ background:#fd7e14 !important; color:#fff !important; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Suporte — Chamados</h1>
  <a class="btn btn-primary" href="/?page=support_new">Abrir chamado</a>
</div>

<?php if (!$supportOK): ?>
  <div class="alert alert-danger">
    Não foi possível carregar os chamados de suporte.
    <?php if ($errorMsg): ?>
      <div class="small text-muted mt-2">Detalhes técnicos: <?= esc($errorMsg) ?></div>
    <?php endif; ?>
    <hr>
    <div class="small">
      Verifique se as tabelas <code>support_tickets</code> e <code>support_messages</code> existem e têm permissão de leitura.
    </div>
  </div>
<?php else: ?>

<div class="table-responsive">
  <table class="table table-sm align-middle">
    <thead class="table-light">
      <tr>
        <th>#</th><th>Assunto</th><th>Categoria</th><th>Status</th><th>Pedido</th><th>Cliente</th><th>Criação</th><th class="text-end">Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">Nenhum chamado.</td></tr>
      <?php else: foreach ($rows as $r): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= esc($r['subject']) ?></td>
        <td><?= esc(ucfirst($r['category'])) ?></td>
        <td><?= status_badge($r['status']) ?></td>
        <td><?= $r['order_id'] ? '#'.(int)$r['order_id'] : '—' ?></td>
        <td><?= esc($r['user_name'] ?? '—') ?></td>
        <td><?= esc(date('d/m/Y H:i', strtotime($r['created_at']))) ?></td>
        <td class="text-end">
          <a class="btn btn-outline-secondary btn-sm" href="/?page=support_view&id=<?= (int)$r['id'] ?>">Abrir</a>
        </td>
      </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php if ($totalPages > 1): ?>
<nav aria-label="Paginação">
  <ul class="pagination justify-content-center">
    <?php $base='/?page=support&p='; for ($i=1;$i<=$totalPages;$i++): ?>
      <li class="page-item <?= $i===$p?'active':'' ?>"><a class="page-link" href="<?= $base.$i ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<?php endif; ?>

<?php include __DIR__ . '/../views/_footer.php';
