<?php
header('Content-Type: text/plain; charset=utf-8');
echo "RIDIECERT — Mercado Pago Debug\n\n";

$env = @parse_ini_file(__DIR__.'/.env', false, INI_SCANNER_RAW);
if (!$env) { echo "ERRO: não consegui ler .env na raiz\n"; exit; }

$token = $env['MP_ACCESS_TOKEN'] ?? '';
$site  = $env['SITE_URL'] ?? '';

echo "SITE_URL: " . $site . "\n";
echo "MP_ACCESS_TOKEN prefix: " . ($token ? substr($token, 0, 8) : '(vazio)') . "\n";

if (!$token) { echo "\nFALHA: MP_ACCESS_TOKEN vazio no .env\n"; exit; }
if (!function_exists('curl_init')) { echo "\nFALHA: extensão cURL não habilitada\n"; exit; }

$payload = [
  "items" => [[
    "title" => "Teste RIDIECERT",
    "quantity" => 1,
    "currency_id" => "BRL",
    "unit_price" => 10.00
  ]],
  "external_reference" => "RIDIE-DEBUG-" . date('Ymd-His'),
  "notification_url" => rtrim($site,'/') . "/?page=mp_webhook&secret=" . ($env['WEBHOOK_SECRET'] ?? 'changeme'),
  "back_urls" => [
    "success" => rtrim($site,'/') . "/?page=order_success",
    "failure" => rtrim($site,'/') . "/?page=order_failure",
    "pending" => rtrim($site,'/') . "/?page=order_pending",
  ],
  "auto_return" => "approved"
];

$ch = curl_init("https://api.mercadopago.com/checkout/preferences");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Authorization: Bearer " . $token,
  "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
$resp = curl_exec($ch);
$err = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "\nHTTP code: " . $code . "\n";
if ($err) echo "cURL error: $err\n";
echo "Body:\n" . $resp . "\n";

$data = json_decode($resp, true);
if (isset($data['init_point'])) {
  echo "\ninit_point: " . $data['init_point'] . "\n";
}
if (isset($data['sandbox_init_point'])) {
  echo "sandbox_init_point: " . $data['sandbox_init_point'] . "\n";
}
