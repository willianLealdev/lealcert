<?php
ini_set('display_errors','1'); error_reporting(E_ALL);
header('Content-Type: text/plain; charset=utf-8');

echo "=== DIAG RECV (sem banco) ===\n\n";
echo "REQUEST_METHOD: " . ($_SERVER['REQUEST_METHOD'] ?? '') . "\n";
echo "CONTENT_LENGTH: " . ($_SERVER['CONTENT_LENGTH'] ?? '') . "\n";
echo "post_max_size: " . ini_get('post_max_size') . "\n";
echo "upload_max_filesize: " . ini_get('upload_max_filesize') . "\n\n";

echo "--- _POST ---\n"; print_r($_POST);
echo "\n--- _FILES ---\n"; print_r($_FILES); echo "\n";

$okUpload = false;
if (!empty($_FILES['cnh_file']['name']) && is_uploaded_file($_FILES['cnh_file']['tmp_name'])) {
  $dir = __DIR__ . '/../../storage/tmp';
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  $dest = $dir . '/diag_' . date('Ymd_His') . '.pdf';
  if (@move_uploaded_file($_FILES['cnh_file']['tmp_name'], $dest)) {
    $okUpload = true;
    echo "UPLOAD: OK -> $dest\n";
  } else {
    echo "UPLOAD: FALHOU ao mover\n";
  }
} else {
  echo "UPLOAD: arquivo não chegou (is_uploaded_file=false)\n";
}

echo "\n=== FIM ===\n";
