<?php
require_once __DIR__ . '/../config.php';

// Evita problemas de header se algo imprimir por engano
if (function_exists('ob_get_level') && ob_get_level() === 0) { @ob_start(); }

try {
  $token = $_POST['token'] ?? '';
  $pass  = $_POST['password'] ?? '';

  if (!$token) {
    header('Location: /?page=reset_password&err=token'); exit;
  }
  if (!$pass || strlen($pass) < 6) {
    header('Location: /?page=reset_password&token='.urlencode($token).'&err=1'); exit;
  }

  // Busca usuário pelo token
  $stmt = $pdo->prepare("SELECT id, reset_password_expires FROM users WHERE reset_password_token=? LIMIT 1");
  $stmt->execute([$token]);
  $u = $stmt->fetch();

  if (!$u) {
    header('Location: /?page=reset_password&err=invalid'); exit;
  }
  if (strtotime($u['reset_password_expires']) < time()) {
    header('Location: /?page=reset_password&err=expired'); exit;
  }

  // Descobre o nome da coluna de senha: 'password' (padrão) ou 'password_hash' (algumas instalações)
  $pwdCol = 'password';
  $chk = $pdo->query("SHOW COLUMNS FROM users LIKE 'password'");
  if (!$chk->fetch()) {
    $chk2 = $pdo->query("SHOW COLUMNS FROM users LIKE 'password_hash'");
    if ($chk2->fetch()) { $pwdCol = 'password_hash'; }
    else {
      // Nenhuma das duas existe — mostra erro de diagnóstico
      http_response_code(500);
      echo "ERRO: coluna de senha não encontrada na tabela 'users'. Crie 'password' (VARCHAR 255) ou ajuste o código.";
      exit;
    }
  }

  // Hash seguro (bcrypt)
  $hash = password_hash($pass, PASSWORD_BCRYPT);

  // Atualiza a senha e limpa o token
  $sql = "UPDATE users SET {$pwdCol}=?, reset_password_token=NULL, reset_password_expires=NULL WHERE id=?";
  $upd = $pdo->prepare($sql);
  $upd->execute([$hash, $u['id']]);

  // Redireciona para confirmação
  header('Location: /?page=reset_password&ok=1'); exit;

} catch (Throwable $e) {
  // DEBUG: exponho a mensagem aqui pra gente resolver rápido.
  // Depois que funcionar, trocamos por log e redirecionamento silencioso.
  http_response_code(500);
  echo "Falha ao redefinir a senha.<br>";
  echo "<pre style='white-space:pre-wrap;font-family:monospace'>";
  echo "Mensagem: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "\n";
  if ($e instanceof PDOException) {
    echo "Código SQLSTATE: " . $e->getCode() . "\n";
  }
  echo "</pre>";
  exit;
} finally {
  if (function_exists('ob_get_level') && ob_get_level() > 0) { @ob_end_flush(); }
}
