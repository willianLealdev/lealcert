<?php
// app/controllers/support_new.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../lib/mailer.php';
require_login();

$u = auth_user();
$err = null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $subject = trim($_POST['subject'] ?? '');
  $category= $_POST['category'] ?? 'outras';
  $orderRaw= trim($_POST['order_number'] ?? ''); // cliente digita
  $message = trim($_POST['message'] ?? '');

  $orderId = null;
  if ($orderRaw !== '') {
    // aceita "#123" ou "123"
    $orderId = (int)preg_replace('/\D+/', '', $orderRaw);
    if ($orderId <= 0) $orderId = null;
  }

  if ($subject==='' || $message==='') {
    $err = "Preencha assunto e mensagem.";
  } else {
    try {
      $ins = $pdo->prepare("INSERT INTO support_tickets (user_id, order_id, category, subject, status, unread_admin, unread_client, created_at)
                            VALUES (?,?,?,?, 'aberto', 1, 0, NOW())");
      $ins->execute([(int)$u['id'], $orderId, $category, $subject]);
      $ticketId = (int)$pdo->lastInsertId();

      $m = $pdo->prepare("INSERT INTO support_messages (ticket_id, sender_role, message, created_at) VALUES (?,?,?,NOW())");
      $m->execute([$ticketId, (($u['role'] ?? '')==='admin'?'admin':'contador'), $message]);

      // notifica admins
      notify_support_new_for_admin($pdo, $ticketId);

      header("Location: /?page=support_view&id=".$ticketId."&ok=1");
      exit;
    } catch(Throwable $e) {
      $err = "Erro ao abrir chamado: ".$e->getMessage();
    }
  }
}

include __DIR__ . '/../views/_header.php';
function esc($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<h1 class="h5 mb-3">Abrir chamado</h1>

<?php if ($err): ?><div class="alert alert-danger"><?= esc($err) ?></div><?php endif; ?>

<form method="post" class="row g-3">
  <div class="col-md-6">
    <label class="form-label">Assunto <span class="text-danger">*</span></label>
    <input type="text" name="subject" class="form-control" required maxlength="160">
  </div>
  <div class="col-md-3">
    <label class="form-label">Categoria <span class="text-danger">*</span></label>
    <select name="category" class="form-select" required>
      <option value="financeiro">Financeiro</option>
      <option value="emissao">Emissão</option>
      <option value="pedidos">Pedidos</option>
      <option value="outras" selected>Outras dúvidas</option>
    </select>
  </div>
  <div class="col-md-3">
    <label class="form-label">Pedido (opcional)</label>
    <input type="text" name="order_number" class="form-control" placeholder="Ex.: 20250815-0001 ou #123">
  </div>

  <div class="col-12">
    <label class="form-label">Mensagem <span class="text-danger">*</span></label>
    <textarea name="message" class="form-control" rows="6" required></textarea>
  </div>

  <div class="col-12 d-flex gap-2">
    <button class="btn btn-primary">Abrir chamado</button>
    <a class="btn btn-outline-secondary" href="/?page=support">Cancelar</a>
  </div>
</form>

<?php include __DIR__ . '/../views/_footer.php';
