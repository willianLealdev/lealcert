<?php
require_role('admin');
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM certificate_models WHERE id=?");
$stmt->execute([$id]); $m = $stmt->fetch();
if (!$m) redirect('/?page=admin_models');
include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Editar Modelo #<?= $m['id'] ?></h1>
<form method="post" action="/?page=admin_model_save">
  <input type="hidden" name="id" value="<?= $m['id'] ?>">
  <div class="mb-3"><label class="form-label">Nome</label><input name="name" class="form-control" value="<?= sanitize($m['name']) ?>" required></div>
  <div class="mb-3"><label class="form-label">Descrição</label><textarea name="description" class="form-control" rows="4"><?= sanitize($m['description']) ?></textarea></div>
  <div class="mb-3"><label class="form-label">Preço (R$)</label><input name="price" type="number" step="0.01" class="form-control" value="<?= $m['price'] ?>"></div>
  <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="active" <?= $m['active']?'checked':'' ?>><label class="form-check-label">Ativo</label></div>
  <button class="btn btn-primary">Salvar</button>
</form>
<?php include __DIR__ . '/../views/_footer.php'; ?>
