<?php
// app/controllers/admin_users.php (versão simples + botão Excluir)
require_role('admin');

// Carrega lista de usuários com fallback de erro
$rows = [];
$err  = null;
try {
  $stmt = $pdo->query("SELECT id,name,email,cpf_cnpj,role,phone,created_at FROM users ORDER BY id DESC");
  $rows = $stmt->fetchAll();
} catch (Throwable $e) {
  $err = $e->getMessage();
}

include __DIR__ . '/../views/_header.php';
?>
<h1 class="h4 mb-3">Usuários</h1>

<?php if ($err): ?>
  <div class="alert alert-danger">Erro ao carregar usuários: <?= sanitize($err) ?></div>
<?php endif; ?>

<div class="table-responsive">
<table class="table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Nome</th>
      <th>CPF/CNPJ</th>
      <th>Perfil</th>
      <th>E-mail</th>
      <th>Fone</th>
      <th>Criado</th>
      <th>Ações</th>
    </tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="8" class="text-center text-muted">Nenhum usuário encontrado.</td></tr>
  <?php else: ?>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= sanitize($r['name']) ?></td>
        <td><?= sanitize($r['cpf_cnpj']) ?></td>
        <td><?= sanitize($r['role']) ?></td>
        <td><?= sanitize($r['email']) ?></td>
        <td><?= sanitize($r['phone']) ?></td>
        <td><?= $r['created_at'] ? date('d/m/Y H:i', strtotime($r['created_at'])) : '—' ?></td>
        <td>
          <a class="btn btn-sm btn-outline-primary" href="/?page=admin_user_edit&id=<?= (int)$r['id'] ?>">Editar</a>
          <a class="btn btn-sm btn-outline-warning" href="/?page=admin_user_reset&id=<?= (int)$r['id'] ?>">Reset Senha</a>
          <a class="btn btn-sm btn-outline-danger"
             href="/?page=admin_user_delete&id=<?= (int)$r['id'] ?>"
             onclick="return confirm('Excluir o usuário <?= sanitize($r['name']) ?> (ID <?= (int)$r['id'] ?>)?');">
             Excluir
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
