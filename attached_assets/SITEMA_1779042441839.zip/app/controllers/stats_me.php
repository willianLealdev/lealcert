<?php
$u = auth_user();
$labels = ['created','pending_payment','paid','protocol_assigned','completed'];
$values = [];
foreach ($labels as $s) {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id=? AND status=?");
  $stmt->execute([$u['id'],$s]);
  $values[] = (int)$stmt->fetchColumn();
}
header('Content-Type: application/json');
echo json_encode(['labels'=>$labels,'values'=>$values]);
