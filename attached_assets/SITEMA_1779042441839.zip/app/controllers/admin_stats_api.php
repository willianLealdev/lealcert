<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

header('Content-Type: application/json; charset=utf-8');

/* helpers schema */
function col_exists(PDO $pdo, string $t, string $c): bool { try{$q=$pdo->query("SHOW COLUMNS FROM `$t` LIKE '$c'"); return (bool)$q->fetch();}catch(Throwable $e){return false;} }
function pick_col(PDO $pdo, string $t, array $cands, ?string $fallback=null): ?string { foreach($cands as $c) if (col_exists($pdo,$t,$c)) return $c; return $fallback; }
function table_exists(PDO $pdo, string $t): bool { try{$pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true;}catch(Throwable $e){return false;} }
function pick_table(PDO $pdo, array $cands): ?string { foreach($cands as $t) if (table_exists($pdo,$t)) return $t; return null; }

/* tabelas/colunas */
$usersTbl    = 'users';
$userIdCol   = pick_col($pdo,$usersTbl,['id'],'id');
$userNameCol = pick_col($pdo,$usersTbl,['name','nome'],'name');
$userDocCol  = pick_col($pdo,$usersTbl,['cpf_cnpj','documento','doc'],'cpf_cnpj');
$userRoleCol = pick_col($pdo,$usersTbl,['role','perfil','tipo'],'role');
$userCityCol = pick_col($pdo,$usersTbl,['city','cidade'],null);
$userUfCol   = pick_col($pdo,$usersTbl,['state','uf','estado'],null);
$userCreated = pick_col($pdo,$usersTbl,['created_at','created','created_on','dt_created','inserted_at'],'created_at');

$ordersTbl   = 'orders';
$ownerCol    = pick_col($pdo,$ordersTbl,['user_id','contador_id','owner_id','created_by']);
$orderCreated= pick_col($pdo,$ordersTbl,['created_at','created','created_on','createdAt','dt_created'],'created_at');
$orderStatus = pick_col($pdo,$ordersTbl,['status','order_status'],'status');
$orderNoCol  = pick_col($pdo,$ordersTbl,['order_number','numero_pedido','numero','ref','id'],'id');
$modelIdCol  = pick_col($pdo,$ordersTbl,['model_id','certificate_model_id','product_id'],null);

/* modelos (para preço fallback) */
$modelsTbl    = pick_table($pdo, ['certificate_models','products','product_models','models']);
$modelsNameCol= 'name';
if ($modelsTbl) foreach (['name','title','label','descricao'] as $nm) { if (col_exists($pdo,$modelsTbl,$nm)) {$modelsNameCol=$nm; break;} }
$modelsPriceCol = null;
if ($modelsTbl) foreach (['price','valor','amount','preco','value'] as $nm) { if (col_exists($pdo,$modelsTbl,$nm)) {$modelsPriceCol=$nm; break;} }

/* coluna de valor no pedido (quando existir) */
$amountCol = pick_col($pdo,$ordersTbl,['total_amount','total','amount','price','valor','grand_total','order_total'],null);

/* expressão de valor e join necessário */
$joinAmount = '';
if ($amountCol) {
  $amountExpr = "o.`$amountCol`";
} elseif ($modelsTbl && $modelIdCol && $modelsPriceCol) {
  $amountExpr = "m.`$modelsPriceCol`";
  $joinAmount = "JOIN `$modelsTbl` m ON m.id = o.`$modelIdCol`";
} else {
  $amountExpr = "0";
}

/* range */
$range = $_GET['range'] ?? '30d';
$from  = $_GET['from'] ?? null;
$to    = $_GET['to']   ?? null;

$tz = new DateTimeZone(date_default_timezone_get() ?: 'America/Sao_Paulo');
$now = new DateTimeImmutable('now', $tz);
if ($range==='custom' && $from && $to) {
  $start=(new DateTime($from.' 00:00:00',$tz))->format('Y-m-d H:i:s');
  $end  =(new DateTime($to  .' 23:59:59',$tz))->format('Y-m-d H:i:s');
} else {
  switch ($range) {
    case 'today': $start=$now->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '7d':    $start=$now->modify('-6 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '15d':   $start=$now->modify('-14 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '90d':   $start=$now->modify('-89 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
    case '30d':
    default:      $start=$now->modify('-29 days')->format('Y-m-d 00:00:00'); $end=$now->format('Y-m-d 23:59:59'); break;
  }
}

/* listas de status equivalentes */
$pendingList = ["pending_payment","aguardando_pagamento","pendente","pending"];
$paidList    = ["paid","pago"];
$protoList   = ["protocol_assigned","protocolo","com_protocolo","concluida","completed","finalizado"];
$inPending = implode(',', array_map(fn($s)=>$pdo->quote($s), $pendingList));
$inPaid    = implode(',', array_map(fn($s)=>$pdo->quote($s), $paidList));
$inProto   = implode(',', array_map(fn($s)=>$pdo->quote($s), $protoList));
$inPaidOrProto = $inPaid . ',' . $inProto;

/* cards principais */
$roleCont = 'contador';
$q = $pdo->prepare("SELECT COUNT(*) FROM `$usersTbl` WHERE `$userRoleCol`=?"); $q->execute([$roleCont]); $totalUsers=(int)$q->fetchColumn();
$q = $pdo->prepare("SELECT COUNT(*) FROM `$usersTbl` WHERE `$userRoleCol`=? AND `$userCreated` BETWEEN ? AND ?");
$q->execute([$roleCont,$start,$end]); $newUsers=(int)$q->fetchColumn();

$ordersPeriod=0; $buyersPeriod=0;
if ($orderCreated) {
  $row = $pdo->query("
    SELECT COUNT(*) c, COUNT(DISTINCT `$ownerCol`) buyers
    FROM `$ordersTbl`
    WHERE `$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)
  )->fetch(PDO::FETCH_ASSOC);
  $ordersPeriod = (int)($row['c'] ?? 0);
  $buyersPeriod = (int)($row['buyers'] ?? 0);
}

/* cards por status no período */
$pendingPeriod=0; $paidPeriod=0; $protocolPeriod=0;
if ($orderCreated) {
  $row = $pdo->query("
    SELECT
      SUM(CASE WHEN `$orderStatus` IN ($inPending) THEN 1 ELSE 0 END) AS pending,
      SUM(CASE WHEN `$orderStatus` IN ($inPaid)    THEN 1 ELSE 0 END) AS paid,
      SUM(CASE WHEN `$orderStatus` IN ($inProto)   THEN 1 ELSE 0 END) AS protocol
    FROM `$ordersTbl`
    WHERE `$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)
  )->fetch(PDO::FETCH_ASSOC);
  $pendingPeriod  = (int)($row['pending'] ?? 0);
  $paidPeriod     = (int)($row['paid'] ?? 0);
  $protocolPeriod = (int)($row['protocol'] ?? 0);
}

/* séries por dia */
$usersPerDay = $pdo->prepare("
  SELECT DATE(`$userCreated`) d, COUNT(*) c
  FROM `$usersTbl`
  WHERE `$userRoleCol`=? AND `$userCreated` BETWEEN ? AND ?
  GROUP BY DATE(`$userCreated`) ORDER BY d
");
$usersPerDay->execute([$roleCont,$start,$end]);
$usersPerDay = $usersPerDay->fetchAll(PDO::FETCH_ASSOC);

$ordersPerDay=[];
if ($orderCreated) {
  $ordersPerDay = $pdo->query("
    SELECT DATE(`$orderCreated`) d, COUNT(*) c
    FROM `$ordersTbl`
    WHERE `$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)."
    GROUP BY DATE(`$orderCreated`) ORDER BY d
  ")->fetchAll(PDO::FETCH_ASSOC);
}

/* geo */
$geoStates=[]; if ($userUfCol){
  $st=$pdo->prepare("SELECT UPPER(TRIM(`$userUfCol`)) label, COUNT(*) c
                     FROM `$usersTbl` WHERE `$userRoleCol`=? AND `$userUfCol` IS NOT NULL AND `$userUfCol` <> ''
                     GROUP BY UPPER(TRIM(`$userUfCol`)) ORDER BY c DESC LIMIT 12");
  $st->execute([$roleCont]); $geoStates=$st->fetchAll(PDO::FETCH_ASSOC);
}

/* top compradores no período (pagos/protocolo) */
$topPeriod=[];
if ($ownerCol && $orderCreated){
  $sql="SELECT u.`$userIdCol` uid, u.`$userNameCol` name, u.`$userDocCol` doc, COUNT(o.`$orderNoCol`) c
        FROM `$ordersTbl` o
        JOIN `$usersTbl` u ON u.`$userIdCol`=o.`$ownerCol`
        WHERE o.`$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)."
          AND o.`$orderStatus` IN ($inPaidOrProto)
          AND u.`$userRoleCol`=".$pdo->quote($roleCont)."
        GROUP BY u.`$userIdCol`, u.`$userNameCol`, u.`$userDocCol`
        ORDER BY c DESC LIMIT 10";
  $topPeriod = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

/* inatividade (sem compras pagas há X dias) */
$inact=['no_30'=>0,'no_90'=>0,'no_180'=>0,'no_365'=>0];
if ($ownerCol && $orderCreated){
  $sql="SELECT u.`$userIdCol` uid,
               MAX(CASE WHEN o.`$orderStatus` IN ($inPaidOrProto) THEN o.`$orderCreated` END) last_buy
        FROM `$usersTbl` u
        LEFT JOIN `$ordersTbl` o ON o.`$ownerCol`=u.`$userIdCol`
        WHERE u.`$userRoleCol`=".$pdo->quote($roleCont)."
        GROUP BY u.`$userIdCol`";
  $rows=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
  $nowTs=time();
  foreach($rows as $r){
    $last=$r['last_buy']?strtotime($r['last_buy']):0;
    $days=$last?floor(($nowTs-$last)/86400):99999;
    if($days>=30)$inact['no_30']++;
    if($days>=90)$inact['no_90']++;
    if($days>=180)$inact['no_180']++;
    if($days>=365)$inact['no_365']++;
  }
}

/* modelos (TIPO de certificado) — pagos/protocolo no período */
$modelsBreak=[];
if ($modelsTbl && $modelIdCol && $orderCreated){
  $sql="SELECT m.`$modelsNameCol` label, COUNT(*) c
        FROM `$ordersTbl` o
        JOIN `$modelsTbl` m ON m.id = o.`$modelIdCol`
        WHERE o.`$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)."
          AND o.`$orderStatus` IN ($inPaidOrProto)
        GROUP BY m.id ORDER BY c DESC";
  $modelsBreak=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

/* status breakdown (todos os pedidos do período) */
$statusBreak=[];
if ($orderCreated){
  $sql="SELECT `$orderStatus` AS status, COUNT(*) c
        FROM `$ordersTbl`
        WHERE `$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end)."
        GROUP BY `$orderStatus` ORDER BY c DESC";
  $statusBreak=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

/* ======= Faturamento ======= */
$revenue = ['today'=>0,'month'=>0,'all'=>0,'period'=>0];

/* hoje */
if ($orderCreated){
  $sql="SELECT SUM($amountExpr) v FROM `$ordersTbl` o $joinAmount
        WHERE o.`$orderStatus` IN ($inPaidOrProto)
          AND DATE(o.`$orderCreated`) = CURDATE()";
  $revenue['today'] = (float)($pdo->query($sql)->fetchColumn() ?: 0);
}

/* mês atual */
if ($orderCreated){
  $sql="SELECT SUM($amountExpr) v FROM `$ordersTbl` o $joinAmount
        WHERE o.`$orderStatus` IN ($inPaidOrProto)
          AND YEAR(o.`$orderCreated`) = YEAR(CURDATE())
          AND MONTH(o.`$orderCreated`) = MONTH(CURDATE())";
  $revenue['month'] = (float)($pdo->query($sql)->fetchColumn() ?: 0);
}

/* total (lifetime) */
$sql="SELECT SUM($amountExpr) v FROM `$ordersTbl` o $joinAmount
      WHERE o.`$orderStatus` IN ($inPaidOrProto)";
$revenue['all'] = (float)($pdo->query($sql)->fetchColumn() ?: 0);

/* período atual do filtro */
if ($orderCreated){
  $sql="SELECT SUM($amountExpr) v FROM `$ordersTbl` o $joinAmount
        WHERE o.`$orderStatus` IN ($inPaidOrProto)
          AND o.`$orderCreated` BETWEEN ".$pdo->quote($start)." AND ".$pdo->quote($end);
  $revenue['period'] = (float)($pdo->query($sql)->fetchColumn() ?: 0);
}

/* 12 meses (bar R$, line contagem) */
$labels=[]; $values=[]; $counts=[];
$firstMonth = (new DateTime('first day of -11 months', $tz))->format('Y-m-01 00:00:00');
$monthlySql = "
  SELECT DATE_FORMAT(o.`$orderCreated`,'%Y-%m') ym,
         SUM($amountExpr) total,
         COUNT(*) cnt
  FROM `$ordersTbl` o
  $joinAmount
  WHERE o.`$orderStatus` IN ($inPaidOrProto)
    AND o.`$orderCreated` >= ".$pdo->quote($firstMonth)."
  GROUP BY ym ORDER BY ym
";
$rows = $orderCreated ? $pdo->query($monthlySql)->fetchAll(PDO::FETCH_ASSOC) : [];
// preencher meses faltantes com zero
$map=[];
foreach($rows as $r){ $map[$r['ym']] = ['v'=>(float)$r['total'],'c'=>(int)$r['cnt']]; }
$dt = new DateTime('first day of -11 months', $tz);
for($i=0;$i<12;$i++){
  $ym = $dt->format('Y-m');
  $labels[] = strftime('%b/%Y', $dt->getTimestamp());
  $values[] = isset($map[$ym]) ? $map[$ym]['v'] : 0;
  $counts[] = isset($map[$ym]) ? $map[$ym]['c'] : 0;
  $dt->modify('+1 month');
}

/* tiers lifetime (mantido) */
$tiersCfg=['top'=>10,'vip'=>25,'gold'=>50];
$tiers=[];
if ($ownerCol){
  $sql="SELECT u.`$userIdCol` uid, u.`$userNameCol` name, u.`$userDocCol` doc,
               COUNT(CASE WHEN o.`$orderStatus` IN ($inPaidOrProto) THEN 1 END) c,
               MAX(CASE WHEN o.`$orderStatus` IN ($inPaidOrProto) THEN o.`$orderCreated` END) last_buy
        FROM `$usersTbl` u
        LEFT JOIN `$ordersTbl` o ON o.`$ownerCol`=u.`$userIdCol`
        WHERE u.`$userRoleCol`=".$pdo->quote($roleCont)."
        GROUP BY u.`$userIdCol`, u.`$userNameCol`, u.`$userDocCol`
        HAVING c > 0
        ORDER BY c DESC, last_buy DESC
        LIMIT 50";
  $rows=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
  foreach($rows as $r){
    $cnt=(int)$r['c']; $tier='top';
    if($cnt>=$tiersCfg['gold'])$tier='gold';
    elseif($cnt>=$tiersCfg['vip'])$tier='vip';
    elseif($cnt>=$tiersCfg['top'])$tier='top';
    $tiers[]=['uid'=>(int)$r['uid'],'name'=>$r['name'],'doc'=>$r['doc'],'c'=>$cnt,'last'=>$r['last_buy']?date('d/m/Y H:i',strtotime($r['last_buy'])):'','tier'=>$tier];
  }
}

/* resposta */
echo json_encode([
  'cards'=>[
    'total_users'=>$totalUsers,
    'new_users'=>$newUsers,
    'orders_period'=>$ordersPeriod,
    'buyers_period'=>$buyersPeriod,
    'pending_period'=>$pendingPeriod,
    'paid_period'=>$paidPeriod,
    'protocol_period'=>$protocolPeriod,
  ],
  'revenue'=>$revenue,
  'users_per_day'=>$usersPerDay,
  'orders_per_day'=>$ordersPerDay,
  'models_breakdown'=>$modelsBreak,
  'status_breakdown'=>$statusBreak,
  'geo_states'=>$geoStates,
  'top_buyers_period'=>$topPeriod,
  'inactive'=>$inact,
  'revenue12'=>[
    'labels'=>$labels,'values'=>$values,'counts'=>$counts
  ],
  'tiers_all_time'=>$tiers,
  'meta'=>[
    'tables'=>['users'=>$usersTbl,'orders'=>$ordersTbl,'models'=>$modelsTbl],
    'cols'=>[
      'userId'=>$userIdCol,'userName'=>$userNameCol,'userDoc'=>$userDocCol,'userRole'=>$userRoleCol,
      'userCity'=>$userCityCol,'userState'=>$userUfCol,'userCreated'=>$userCreated,
      'ownerCol'=>$ownerCol,'orderCreated'=>$orderCreated,'orderStatus'=>$orderStatus,'orderNo'=>$orderNoCol,
      'modelId'=>$modelIdCol,'modelName'=>$modelsNameCol,
      'amountCol'=>$amountCol,'modelsPriceCol'=>$modelsPriceCol
    ],
    'range'=>[$start,$end],
    'tiers'=>$tiersCfg
  ]
]);
