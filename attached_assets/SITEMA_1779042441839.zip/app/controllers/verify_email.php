<?php
// app/controllers/verify_email.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php'; // config já carrega mailer.php (send_mail)

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function col_exists(PDO $pdo, string $t, string $c): bool {
  try { $q=$pdo->prepare("SHOW COLUMNS FROM `$t` LIKE ?"); $q->execute([$c]); return (bool)$q->fetch(); }
  catch(Throwable $e){ return false; }
}

$token = trim((string)($_GET['token'] ?? ''));
if ($token === '') {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger">Token ausente.</div>';
  echo '<a class="btn btn-secondary" href="/?page=login">Voltar ao login</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}

try {
  // Busca EXATA (case-sensitive) pelo token
  $st = $pdo->prepare("SELECT id, name, email FROM users WHERE BINARY email_verification_token = ? LIMIT 1");
  $st->execute([$token]);
  $u = $st->fetch(PDO::FETCH_ASSOC);

  if (!$u) {
    include __DIR__ . '/../views/_header.php';
    echo '<div class="alert alert-warning">Token inválido ou já utilizado.</div>';
    echo '<a class="btn btn-primary" href="/?page=login">Ir para o login</a>';
    include __DIR__ . '/../views/_footer.php';
    exit;
  }

  $uid   = (int)$u['id'];
  $name  = (string)$u['name'];
  $email = (string)$u['email'];

  // Confirma e ativa (se as colunas existirem)
  $sets = ["email_verification_token = NULL"];
  if (col_exists($pdo,'users','email_verified')) $sets[] = "email_verified = 1";
  if (col_exists($pdo,'users','is_active'))      $sets[] = "is_active = 1";

  $sql = "UPDATE users SET ".implode(", ", $sets)." WHERE id = ?";
  $up = $pdo->prepare($sql);
  $up->execute([$uid]);

  // Envia e-mail de boas-vindas SIMPLES (o que funcionava)
  $base     = function_exists('app_base_url') ? app_base_url() : (rtrim(getenv('SITE_URL') ?: '', '/'));
  $loginUrl = $base.'/?page=login';
  $app      = defined('APP_NAME') ? APP_NAME : 'RIDIECERT';

  if (function_exists('send_mail') && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $html =
'<!doctype html><html><body style="margin:0;padding:24px;background:#f6f9fc;font-family:Arial,Helvetica,sans-serif;">'
.'<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #e6ecf5;border-radius:12px;">'
  .'<tr>'
    .'<td style="background:#0d6efd;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0;font-size:18px;font-weight:700;">'.h($app).'</td>'
  .'</tr>'
  .'<tr>'
    .'<td style="padding:22px;">'
      .'<p style="margin:0 0 10px 0;font-size:16px;">Olá, <strong>'.h($name).'</strong> 👋</p>'
      .'<p style="margin:0 0 12px 0;color:#374151;font-size:14px;line-height:1.6;">'
        .'Seu e-mail foi confirmado com sucesso no <strong>'.h($app).'</strong>!'
        .' Agora você já pode acessar o painel e iniciar seus pedidos com rapidez e segurança.'
      .'</p>'
      .'<p style="margin:16px 0 18px 0;">'
        .'<a href="'.h($loginUrl).'" '
           .'style="background:#0d6efd;color:#ffffff;text-decoration:none;padding:12px 18px;'
                  .'border-radius:10px;display:inline-block;font-weight:600;">'
          .'Acessar meu painel'
        .'</a>'
      .'</p>'
      .'<p style="margin:0 0 10px 0;color:#6b7280;font-size:12px;">'
        .'Se o botão não funcionar, copie e cole este link no navegador:<br>'
        .'<span style="word-break:break-all;color:#111827;">'.h($loginUrl).'</span>'
      .'</p>'
    .'</td>'
  .'</tr>'
  .'<tr>'
    .'<td style="background:#fafbff;border-top:1px solid #eef2f7;padding:14px 20px;color:#6b7280;font-size:12px;border-radius:0 0 12px 12px;">'
      .'© '.date('Y').' '.h($app).'. Todos os direitos reservados.'
    .'</td>'
  .'</tr>'
.'</table>'
.'</body></html>';

    @send_mail($email, 'Bem-vindo(a) — '.$app, $html);
  }

  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-success">E-mail confirmado! Sua conta foi ativada.</div>';
  echo '<a class="btn btn-primary" href="/?page=login">Ir para o login</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;

} catch (Throwable $e) {
  include __DIR__ . '/../views/_header.php';
  echo '<div class="alert alert-danger"><strong>Falha na verificação:</strong><br><span class="small">'.h($e->getMessage()).'</span></div>';
  echo '<a class="btn btn-secondary" href="/?page=login">Voltar ao login</a>';
  include __DIR__ . '/../views/_footer.php';
  exit;
}
