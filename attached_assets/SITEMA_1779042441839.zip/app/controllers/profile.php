<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
$u = auth_user();
include __DIR__ . '/../views/_header.php'; ?>
<div class="container py-3" style="max-width:820px">
  <h1 class="h5 mb-3">Meu Perfil</h1>
  <form method="post" action="/?page=do_profile" enctype="multipart/form-data" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Nome</label>
      <input class="form-control" type="text" name="name" value="<?= sanitize($u['name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">E-mail</label>
      <input class="form-control" type="email" name="email" value="<?= sanitize($u['email']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Cidade</label>
      <input class="form-control" type="text" name="city" value="<?= sanitize($u['city'] ?? '') ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">UF</label>
      <input class="form-control" type="text" name="state" maxlength="2" value="<?= sanitize($u['state'] ?? '') ?>">
    </div>
    <div class="col-md-4">
      <label class="form-label">Telefone do Escritório</label>
      <input class="form-control" type="text" name="office_phone" value="<?= sanitize($u['office_phone'] ?? '') ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Nome do Escritório</label>
      <input class="form-control" type="text" name="company_name" value="<?= sanitize($u['company_name'] ?? '') ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">CNPJ do Escritório</label>
      <input class="form-control" type="text" name="company_cnpj" value="<?= sanitize($u['company_cnpj'] ?? '') ?>">
    </div>
    <div class="col-md-12">
      <label class="form-label">Foto/Logo (png/jpg, até 2MB)</label>
      <input class="form-control" type="file" name="avatar" accept=".png,.jpg,.jpeg">
      <?php if(!empty($u['avatar_path'])): ?>
        <small class="text-muted">Atual: <a href="/storage/uploads/avatars/<?= sanitize($u['avatar_path']) ?>" target="_blank">ver</a></small>
      <?php endif; ?>
    </div>
    <div class="col-12">
      <button class="btn btn-primary">Salvar</button>
    </div>
  </form>
</div>
<?php include __DIR__ . '/../views/_footer.php'; ?>
