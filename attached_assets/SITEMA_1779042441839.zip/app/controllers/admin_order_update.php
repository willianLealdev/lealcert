<?php
// app/controllers/admin_order_update.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');
require_once __DIR__ . '/../mailer.php';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
  http_response_code(405);
  echo "M��todo n�0�0o permitido."; exit;
}

$id              = (int)($_POST['id'] ?? 0);
$status          = trim($_POST['status'] ?? '');
$protocol_number = trim($_POST['protocol_number'] ?? '');
$codigo_chave    = trim($_POST['codigo_chave'] ?? '');

if ($id <= 0) { http_response_code(400); echo "ID inv��lido."; exit; }

// Carrega pedido antes
$st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st->execute([$id]);
$before = $st->fetch();
if (!$before) { http_response_code(404); echo "Pedido n�0�0o encontrado."; exit; }

$set = [];
$params = [];

if ($status !== '')           { $set[] = "status=?";           $params[] = $status; }
if ($protocol_number !== '')  { $set[] = "protocol_number=?";  $params[] = $protocol_number; }
if ($codigo_chave !== '')     { $set[] = "codigo_chave=?";     $params[] = $codigo_chave; }
$set[] = "updated_at=NOW()";

if (count($set)) {
  $params[] = $id;
  $sql = "UPDATE orders SET ".implode(',', $set)." WHERE id=?";
  $up = $pdo->prepare($sql);
  $up->execute($params);
}

// Carrega pedido atualizado
$st2 = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$st2->execute([$id]);
$after = $st2->fetch();

$beforeStatus = $before['status'] ?? '';
$afterStatus  = $after['status']  ?? '';
$protoBefore  = trim($before['protocol_number'] ?? '');
$protoAfter   = trim($after['protocol_number'] ?? '');
$codigoBefore = trim($before['codigo_chave'] ?? '');
$codigoAfter  = trim($after['codigo_chave'] ?? '');

// dispara e-mail do protocolo
if (($afterStatus === 'protocol_assigned' && $beforeStatus !== 'protocol_assigned') || 
    ($protoAfter !== '' && $protoAfter !== $protoBefore)) {
  notify_protocol_assigned($pdo, $id);
}

// dispara e-mail de conclus�0�0o com c��digo
if ($afterStatus === 'completed' && $codigoAfter !== '' && $codigoAfter !== $codigoBefore) {
  notify_order_completed_with_code($pdo, $id);
}

$redir = "/?page=admin_order_edit&id=".$id;
header("Location: ".$redir."&ok=1");
exit;
