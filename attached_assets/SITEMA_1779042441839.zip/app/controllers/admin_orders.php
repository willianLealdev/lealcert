<?php
// app/controllers/admin_orders.php — paginação + filtros + "Inserir Protocolo"
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

/* Helpers */
function h($v): string {
  if ($v === null) return '';
  if (is_string($v) || is_numeric($v)) return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
  if (is_object($v)) return htmlspecialchars('['.get_class($v).']', ENT_QUOTES, 'UTF-8');
  if (is_array($v))  return htmlspecialchars(json_encode($v, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE), ENT_QUOTES, 'UTF-8');
  return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
function fmt_dt($v): string {
  if (!$v) return '—';
  $t = @strtotime($v);
  if ($t === false) return '—';
  return date('d/m/Y H:i', $t);
}
function fmt_money($v): string {
  return 'R$ '.number_format((float)$v, 2, ',', '.');
}

/* -------- Filtros -------- */
$qstr      = isset($_GET['q'])         ? (string)$_GET['q']         : '';
$status    = isset($_GET['status'])    ? (string)$_GET['status']    : '';
$date_from = isset($_GET['date_from']) ? (string)$_GET['date_from'] : '';
$date_to   = isset($_GET['date_to'])   ? (string)$_GET['date_to']   : '';

/* -------- Paginação -------- */
$allowedPer = [10,20,50,100];
$per = (int)($_GET['per'] ?? 20);
if (!in_array($per, $allowedPer, true)) $per = 20;

$page = (int)($_GET['p'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $per;

/* WHERE + params (apenas posicionais) */
$where = [];
$params = [];

if ($qstr !== '') {
  $where[] = "("
    ."order_number LIKE ? OR customer_name LIKE ? OR customer_email LIKE ? OR customer_phone LIKE ? "
    ."OR customer_cpf_cnpj LIKE ? OR RAZAOSOCIAL LIKE ? OR CNPJ LIKE ? OR protocol_number LIKE ?"
    .")";
  $like = "%$qstr%";
  array_push($params, $like,$like,$like,$like,$like,$like,$like,$like);
}
if ($status !== '')    { $where[] = "status = ?";            $params[] = $status; }
if ($date_from !== '') { $where[] = "DATE(created_at) >= ?"; $params[] = $date_from; }
if ($date_to   !== '') { $where[] = "DATE(created_at) <= ?"; $params[] = $date_to; }

$whereSql = $where ? (" WHERE ".implode(" AND ", $where)) : "";

/* COUNT total */
$total = 0; $countErr = '';
try {
  $sqlCount = "SELECT COUNT(*) FROM orders $whereSql";
  $stc = $pdo->prepare($sqlCount);
  $stc->execute($params);
  $total = (int)$stc->fetchColumn();
} catch (Throwable $e) {
  $countErr = $e->getMessage();
}

/* Ajusta página caso tenha estourado */
$maxPage = max(1, (int)ceil($total / $per));
if ($page > $maxPage) { $page = $maxPage; $offset = ($page - 1) * $per; }

/* SELECT página (LIMIT/OFFSET como inteiros) */
$rows = []; $selectErr = '';
try {
  $lim = (int)$per;
  $off = (int)$offset;

  $sql = "SELECT
            id, order_number, customer_name, customer_cpf_cnpj,
            RAZAOSOCIAL, CNPJ, customer_email, customer_phone,
            scheduled_at, total, protocol_number, status, user_id, created_at
          FROM orders
          $whereSql
          ORDER BY COALESCE(created_at, NOW()) DESC, id DESC
          LIMIT $lim OFFSET $off";
  $st = $pdo->prepare($sql);
  $st->execute($params);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
  $selectErr = $e->getMessage();
}

/* helper para manter querystring nos links da paginação */
function build_qs(array $override = []): string {
  $keep = $_GET;
  unset($keep['p']); // página será ajustada
  $q = array_merge($keep, $override);
  return http_build_query($q);
}

/* Mapa de labels p/ status */
$STATUS_LABELS = [
  'created'           => 'Criado',
  'pending_payment'   => 'Aguardando pagamento',
  'paid'              => 'Pago',
  'protocol_assigned' => 'Protocolo',
  'completed'         => 'Concluído'
];

include __DIR__ . '/../views/_header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h5 mb-0">Pedidos (Admin)</h1>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-warning" href="/?page=admin_orders_sync_all">🔄 Sincronizar todos</a>
    <a class="btn btn-outline-secondary" href="/?page=admin_dashboard">Voltar ao dashboard</a>
  </div>
</div>

<?php if (!empty($countErr)): ?>
  <div class="alert alert-danger">Erro no COUNT: <span class="small"><?= h($countErr) ?></span></div>
<?php endif; ?>
<?php if (!empty($selectErr)): ?>
  <div class="alert alert-danger">Erro no SELECT: <span class="small"><?= h($selectErr) ?></span></div>
<?php endif; ?>

<form class="row g-2 mb-3" method="get">
  <input type="hidden" name="page" value="admin_orders">
  <div class="col-md-4">
    <input type="text" class="form-control" name="q" placeholder="Buscar (pedido, cliente, doc, e-mail, protocolo)..." value="<?= h($qstr) ?>">
  </div>
  <div class="col-md-2">
    <select class="form-select" name="status">
      <?php
        $opts = [''=>'-- Status --'] + $STATUS_LABELS;
        foreach ($opts as $k=>$v) {
          $sel = ($status===$k)?'selected':'';
          echo '<option value="'.h($k).'" '.$sel.'>'.h($v).'</option>';
        }
      ?>
    </select>
  </div>
  <div class="col-md-2"><input type="date" class="form-control" name="date_from" value="<?= h($date_from) ?>"></div>
  <div class="col-md-2"><input type="date" class="form-control" name="date_to" value="<?= h($date_to) ?>"></div>
  <div class="col-md-1">
    <select class="form-select" name="per" onchange="this.form.submit()">
      <?php foreach ($allowedPer as $p): ?>
        <option value="<?= $p ?>" <?= $per===$p?'selected':'' ?>><?= $p ?>/pág</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-1 d-grid">
    <button class="btn btn-primary">Filtrar</button>
  </div>
</form>

<div class="d-flex align-items-center justify-content-between mb-2">
  <div class="small text-muted">
    Total: <strong><?= (int)$total ?></strong> • Página <strong><?= (int)$page ?></strong> de <strong><?= (int)$maxPage ?></strong>
  </div>
  <?php if ($maxPage > 1): ?>
  <nav>
    <ul class="pagination pagination-sm mb-0">
      <li class="page-item <?= $page<=1?'disabled':'' ?>">
        <a class="page-link" href="/?<?= build_qs(['p'=>1]) ?>">«</a>
      </li>
      <li class="page-item <?= $page<=1?'disabled':'' ?>">
        <a class="page-link" href="/?<?= build_qs(['p'=>$page-1]) ?>">‹</a>
      </li>
      <?php
        $start = max(1, $page-2);
        $end   = min($maxPage, $page+2);
        for ($i=$start; $i<=$end; $i++):
      ?>
      <li class="page-item <?= $i===$page?'active':'' ?>">
        <a class="page-link" href="/?<?= build_qs(['p'=>$i]) ?>"><?= $i ?></a>
      </li>
      <?php endfor; ?>
      <li class="page-item <?= $page>=$maxPage?'disabled':'' ?>">
        <a class="page-link" href="/?<?= build_qs(['p'=>$page+1]) ?>">›</a>
      </li>
      <li class="page-item <?= $page>=$maxPage?'disabled':'' ?>">
        <a class="page-link" href="/?<?= build_qs(['p'=>$maxPage]) ?>">»</a>
      </li>
    </ul>
  </nav>
  <?php endif; ?>
</div>

<div class="table-responsive">
  <table class="table table-sm align-middle">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Pedido</th>
        <th>Cliente</th>
        <th>Doc</th>
        <th>Razão/CNPJ</th>
        <th>Agendamento</th>
        <th>Total</th>
        <th>Protocolo</th>
        <th>Status</th>
        <th>Contador</th>
        <th>Criado</th>
        <th class="text-end">Ações</th>
      </tr>
    </thead>
    <tbody>
    <?php if (!$rows): ?>
      <tr><td colspan="12" class="text-center text-muted py-4">Nenhum pedido retornado (remova filtros e tente novamente).</td></tr>
    <?php else:
      foreach ($rows as $r):
        $ag   = fmt_dt($r['scheduled_at'] ?? null);
        $tot  = fmt_money($r['total'] ?? 0);
        $stat = $STATUS_LABELS[$r['status']] ?? $r['status'];
        $doc  = $r['customer_cpf_cnpj'] ?: '—';
        $razao = $r['RAZAOSOCIAL'] ?: '—';
        if (!empty($r['CNPJ'])) $razao .= ' / '.$r['CNPJ'];
        $created = fmt_dt($r['created_at'] ?? null);

        $isPaid   = (isset($r['status']) && $r['status']==='paid');
        $hasProto = !empty($r['protocol_number']);
    ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><a href="/?page=order_detail&id=<?= (int)$r['id'] ?>"><?= h($r['order_number']) ?></a></td>
        <td><?= h($r['customer_name']) ?></td>
        <td><?= h($doc) ?></td>
        <td><?= h($razao) ?></td>
        <td><?= h($ag) ?></td>
        <td><?= $tot ?></td>
        <td><?= h($r['protocol_number'] ?: '—') ?></td>
        <td><?= h($stat) ?></td>
        <td>#<?= (int)$r['user_id'] ?></td>
        <td><?= h($created) ?></td>
        <td class="text-end">
          <div class="btn-group btn-group-sm">
            <a class="btn btn-outline-secondary" href="/?page=order_detail&id=<?= (int)$r['id'] ?>">Detalhes</a>
            <a class="btn btn-outline-primary" href="/?page=admin_order_edit&id=<?= (int)$r['id'] ?>">Editar</a>
            <?php if ($isPaid && !$hasProto): ?>
              <a class="btn btn-warning" href="/?page=admin_order_edit&id=<?= (int)$r['id'] ?>&focus=protocol">Protocolo</a>
            <?php endif; ?>
            <a class="btn btn-outline-danger"
               href="/?page=admin_order_delete&id=<?= (int)$r['id'] ?>"
               onclick="return confirm('Excluir o pedido #<?= h($r['order_number']) ?>?');">Excluir</a>
          </div>
        </td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../views/_footer.php';
