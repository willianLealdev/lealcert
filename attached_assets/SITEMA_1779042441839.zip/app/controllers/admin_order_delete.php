<?php
// app/controllers/admin_order_delete.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
require_login();
require_role('admin');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); echo "Pedido inválido."; exit; }

try {
  $st = $pdo->prepare("DELETE FROM orders WHERE id=? LIMIT 1");
  $st->execute([$id]);
} catch (Throwable $e) {
  // se quiser, logue o erro em storage/logs
}

header('Location: /?page=admin_orders');
exit;
