<?php
// app/lib/notify.php
require_once __DIR__ . '/mailer.php';

if (!function_exists('notify_protocol_assigned')) {
  /**
   * Envia e-mail ao contador (dono do pedido) informando que o protocolo foi atribuído.
   * Retorna true se o e-mail foi disparado, false caso contrário.
   */
  function notify_protocol_assigned(PDO $pdo, int $orderId): bool {
    // Carrega pedido
    $st = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
    $st->execute([$orderId]);
    $o = $st->fetch(PDO::FETCH_ASSOC);
    if (!$o) return false;

    // Carrega dono (contador)
    $ownerId = (int)($o['user_id'] ?? 0);
    if ($ownerId <= 0) return false;

    $ust = $pdo->prepare("SELECT name, email FROM users WHERE id=?");
    $ust->execute([$ownerId]);
    $u = $ust->fetch(PDO::FETCH_ASSOC);
    if (!$u || !filter_var($u['email'] ?? '', FILTER_VALIDATE_EMAIL)) return false;

    // Dados do e-mail
    $orderNo   = $o['order_number'] ?? ('#'.$orderId);
    $when      = !empty($o['scheduled_at']) ? date('d/m/Y H:i', strtotime($o['scheduled_at'])) : '—';
    $proto     = trim($o['protocol_number'] ?? '');
    $baseUrl   = (defined('SITE_URL') && SITE_URL) ? rtrim(SITE_URL, '/') : '';
    $detailUrl = ($baseUrl ?: '') . '/?page=order_detail&id=' . $orderId;

    $subject = "Protocolo disponível — Pedido {$orderNo}";
    $h = function($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
    $html = "
      <p>Olá, ".$h($u['name'] ?? '')."</p>
      <p>O pedido <strong>".$h($orderNo)."</strong> foi atualizado para <strong>Protocolo</strong>.</p>
      <p><strong>Protocolo:</strong> ".$h($proto ?: '—')."<br>
         <strong>Data/horário para emissão:</strong> ".$h($when)."</p>
      <p>Veja os detalhes: <a href=\"".$h($detailUrl)."\">".$h($detailUrl)."</a></p>
      <p>".$h(defined('APP_NAME') ? APP_NAME : 'RIDIECERT')."</p>
    ";

    return ridie_send_mail($u['email'], $subject, $html);
  }
}
