<?php
// app/lib/mailer.php
if (!function_exists('ridie_send_mail')) {
  function ridie_send_mail(string $to, string $subject, string $html, ?string $text = null): bool {
    $from = defined('MAIL_FROM') ? MAIL_FROM : 'no-reply@example.com';
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: {$from}\r\n";
    $headers .= "X-Mailer: PHP/".phpversion();

    if ($text === null) {
      $text = strip_tags(str_replace(['<br>','<br/>','<br />'], "\n", $html));
    }

    $ok = @mail($to, "=?UTF-8?B?".base64_encode($subject)."?=", $html, $headers);

    if (defined('MAIL_DEBUG') && MAIL_DEBUG) {
      error_log("[RIDIECERT][MAIL] to={$to} subject={$subject} sent=" . ($ok?'YES':'NO'));
    }
    return $ok;
  }
}
