<?php
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

/* helper local (caso não exista no config) */
if (!function_exists('only_digits')) {
  function only_digits($s) { return preg_replace('/\D+/', '', (string)$s); }
}

/**
 * Login por CPF/CNPJ (apenas dígitos) + senha
 * - Normaliza CPF/CNPJ no SQL (ignora ., -, / e espaços)
 * - Aceita coluna de senha 'password' (padrão) ou 'password_hash'
 * - Bloqueia se is_active != 1
 */
function auth_login($cpf_cnpj, $password) {
  global $pdo;

  $id = only_digits($cpf_cnpj);

  // Busca usuário comparando o documento sem pontuação/espacos
  $stmt = $pdo->prepare("
    SELECT *
    FROM users
    WHERE TRIM(REPLACE(REPLACE(REPLACE(REPLACE(cpf_cnpj, '.', ''), '-', ''), '/', ''), ' ', '')) = ?
    LIMIT 1
  ");
  $stmt->execute([$id]);
  $u = $stmt->fetch();
  if (!$u) {
    // opcional: $_SESSION['LOGIN_ERR'] = 'CPF/CNPJ não encontrado.';
    return false;
  }

  // Descobre a coluna de hash disponível
  $pwdHash = null;
  if (array_key_exists('password', $u) && !empty($u['password'])) {
    $pwdHash = $u['password'];
  } elseif (array_key_exists('password_hash', $u) && !empty($u['password_hash'])) {
    $pwdHash = $u['password_hash'];
  }

  if (!$pwdHash || !password_verify($password, $pwdHash)) {
    // opcional: $_SESSION['LOGIN_ERR'] = 'Senha inválida.';
    return false;
  }

  // Bloqueio por ativação (admin pode ativar; ou via verificação de e-mail)
  if (isset($u['is_active']) && (int)$u['is_active'] !== 1) {
    $_SESSION['LOGIN_BLOCKED'] = 'Conta ainda não ativada. Verifique seu e-mail ou peça liberação ao admin.';
    return false;
  }

  // OK: abre sessão
  session_regenerate_id(true);
  $_SESSION['uid']  = (int)$u['id'];
  $_SESSION['role'] = $u['role'] ?? 'contador';
  return true;
}

/** Retorna o usuário logado (array) ou null */
function auth_user() {
  global $pdo;
  if (empty($_SESSION['uid'])) return null;
  $stmt = $pdo->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
  $stmt->execute([$_SESSION['uid']]);
  $user = $stmt->fetch();
  return $user ?: null;
}

/** Exige login (e derruba sessão se usuário estiver desativado) */
function require_login() {
  $user = auth_user();
  if (!$user) {
    redirect('/?page=login');
  }
  if (isset($user['is_active']) && (int)$user['is_active'] !== 1) {
    logout();
  }
}

/**
 * Exige perfil/role. Aceita string ou array de roles.
 * Ex.: require_role('admin') ou require_role(['admin','contador'])
 */
function require_role($role) {
  if (!isset($_SESSION['role'])) {
    redirect('/?page=login');
  }
  if (is_array($role)) {
    if (!in_array($_SESSION['role'], $role, true)) {
      redirect('/?page=login');
    }
  } else {
    if ($_SESSION['role'] !== $role) {
      redirect('/?page=login');
    }
  }
}

/** Encerra sessão e volta ao login */
function logout() {
  if (session_status() === PHP_SESSION_ACTIVE) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
      $params = session_get_cookie_params();
      setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
  }
  redirect('/?page=login');
}
