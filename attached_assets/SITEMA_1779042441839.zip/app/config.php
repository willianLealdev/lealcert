<?php
// ===============================
// REDIECERT - app/config.php
// ===============================

$candidates = [
  __DIR__ . '/../.env',
  __DIR__ . '/.env',
  __DIR__ . '/../../.env',
];

$envPath = null;
foreach ($candidates as $p) {
  if (is_file($p)) { $envPath = $p; break; }
}
if (!$envPath) {
  die("ERRO: Arquivo .env não encontrado. Coloque o .env na raiz do site (mesmo nível do index.php) ou um nível acima de /app.");
}

$env = parse_ini_file($envPath, false, INI_SCANNER_RAW);
if (!is_array($env)) {
  die("ERRO: Não foi possível ler o .env. Verifique a codificação (UTF-8) e o formato CHAVE=valor.");
}

/* exporta .env para getenv()/$_ENV e remove aspas externas */
foreach ($env as $k => $v) {
  if (is_string($v) && strlen($v) >= 2 &&
     (($v[0] === '"'  && substr($v, -1) === '"') ||
      ($v[0] === "'"  && substr($v, -1) === "'"))) {
    $v = substr($v, 1, -1);
  }
  putenv("$k=$v");
  $_ENV[$k] = $v;
}

function env_or_default(array $arr, string $key, $default) {
  $v = getenv($key);
  if ($v !== false && $v !== "") return $v;
  return array_key_exists($key, $arr) && $arr[$key] !== "" ? $arr[$key] : $default;
}

date_default_timezone_set(env_or_default($env, 'TIMEZONE', 'America/Sao_Paulo'));

define('MP_PUBLIC_KEY', env_or_default($env, 'MP_PUBLIC_KEY', ''));
define('APP_NAME',        env_or_default($env, 'APP_NAME', 'REDIECERT'));
define('SITE_URL',        rtrim(env_or_default($env, 'SITE_URL', ''), '/'));
define('DB_HOST',         env_or_default($env, 'DB_HOST', 'localhost'));
define('DB_NAME',         env_or_default($env, 'DB_NAME', 'redie_rediecert'));
define('DB_USER',         env_or_default($env, 'DB_USER', 'root'));
define('DB_PASS',         env_or_default($env, 'DB_PASS', ''));
define('DB_PORT',  (int)  env_or_default($env, 'DB_PORT', '3306'));
define('MP_ACCESS_TOKEN', env_or_default($env, 'MP_ACCESS_TOKEN', ''));
define('WEBHOOK_SECRET',  env_or_default($env, 'WEBHOOK_SECRET', 'changeme'));
define('MAIL_FROM', env_or_default($env, 'MAIL_FROM', 'REDIECERT <no-reply@rediecert.com.br>'));
define('MAIL_DEBUG', (int) env_or_default($env, 'MAIL_DEBUG', '0'));

try {
  $dsn = "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4";
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
  ]);
} catch (PDOException $e) {
  die("Erro ao conectar no banco: " . $e->getMessage()
     . " | Tentativa: user='".DB_USER."', db='".DB_NAME."', host='".DB_HOST."':".DB_PORT);
}

/* Helpers */
function sanitize($s)     { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function only_digits($s)  { return preg_replace('/\D+/', '', (string)($s ?? '')); }
function is_cpf_cnpj($s)  { $d = only_digits($s); return strlen($d) === 11 || strlen($d) === 14; }
function asset($path)     { return '/assets/' . ltrim($path, '/'); }
function redirect($path)  { header("Location: " . $path); exit; }

/** Número do pedido YYYYMMDD-#### */
function order_number_gen(PDO $pdo) {
  $stmt = $pdo->query("SELECT COUNT(*) c FROM orders WHERE DATE(created_at)=CURDATE()");
  $c = (int)$stmt->fetchColumn() + 1;
  return date('Ymd') . '-' . str_pad((string)$c, 4, '0', STR_PAD_LEFT);
}

/** URL base absoluta para e-mails/links */
if (!function_exists('app_base_url')) {
  function app_base_url(): string {
    if (defined('SITE_URL') && SITE_URL !== '') {
      return rtrim(SITE_URL, '/');
    }
    $scheme = 'http';
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
      $scheme = $_SERVER['HTTP_X_FORWARDED_PROTO'];
    } elseif (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
      $scheme = 'https';
    }
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return rtrim($scheme.'://'.$host, '/');
  }
}

/* Carrega o mailer para toda a aplicação (send_mail, send_welcome_email, notify_protocol_assigned, etc.) */
require_once __DIR__ . '/mailer.php';
