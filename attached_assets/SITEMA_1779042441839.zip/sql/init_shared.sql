-- Execute dentro do banco selecionado (ex.: redie_rediecert)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) UNIQUE,
  cpf_cnpj VARCHAR(20) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','contador') NOT NULL DEFAULT 'contador',
  phone VARCHAR(30),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS certificate_models (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(30) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  model_id INT NOT NULL,
  status ENUM('created','pending_payment','paid','protocol_assigned','completed') NOT NULL DEFAULT 'created',
  total DECIMAL(10,2) NOT NULL,
  mp_preference_id VARCHAR(64),
  mp_payment_id VARCHAR(64),
  protocol_number VARCHAR(64),
  scheduled_at DATETIME,
  customer_name VARCHAR(120) NOT NULL,
  customer_cpf_cnpj VARCHAR(20) NOT NULL,
  customer_email VARCHAR(160),
  customer_phone VARCHAR(30),
  cnh_path VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_status (status),
  INDEX idx_orders_created (created_at),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_orders_model FOREIGN KEY (model_id) REFERENCES certificate_models(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS available_slots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slot_datetime DATETIME NOT NULL UNIQUE,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users (name, email, cpf_cnpj, password_hash, role, phone)
VALUES ('Administrador', 'admin@ridiecert.local', '00000000000',
        '$2y$10$D8y7h2m75qI3Zj4dE1ivbO1iJgDpvF3l2x1WYPKxIS3zKtUOqfJ1i',
        'admin', NULL)
ON DUPLICATE KEY UPDATE id=id;

INSERT INTO certificate_models (name, description, price, active) VALUES
('e-CPF A1 (1 ano)', 'Certificado digital e-CPF A1 com validade de 12 meses.', 129.90, 1),
('e-CPF A3 (2 anos)', 'Certificado digital e-CPF A3 com validade de 24 meses.', 249.90, 1),
('e-CNPJ A1 (1 ano)', 'Certificado digital e-CNPJ A1 com validade de 12 meses.', 199.90, 1),
('e-CNPJ A3 (3 anos)', 'Certificado digital e-CNPJ A3 com validade de 36 meses.', 399.90, 1)
ON DUPLICATE KEY UPDATE id=id;
