<?php
require_once __DIR__ . '/app/config.php';
require_once __DIR__ . '/app/auth.php';

$page = $_GET['page'] ?? 'login';

$public_pages = [
'login','do_login','register','do_register','logout',
  'mp_webhook','order_success','order_failure','order_pending',
  'forgot_password','do_forgot_password','reset_password','do_reset_password',
  'verify_email','admin_stats_api'
];

if (!in_array($page, $public_pages, true)) {
  require_login();
}

/* Carrega o controller correspondente */
$view_path = __DIR__ . '/app/controllers/' . basename($page) . '.php';
if (file_exists($view_path)) {
  require $view_path;
} else {
  http_response_code(404);
  echo "Página não encontrada.";
}
