// RIDIECERT — Agenda dinâmica para a tela de Novo Pedido
// - substitui o <select name="scheduled_at"> antigo por calendário + slots 30/30 (09:00→15:00)
// - bloqueia sábados e domingos
// - usa /?page=slots&date=YYYY-MM-DD para marcar horários ocupados
(function () {
  function onReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") setTimeout(fn, 0);
    else document.addEventListener("DOMContentLoaded", fn);
  }

  onReady(function () {
    // Ativa só na tela de Novo Pedido
    var isNewOrderPage =
      /(^|[?&])page=new_order(&|$)/.test(location.search) ||
      document.querySelector('form[action*="?page=do_new_order"]');

    if (!isNewOrderPage) return;

    // Encontra o <select name="scheduled_at"> antigo
    var oldSel = document.querySelector('select[name="scheduled_at"]');
    if (!oldSel) {
      // alguns templates usam id diferente; tenta por id genérico
      oldSel = document.getElementById("scheduled_at");
      if (oldSel && oldSel.tagName !== "SELECT") oldSel = null;
    }
    if (!oldSel) return; // nada para fazer

    // Estilos básicos (injeta se não existir)
    if (!document.getElementById("ridieAgendaStyle")) {
      var style = document.createElement("style");
      style.id = "ridieAgendaStyle";
      style.textContent =
        ".ridie-slot{padding:.45rem .7rem;border:1px solid #ddd;border-radius:12px;margin:.25rem;display:inline-block;cursor:pointer;font-weight:500}" +
        ".ridie-slot.disabled{opacity:.45;cursor:not-allowed}" +
        ".ridie-slot.active{border-color:#0d6efd;background:#0d6efd;color:#fff}";
      document.head.appendChild(style);
    }

    // Cria a nova UI
    var dateLabel = document.createElement("label");
    dateLabel.className = "form-label";
    dateLabel.textContent = "Data do Agendamento";

    var dateInput = document.createElement("input");
    dateInput.type = "date";
    dateInput.className = "form-control mb-2";
    dateInput.id = "ridie_date";
    dateInput.required = true;

    var slotsLabel = document.createElement("label");
    slotsLabel.className = "form-label mt-2";
    slotsLabel.textContent = "Horários disponíveis";

    var slotsWrap = document.createElement("div");
    slotsWrap.id = "ridie_slots";

    // O valor real vai em um hidden com o name correto
    var hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = "scheduled_at";
    hidden.id = "scheduled_at_hidden";

    // Insere UI nova antes do select antigo
    oldSel.parentNode.insertBefore(dateLabel, oldSel);
    oldSel.parentNode.insertBefore(dateInput, oldSel);
    oldSel.parentNode.insertBefore(slotsLabel, oldSel);
    oldSel.parentNode.insertBefore(slotsWrap, oldSel);
    oldSel.parentNode.insertBefore(hidden, oldSel);

    // Esconde o select antigo e remove name p/ não conflitar
    oldSel.removeAttribute("name");
    oldSel.style.display = "none";

    // Helpers
    function pad(n) { return n < 10 ? "0" + n : "" + n; }
    function isWeekend(d) { var g = d.getDay(); return g === 0 || g === 6; } // 0=Dom,6=Sáb
    function isoDate(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }

    function fetchBusySet(iso) {
      // Tenta usar o endpoint /?page=slots. Se falhar, segue sem marcação de ocupado.
      return fetch("/?page=slots&date=" + encodeURIComponent(iso), { cache: "no-store" })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) {
          var set = new Set();
          if (j && Array.isArray(j.slots)) {
            j.slots.forEach(function (s) { if (!s.available) set.add(s.value); });
          }
          return set;
        })
        .catch(function () { return new Set(); });
    }

    function renderSlots(iso) {
      slotsWrap.textContent = "Carregando...";
      var parts = iso.split("-");
      if (parts.length !== 3) { slotsWrap.textContent = "Data inválida"; return; }
      var y = +parts[0], m = +parts[1] - 1, d = +parts[2];
      var base = new Date(y, m, d);
      if (isWeekend(base)) { slotsWrap.textContent = "Atendimento apenas de segunda a sexta."; hidden.value = ""; return; }

      var now = new Date();
      var startHour = 9, endHour = 15, step = 30; // 09:00 → 15:00, 30min

      fetchBusySet(iso).then(function (busy) {
        slotsWrap.innerHTML = "";
        var any = false;

        for (var h = startHour; h <= endHour; h++) {
          for (var mm = 0; mm < 60; mm += step) {
            var value = iso + " " + pad(h) + ":" + pad(mm) + ":00";
            var label = pad(h) + ":" + pad(mm);

            var btn = document.createElement("button");
            btn.type = "button";
            btn.className = "ridie-slot";
            btn.textContent = label;

            var disabled = busy.has(value);
            if (iso === isoDate(now)) {
              var t = new Date(y, m, d, h, mm, 0);
              if (t <= now) disabled = true;
            }
            if (disabled) btn.classList.add("disabled");

            if (!disabled) {
              any = true;
              btn.addEventListener("click", function (val, el) {
                return function () {
                  document.querySelectorAll(".ridie-slot").forEach(function (x) { x.classList.remove("active"); });
                  el.classList.add("active");
                  hidden.value = val; // "YYYY-MM-DD HH:MM:00"
                };
              }(value, btn));
            }

            slotsWrap.appendChild(btn);
          }
        }

        if (!any) {
          var p = document.createElement("p");
          p.textContent = "Sem horários disponíveis nesta data.";
          slotsWrap.appendChild(p);
          hidden.value = "";
        }
      });
    }

    // Data inicial: hoje (se útil) senão próxima segunda
    var start = new Date();
    if (start.getDay() === 6) start.setDate(start.getDate() + 2);
    if (start.getDay() === 0) start.setDate(start.getDate() + 1);
    dateInput.value = isoDate(start);
    renderSlots(dateInput.value);

    dateInput.addEventListener("change", function () {
      if (!this.value) return;
      var d = new Date(this.value + "T00:00:00");
      if (isWeekend(d)) { slotsWrap.textContent = "Atendimento apenas de segunda a sexta."; hidden.value = ""; return; }
      renderSlots(this.value);
    });
  });
})();
