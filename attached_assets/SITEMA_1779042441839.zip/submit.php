<?php
// submit.php — salva o pedido e redireciona para o checkout (rota /?page=pay)
// Coloque este arquivo na RAIZ do site (mesmo nível do index.php)

ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/app/config.php';
require_once __DIR__ . '/app/auth.php';
require_login();

// Usa only_digits() do config.php. Se por algum motivo não existir, define aqui.
if (!function_exists('only_digits')) {
  function only_digits($s){ return preg_replace('/\D+/', '', (string)($s ?? '')); }
}

function fail($msg){
  // Loga e responde texto (evita 500 em branco)
  $dir = __DIR__ . '/storage/logs';
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  @file_put_contents($dir.'/submit.log', '['.date('Y-m-d H:i:s')."] FAIL | $msg\n", FILE_APPEND);
  header('Content-Type:text/plain; charset=utf-8');
  http_response_code(500);
  echo $msg;
  exit;
}
function logx($label,$data=[]){
  $dir = __DIR__ . '/storage/logs';
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  @file_put_contents(
    $dir.'/submit.log',
    '['.date('Y-m-d H:i:s')."] $label | ".json_encode($data,JSON_UNESCAPED_UNICODE)."\n",
    FILE_APPEND
  );
}

try {
  $u = auth_user(); 
  $user_id = (int)($u['id'] ?? 0);

  // ---------- Campos do formulário ----------
  $model_id     = (int)($_POST['model_id'] ?? 0);
  $model_type   = $_POST['model_type'] ?? 'cpf';
  $client_name  = trim($_POST['client_name'] ?? '');
  $client_cpf   = only_digits($_POST['client_cpf'] ?? '');
  $client_email = trim($_POST['client_email'] ?? '');
  $client_phone = trim($_POST['client_phone'] ?? '');
  $company_name = trim($_POST['company_name'] ?? '');        // RAZAOSOCIAL
  $company_cnpj = only_digits($_POST['company_cnpj'] ?? ''); // CNPJ
  $inss_number  = trim($_POST['inss_number'] ?? '');
  $schedule_at  = trim($_POST['schedule_at'] ?? '');

  // Se veio separado (schedule_date + schedule_time)
  if ($schedule_at === '' && !empty($_POST['schedule_date']) && !empty($_POST['schedule_time'])) {
    $schedule_at = $_POST['schedule_date'].' '.$_POST['schedule_time'].':00';
  }

  // ---------- Validações ----------
  $errs = [];
  if ($model_id <= 0) $errs[] = 'Modelo inválido.';
  if ($client_name === '') $errs[] = 'Informe o nome do cliente.';
  if ($client_email === '' || !filter_var($client_email, FILTER_VALIDATE_EMAIL)) $errs[] = 'E-mail inválido.';
  if ($client_phone === '') $errs[] = 'Informe o telefone.';
  if (strlen($client_cpf) !== 11) $errs[] = 'CPF inválido.';
  $isCNPJ = ($model_type === 'cnpj');
  if ($isCNPJ) {
    if ($company_name === '') $errs[] = 'Informe a Razão Social.';
    if (strlen($company_cnpj) !== 14) $errs[] = 'CNPJ inválido.';
  }
  if ($schedule_at === '') $errs[] = 'Selecione data e horário do agendamento.';

  // CNH PDF obrigatória (até 2MB)
  if (empty($_FILES['cnh_file']['name']) || !is_uploaded_file($_FILES['cnh_file']['tmp_name'])) {
    $errs[] = 'Envie a CNH em PDF.';
  } else {
    $ext = strtolower(pathinfo($_FILES['cnh_file']['name'], PATHINFO_EXTENSION));
    if ($ext !== 'pdf') $errs[] = 'A CNH deve ser um arquivo PDF.';
    if ((int)$_FILES['cnh_file']['size'] > 2*1024*1024) $errs[] = 'Arquivo da CNH acima de 2MB.';
  }

  if ($errs) fail("Não foi possível salvar a ordem:\n- ".implode("\n- ", $errs));

  // ---------- Preço do modelo (certificate_models -> products) ----------
  $total_amount = 0.0;
  try {
    $tbl='certificate_models'; $col='price';
    foreach (['price','valor','amount','preco','value'] as $c){ try{$pdo->query("SELECT `$c` FROM `$tbl` LIMIT 1"); $col=$c; break;}catch(Throwable $x){} }
    $q=$pdo->prepare("SELECT `$col` AS price FROM `$tbl` WHERE id=?"); $q->execute([$model_id]);
    if ($r=$q->fetch()) $total_amount=(float)$r['price'];
  } catch(Throwable $e) {
    try {
      $tbl='products'; $col='price';
      foreach (['price','valor','amount','preco','value'] as $c){ try{$pdo->query("SELECT `$c` FROM `$tbl` LIMIT 1"); $col=$c; break;}catch(Throwable $x){} }
      $q=$pdo->prepare("SELECT `$col` AS price FROM `$tbl` WHERE id=?"); $q->execute([$model_id]);
      if ($r=$q->fetch()) $total_amount=(float)$r['price'];
    } catch(Throwable $e2) {}
  }

  // ---------- Upload da CNH ----------
  $dir = __DIR__ . '/storage/uploads/cnh';
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  if (!is_writable($dir)) fail("Diretório de upload sem permissão: $dir");
  $fname = 'cnh_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.pdf';
  $dest  = $dir . '/' . $fname;
  if (!move_uploaded_file($_FILES['cnh_file']['tmp_name'], $dest)) fail("Falha ao salvar a CNH em: $dest");
  @chmod($dest, 0644);
  $cnh_path = 'storage/uploads/cnh/' . $fname;

  // ---------- Número do pedido ----------
  $date = date('Ymd');
  $c = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE DATE(created_at)=CURDATE()")->fetchColumn()+1;
  $order_number = $date.'-'.str_pad((string)$c,4,'0',STR_PAD_LEFT);

  // ---------- INSERT em orders (usa seus nomes de colunas) ----------
  $sql="INSERT INTO orders
    (user_id, model_id, status, order_number, total,
     customer_name, customer_email, customer_phone, customer_cpf_cnpj,
     RAZAOSOCIAL, CNPJ, inss_number, cnh_path, scheduled_at,
     created_at, updated_at)
    VALUES
    (:user_id, :model_id, :status, :order_number, :total,
     :customer_name, :customer_email, :customer_phone, :customer_cpf_cnpj,
     :RAZAOSOCIAL, :CNPJ, :inss_number, :cnh_path, :scheduled_at,
     NOW(), NOW())";

  $params = [
    ':user_id'            => $user_id,
    ':model_id'           => $model_id,
    ':status'             => 'pending_payment',
    ':order_number'       => $order_number,
    ':total'              => $total_amount,
    ':customer_name'      => $client_name,
    ':customer_email'     => $client_email,
    ':customer_phone'     => $client_phone,
    ':customer_cpf_cnpj'  => $client_cpf,
    ':RAZAOSOCIAL'        => $company_name !== '' ? $company_name : null,
    ':CNPJ'               => $company_cnpj !== '' ? $company_cnpj : null,
    ':inss_number'        => $inss_number !== '' ? $inss_number : null,
    ':cnh_path'           => $cnh_path,
    ':scheduled_at'       => $schedule_at
  ];

  $st=$pdo->prepare($sql);
  $st->execute($params);
  $order_id = (int)$pdo->lastInsertId();

  logx('order_insert_ok', ['order_id'=>$order_id, 'order_number'=>$order_number, 'total'=>$total_amount]);

  // ---------- Redireciona para a rota de pagamento ----------
  header('Location: /?page=pay&id='.$order_id);
  exit;

} catch (Throwable $e) {
  fail("ERRO: ".$e->getMessage());
}
