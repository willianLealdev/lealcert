RIDIECERT (public_html layout)
1) Suba tudo para public_html/
2) Copie .env.example para .env e configure DB + Mercado Pago
3) Importe o script SQL para hospedagem compartilhada (use o arquivo que enviei ou cole o script no phpMyAdmin)
4) Acesse seu domínio e faça login (admin: 00000000000 / admin123)
